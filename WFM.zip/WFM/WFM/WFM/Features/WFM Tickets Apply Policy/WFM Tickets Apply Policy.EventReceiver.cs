using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using NYL.WFM.Common.ExpirationPolicy;
using WFM.Common;

namespace NYL.WFM.Features.WFM_Tickets_Policy
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("8ef580f0-901c-4037-97e7-e285c321502c")]
    public class WFM_Tickets_PolicyEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            try
            {
                SPWeb webObj = properties.Feature.Parent as SPWeb;
                using (SPSite site = new SPSite(webObj.Site.ID))
                {
                    using (SPWeb web = site.OpenWeb(webObj.ID))
                    {
                        //Apply retention policy to WFM Tickets
                        ExpirationPolicyManagement.ApplyWFMTicketsPolicy("WFMTicketsCT", Constants.ListName.WFM_TICKETS, web);
                    }
                }
                WFMLogger.LogTraceInformation("Activating Feature WFM Tickets Apply Policy Event Receiver successful", WFMLogger.LogCategory.InfoLog);
            }
            catch (Exception e)
            {
                ExceptionHelper.HandleException(new Exception("Error occured Activating WFM Tickets Apply Policy Event Receiver feature", e), ExceptionPolicy.BOExceptionPolicy, true);
            }
        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
