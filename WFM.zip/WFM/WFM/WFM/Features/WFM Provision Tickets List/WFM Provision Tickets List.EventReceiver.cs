using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using WFM.Common;

namespace WFM.Features.WFM_Provision_Tickets_List
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("d7fdfedb-af08-46e1-844f-2c13aab1c738")]
    public class WFM_Provision_Tickets_ListEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            try
            {
                SPWeb oWeb = (SPWeb)properties.Feature.Parent;
                if (oWeb != null)
                {
                    if (oWeb.Site != null)
                    {
                        BCSHelper.CreateAgentNameBCSSiteColumn(oWeb.Site.ID, oWeb.ID);
                        BCSHelper.AddAgentNameToList(oWeb.Site.ID, oWeb.ID, Constants.ListName.WFM_TICKETS); //Have to reopen site in order for site column to be recognized
                    
                    }
                } 

                WFMLogger.LogTraceInformation("Activating Feature Provisioning of WFM Ticket List Successfully", WFMLogger.LogCategory.InfoLog);
             }
             catch (Exception ex)
             {
                 ExceptionHelper.HandleException(new Exception("Error occured while activating Feature Provisioning of WFM Ticket List", ex), ExceptionPolicy.BOExceptionPolicy, true);
             }
        }


    }
}
