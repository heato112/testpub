﻿
namespace WFM.Common
{
    public static class Constants
    {
        public struct ListName
        {
            public const string WFM_ALLUSERS = "WFMUsers";
            public const string WFM_TICKETS = "WFMTickets";
            public const string EMAIL_CONTENT = "Email Content";
            public const string BLOCKED_USERS = "BlockedUsers";
            public const string GROUP_SYNC_LIST = "GroupSyncList";
            public const string REPORTS_SYNC_LIST = "ReportsSyncList";
            public const string REPORTS_TEMPLATE_LIST = "ReportsTemplateList";
            public const string REQUEST_TYPE = "RequestType";
        }

        public struct ViewName
        {
            public const string WFM_All_Managers = "AllManagers";
            public const string WFM_All_Agents = "AllAgents";
            public const string WFM_All_WFMStaff = "AllWfmStaff";
            public const string WFM_All_WFMAdmin = "AllWfmAdmin";
        }
        
        public struct General
        {
            public const string WFM_LOGS_HEADER = "WFMTracker Logs";
            public const string SUPPORT_EMAIL_TITLE = "WFMTracker - Error Occured";
        }

        public struct GroupNames
        {
            public const string MANAGERS_GROUP = "WFM Managers Group";
            public const string AGENTS_GROUP = "WFM Agents Group";
            public const string WFM_STAFF_GROUP = "WFM Staff Group";
            public const string WFM_ADMIN_GROUP = "WFM Admin Group";
        }

        public struct PermissionLevel
        {
            public const string SPECIAL_CONTRIBUTE_ADD_ONLY_ACCESS = "WFM Special Contribute Add Only Access";
            public const string SPECIAL_CONTRIBUTE_EDIT_ONLY_ACCESS = "WFM Special Contribute Edit Only Access";
            public const string SPECIAL_CONTRIBUTE_ADD_EDIT_ONLY_ACCESS = "WFM Special Contribute Add Edit Only Access";
        }

        public struct LogMessage
        {
            public const string LOG_START = "<--Entering-->";
            public const string LOG_END = "<--Exiting-->";
        }

        public struct NotificationKey
        {
            public const string STATUS_UPDATE_EMAIL = "StatusUpdateEmail";
            public const string NEW_TICKET_EMAIL = "NewTicketEmail";
        }

        public struct GroupSyncResultType
        {
            public const string MANAGER_SYNC_COMPLETE = "ManagerSyncComplete";
            public const string AGENT_SYNC_COMPLETE = "AgentSyncComplete";
            public const string WFMSTAFF_SYNC_COMPLETE = "WFMStaffSyncComplete";
            public const string WFMADMIN_SYNC_COMPLETE = "WFMAdminSyncComplete";
            public const string SYNC_PROCESS_COMPLETE = "SyncProcessComplete";
        }

        public struct ReportsSyncResultType
        {
            public const string REPORT_SYNC_COMPLETE = "ReportSyncComplete";
            public const string SYNC_PROCESS_COMPLETE = "SyncProcessComplete";
        }

        public struct TicketsListViewName
        {
            public const string AGENT_OPEN_TICKETS_VIEW = "AgentOpenTicketsView";
            public const string MANAGER_TICKETS_VIEW = "ManagerTicketsView";
            public const string MANAGER_TEAM_MEMBERS_TICKETS_VIEW = "ManagerTeamMembersTicketsView";
            public const string WFMSTAFF_OPEN_TICKETS_VIEW = "WFMStaffOpenTicketsView";
            public const string WFMSTAFF_CLOSED_TICKETS_VIEW = "WFMStaffClosedTicketsView";
            public const string SEARCH_BY_TICKET_NUMBER_VIEW = "SearchByTicketNumberView";
            public const string SEARCH_BY_DATE_VIEW = "SearchByDateView";

        }

        public struct LandingPagesWebPartsTitle
        {
            public const string AGENT_TICKETS_WEBPART = "Agent Tickets";
            public const string MANAGER_TICKETS_WEBPART = "Manager Tickets";
            public const string MANAGER_TEAM_MEMBER_TICKETS_WEBPART = "Manager Team Tickets";
            public const string WFMSTAFF_OPEN_TICKETS_WEBPART = "Open Tickets";
            public const string WFMSTAFF_CLOSED_TICKETS_WEBPART = "Closed Tickets";
            public const string SEARCH_TICKETS_WEBPART = "Tickets";
        }

        public struct ReportsFile
        {
            public const string FILE_NAME = "ReportsFile";
            public const string SHEET_NAME = "WFMTickets";
        }

        public struct ReportPagesWebPartTitle
        {
            public const string REPORT_1 = "User Ticket Details By User";
            public const string REPORT_2 = "WFM Closed Ticket Details By Event Date";
            public const string REPORT_3 = "Request Category Received";
            public const string REPORT_4 = "Request Category Tickets Closed";
            public const string REPORT_5 = "Closed Tickets Compliance";
        }

        public struct ReportPagesPivotName
        {
            public const string REPORT_PIVOT_1 = "ReportPivot1";
            public const string REPORT_PIVOT_2 = "ReportPivot2";
            public const string REPORT_PIVOT_3 = "ReportPivot3";
            public const string REPORT_PIVOT_4 = "ReportPivot4";
            public const string REPORT_PIVOT_5 = "ReportPivot5";
        }

        public struct ModuleName
        {
            public const string WFM_GROUP_SYNC = "WFM Group Sync";
            public const string WFM_REPORT_SYNC = "WFM Report Sync";
        }
    }
}
