﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Navigation;
using Microsoft.BusinessData;
using Microsoft.SharePoint.Portal;
using Microsoft.Office.Server;
using Microsoft.Office.BusinessData;
using Microsoft.SharePoint.BusinessData.SharedService;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.BusinessData.Runtime;
using Microsoft.SharePoint.BusinessData.SharedService;
using Microsoft.BusinessData.MetadataModel;
using Microsoft.BusinessData.Runtime;
using Microsoft.BusinessData.MetadataModel.Collections;
using System.Collections.Specialized;
using System.Xml;
using System.IO;
using Microsoft.SharePoint.Utilities;

namespace WFM.Common
{
    public class BCSHelper
    {
        public static void CreateAgentNameBCSSiteColumn(Guid oSiteId, Guid oWebId)
        {
            using (SPSite site = new SPSite(oSiteId))
            {
                using (SPWeb web = site.OpenWeb(oWebId))
                {

                    try
                    {

                        string fieldXML = "<Field Type='BusinessData' Name='AgentName' Description='' DisplayName='Agent Name' Group='Custom Columns' Hidden='FALSE' Required='TRUE' Sealed='FALSE' ShowInDisplayForm='TRUE' ShowInEditForm='TRUE' ShowInListSettings='TRUE' SystemInstance='WFM' EntityNamespace='http://isodev4.apps.newyorklife.com/' EntityName='ECT_WFMUsers' SecondaryFieldBdcNames='7%2010%2010%2014%2017%2012%20ACF2ID%20AgentName%20EmailAddr%20ManagerACF2ID%20ManagerEmailAddr%20ManagerName%2017'  BdcField='AgentName' HasActions='True' Profile='' RelatedField='ACF2ID' ShowInNewForm='TRUE'></Field>";
                        web.Fields.AddFieldAsXml(fieldXML);
                        web.Update();
                        WFMLogger.LogTraceInformation("Adding agent name as site column successful", WFMLogger.LogCategory.InfoLog);
                    }
                    catch (Exception e)
                    {
                        WFMLogger.LogTraceInformation("Error occured adding agent name as site column", WFMLogger.LogCategory.ErrorLog);
                    }
                }
            }
        }

        public static void AddAgentNameToList(Guid oSiteId, Guid oWebId, string ListName)
        {
            using (SPSite site = new SPSite(oSiteId))
            {
                using (SPWeb web = site.OpenWeb(oWebId))
                {

                    try
                    {

                        SPField agentField = web.Fields.GetFieldByInternalName("AgentName");
                        
                        SPList spList = web.Lists[ListName];
                        
                        SPField ccManagerEmailField = spList.Fields.GetFieldByInternalName("CCManagerEmail");

                        if (spList != null)
                        {
                            spList.ValidationFormula = "=IF(AND([Event Date]>Created-1, [Event Date]<Created+30),TRUE,FAlSE)";
                            spList.ValidationMessage = "The event date cannot be in the past. Please enter a current or future date.";

                            ccManagerEmailField.ValidationFormula= "=OR(ISBLANK([CC Manager Email]), AND(ISERROR(FIND(\" \", [CC Manager Email],1)), IF(ISERROR(FIND(\"@\", [CC Manager Email],2)), FALSE, AND(ISERROR(FIND(\"@\",[CC Manager Email], FIND(\"@\", [CC Manager Email],2)+1)), IF(ISERROR(FIND(\".\", [CC Manager Email], FIND(\"@\", [CC Manager Email],2)+2)), FALSE, FIND(\".\", [CC Manager Email], FIND(\"@\", [CC Manager Email],2)+2) < LEN([CC Manager Email]))))))";
                            ccManagerEmailField.ValidationMessage = "Invalid Email Format";
                            ccManagerEmailField.Update();

                            spList.Fields.Add(agentField);
                            spList.Update();

                            string[] fields = { "AgentName", "RequestType", "EventDate", "Comments", "Notes", "Status" };
                            ReorderFields(spList, fields);
                        }

                        WFMLogger.LogTraceInformation("Adding agent name to list successful", WFMLogger.LogCategory.InfoLog);
                    }
                    catch (Exception e)
                    {
                        WFMLogger.LogTraceInformation("Error adding agent name to list", WFMLogger.LogCategory.ErrorLog);
                    }

                }
            }
        }

        private static void ReorderFields(SPList list, string[] internalNames)
        {
            try
            {
                StringCollection fields = new StringCollection();
                fields.AddRange(internalNames);

                foreach (SPField field in list.Fields)
                {
                    if (!fields.Contains(field.InternalName))
                    {
                        fields.Add(field.InternalName);
                    }
                }
                StringBuilder sb = new StringBuilder();
                XmlTextWriter xmlWriter = new XmlTextWriter(new StringWriter(sb));
                xmlWriter.Formatting = Formatting.Indented;
                xmlWriter.WriteStartElement("Fields");

                for (int i = 0; i < fields.Count; i++)
                {
                    xmlWriter.WriteStartElement("Field");
                    xmlWriter.WriteAttributeString("Name", fields[i]);
                    xmlWriter.WriteEndElement();
                }
                xmlWriter.WriteEndElement();
                xmlWriter.Flush();
                string rpcTemplate = @"<?xml version=""1.0"" encoding=""UTF-8""?>  
        <Method ID=""0,REORDERFIELDS"">  
        <SetList Scope=""Request"">{0}</SetList>  
        <SetVar Name=""Cmd"">REORDERFIELDS</SetVar>  
        <SetVar Name=""ReorderedFields"">{1}</SetVar>  
        <SetVar Name=""owshiddenversion"">{2}</SetVar>  
        </Method>";
                string rpcCall = string.Format(
                    rpcTemplate,
                    list.ID,
                    SPHttpUtility.HtmlEncode(sb.ToString()),
                    list.Version);
                list.ParentWeb.AllowUnsafeUpdates = true;
                list.ParentWeb.ProcessBatchData(rpcCall);
                list.ParentWeb.AllowUnsafeUpdates = false;

                WFMLogger.LogTraceInformation("Reordering wfm tickets list fields successful", WFMLogger.LogCategory.InfoLog);
            }
            catch (Exception e)
            {
                WFMLogger.LogTraceInformation("Error occured reordering wfmtickets list fields", WFMLogger.LogCategory.ErrorLog);
            }

        }

    }
}
