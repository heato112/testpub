﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using System.Data;
using Microsoft.SharePoint.Administration;

namespace WFM.Common
{
    public class ConfigurationSettings
    {
        private readonly static object _lock = new object();
        public static DataTable ConfigurationSettingsTable = null;
        //public static string MasterSiteURL = string.Empty;
        public static string MasterSiteURL = "";
       
        private const string SITEURL_KEY = "SiteUrl";
        private const string USER_PREFIX_KEY = "UserPrefix";
        private const string GROUP_PREFIX_KEY = "GroupPrefix";
        private const string PAGE_SIZE = "PageSize";
        private const string SMTP_SERVER = "smtpServer";
        private const string EMAIL_CC_ADDRESS = "EmailCCAddress";
        private const string ENABLE_NOTIFICATIONS = "EnableNotifications";
        private const string EMAIL_TO_ADDRESS = "EmailToAddress";
        private const string ENABLE_TRACE_LOG = "EnableTraceLog";
        private const string TRACE_LOG_CATEGORY = "TraceLogCategory";
        private const string SUPPORT_EMAIL = "SupportEmail";
        private const string REPORTS_DATA_ROW_LIMIT = "ReportsDataRowLimit";
        private const string WFM_TICKETS_REMOVAL_DURATION = "WFMTicketsRemovalDuration";
        private const string ENABLE_ERROR_NOTIFICATIONS = "EnableErrorNotifications";
        private const string USER_ID_COLUMN_NAME = "UserIDColumnName";

        public static string SiteUrl()
        {
            return getConfigurationSettingsValue(SITEURL_KEY);
        }

        public static string SiteUrl(SPWeb web)
        {
            return GetAppSettingsValue(SITEURL_KEY, web);
        }

        public static string UserPrefix()
        {
            return getConfigurationSettingsValue(USER_PREFIX_KEY);
        }

        public static string GroupPrefix()
        {
            return getConfigurationSettingsValue(GROUP_PREFIX_KEY);
        }

        public static string GroupPrefix(SPWeb web)
        {
            return GetAppSettingsValue(GROUP_PREFIX_KEY, web);
        }

        public static int PageSize()
        {
            return Convert.ToInt16(getConfigurationSettingsValue(PAGE_SIZE));
        }

        /// <summary>
        /// This method gets the value of key from Web.Config app setting.
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        private static string getConfigurationSettingsValue(string key)
        {
            string enviornment = NYLEnv.ENV;
            string connectionString = string.Empty;
            try
            {
                connectionString = GetConfigurationSettingFromTable(key, enviornment, null);
            }
            catch (Exception ex)
            {
                ExceptionHelper.HandleException(ex, ExceptionPolicy.BOExceptionPolicy);
            }
            return connectionString;
        }

        public static string getSmtpServer()
        {
            return getConfigurationSettingsValue(SMTP_SERVER);
        }

        public static string getWFMTicketsRemovalDuration()
        {
            return getConfigurationSettingsValue(WFM_TICKETS_REMOVAL_DURATION);
        }

        public static int getEnableErrorNotification()
        {
            int retVal = 0;
            if (!string.IsNullOrEmpty(getConfigurationSettingsValue(ENABLE_ERROR_NOTIFICATIONS)))
            {
                retVal = Convert.ToInt32(getConfigurationSettingsValue(ENABLE_ERROR_NOTIFICATIONS));
            }

            return retVal;
        }

        public static string getUserIDColumnName()
        {
            string retVal = "NYLUID";
            if (!string.IsNullOrEmpty(getConfigurationSettingsValue(USER_ID_COLUMN_NAME)))
            {
                retVal = getConfigurationSettingsValue(USER_ID_COLUMN_NAME);
            }

            return retVal;
        }


        public static string GetAppSettingsValue(String key, SPWeb web)
        {
            string enviornment = NYLEnv.ENV;
            SPWebApplication webApp = web.Site.WebApplication;
            return GetConfigurationSettingFromTable(key, enviornment, webApp);
        }

        public static string GetAppSettingsValue(String key, SPWebApplication webApp)
        {
            string enviornment = NYLEnv.ENV;
            return GetConfigurationSettingFromTable(key, enviornment, webApp);
        }

        public static string getEmailCcAddress()
        {
            return getConfigurationSettingsValue(EMAIL_CC_ADDRESS);
        }

        public static int getEnableNotification()
        {
            return Convert.ToInt32(getConfigurationSettingsValue(ENABLE_NOTIFICATIONS));
        }

        public static string GetTraceLogCategory()
        {
            return getConfigurationSettingsValue(TRACE_LOG_CATEGORY);
        }

        public static bool IsTraceLogEnabled()
        {
            string enableTraceLog = getConfigurationSettingsValue(ENABLE_TRACE_LOG);
            return enableTraceLog.Equals("true", StringComparison.OrdinalIgnoreCase);
        }

        public static string getSupportEmail()
        {
            return getConfigurationSettingsValue(SUPPORT_EMAIL);
        }

        public static int getReportsDataRowLimit()
        {
            return Convert.ToInt32(getConfigurationSettingsValue(REPORTS_DATA_ROW_LIMIT));
        }

        public static void GetConfigurationList()
        {
            // DO not write Log info here
            SPWebApplication masterWebApp = null;
            string _masterSiteUrl = string.Empty;

            // $$REVIEW: ADDED FOR RC
            _masterSiteUrl = MasterSiteURL;
            using (SPSite masterSite = new SPSite(_masterSiteUrl))
            {
                using (SPWeb masterWeb = masterSite.OpenWeb())
                {
                    SPList configurationList = masterWeb.Lists["Configuration Settings List"];
                    ConfigurationSettingsTable = ConvertSPListToDataTable(configurationList);
                }
            }
        }

        public static string GetConfigurationSettingFromTable(string key, string env, SPWebApplication spWebApp)
        {
            // DO not write Log info here
            string settingsValue = string.Empty;

            ConfigurationSettingsTable = null;
            if (ConfigurationSettingsTable == null)
            {
                lock (_lock)
                {
                    if (ConfigurationSettingsTable == null)
                        GetConfigurationList();
                }
            }

            string queryString = @"Title = '" + key + "' AND (SettingEnvironment = '" + env + "' OR  SettingEnvironment = 'default')";

            if (ConfigurationSettingsTable != null)
            {
                DataRow[] filteredDataTable = ConfigurationSettingsTable.Select(@queryString);
                foreach (DataRow dr in filteredDataTable)
                {

                    settingsValue = dr["SettingValue"].ToString();
                }
            }

            return settingsValue;
        }


        public static DataTable ConvertSPListToDataTable(SPList oList)
        {
            //*****DO NOT PUT TRACE LOG HERE IN THIS METHOD*****

            DataTable dt = new DataTable();

            try
            {

                if (oList.ItemCount > 0)
                {
                    dt = oList.Items.GetDataTable();
                    foreach (DataColumn c in dt.Columns)
                        c.ColumnName = System.Xml.XmlConvert.DecodeName(c.ColumnName);
                }

                return (dt);
            }
            catch
            {
                return (dt);
            }
        }
    }
}
