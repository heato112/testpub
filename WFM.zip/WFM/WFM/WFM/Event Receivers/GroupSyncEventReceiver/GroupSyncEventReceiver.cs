﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using WFM.Common;
using System.Data;

namespace WFM.Event_Receivers.GroupSyncEventReceiver
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class GroupSyncEventReceiver : SPItemEventReceiver
    {
       /// <summary>
       /// An item was added.
       /// </summary>
       public override void ItemAdded(SPItemEventProperties properties)
       {
           base.ItemAdded(properties);
           //DataTable allUsers = GroupSync.getAllManagers(properties.Web.Site.ID, properties.Web.ID);
           
           GroupSync.SyncUsers(properties.Web.Site.ID, properties.Web.ID,properties.ListItem);
       }


    }
}
