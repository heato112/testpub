﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Web.UI.WebControls.WebParts;
using System.Xml;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebPartPages;
using System.Text;

namespace WFM.Common
{
    public static class ViewHelper
    {
        #region List Views

        public static void CreateAllViews(Guid oSiteId, Guid oWebId)
        {
            CreateWFMStaffOpenTicketsView(oSiteId, oWebId);
            CreateWFMStaffClosedTicketsView(oSiteId, oWebId);
            CreateManagerTicketsView(oSiteId, oWebId);
            CreateManagerTeamMembersTicketsView(oSiteId, oWebId);
            CreateAgentOpenTicketsView(oSiteId, oWebId);
            CreateSearchByTicketNumberView(oSiteId, oWebId);
            CreateSearchByDateView(oSiteId, oWebId);
        }

        private static void CreateWFMStaffOpenTicketsView(Guid oSiteId, Guid oWebId) 
        {
            using (SPSite site = new SPSite(oSiteId))
            {
                using (SPWeb web = site.OpenWeb(oWebId))
                {
                    try
                    {
                        SPList ticketsList = web.Lists.TryGetList(Constants.ListName.WFM_TICKETS);
                        if (ticketsList != null)
                        {
                            StringCollection viewFields = new StringCollection();
                            viewFields.Add("AgentName");
                            viewFields.Add("Agent_x0020_Name_x003a__x0020_Ma1");
                            viewFields.Add("Ticket #");
                            viewFields.Add("Submitted Date");
                            viewFields.Add("Event Date");
                            viewFields.Add("Request Type");
                            viewFields.Add("WFM Team Member Name");
                            viewFields.Add("NotesDisplay");

                            string query = "<Where>" +
                                           "<Eq>" +
                                              "<FieldRef Name=\"Status\" />" +
                                              "<Value Type=\"Lookup\">Open</Value> " +
                                            "</Eq>" +
                                            "</Where>";

                            //ticketsList.Views.Add("WFMStaffOpenTicketsView", viewFields, query, 30, true, false);
                            ticketsList.Views.Add(Constants.TicketsListViewName.WFMSTAFF_OPEN_TICKETS_VIEW, viewFields, query, 30, true, false);
                            ticketsList.Update();
                            WFMLogger.LogTraceInformation("WFM Staff Open Tickets View Created Successfully", WFMLogger.LogCategory.InfoLog);
                        }
                    }
                    catch (Exception ex)
                    {
                        //WFMLogger.LogTraceInformation("Error occured while Creating WFM Staff Open Tickets View", WFMLogger.LogCategory.ErrorLog);
                        ExceptionHelper.HandleException(new Exception("Error occured while Creating WFM Staff Open Tickets View", ex), ExceptionPolicy.BOExceptionPolicy, true);
                    }
                }
            }
        }

        private static void CreateWFMStaffClosedTicketsView(Guid oSiteId, Guid oWebId)
        {
            using (SPSite site = new SPSite(oSiteId))
            {
                using (SPWeb web = site.OpenWeb(oWebId))
                {
                    try
                    {
                        SPList ticketsList = web.Lists.TryGetList(Constants.ListName.WFM_TICKETS);
                        if (ticketsList != null)
                        {
                            StringCollection viewFields = new StringCollection();
                            viewFields.Add("AgentName");
                            viewFields.Add("Agent_x0020_Name_x003a__x0020_Ma1");
                            viewFields.Add("Ticket #");
                            viewFields.Add("Submitted Date");
                            viewFields.Add("Event Date");
                            viewFields.Add("Status");
                            viewFields.Add("Request Type");
                            viewFields.Add("WFM Team Member Name");
                            viewFields.Add("NotesDisplay");

                            string query = "<Where>" +
                                           "<And>" +
                                              "<Geq>" +
                                              "<FieldRef Name=\"Modified\" />" +
                                              "<Value Type=\"DateTime\"><Today OffsetDays=\"-6\"/></Value> " +
                                            "</Geq>" +
                                               "<Neq>" +
                                                  "<FieldRef Name=\"Status\" />" +
                                                  "<Value Type=\"Lookup\">Open</Value> " +
                                                "</Neq>" +
                                            "</And>" +
                                            "</Where>";

                            //ticketsList.Views.Add("WFMStaffClosedTicketsView", viewFields, query, 30, true, false);
                            ticketsList.Views.Add(Constants.TicketsListViewName.WFMSTAFF_CLOSED_TICKETS_VIEW, viewFields, query, 30, true, false);
                            ticketsList.Update();
                            WFMLogger.LogTraceInformation("WFM Staff Closed Tickets View Created Successfully", WFMLogger.LogCategory.InfoLog);
                        }
                    }
                    catch (Exception ex)
                    {
                        //WFMLogger.LogTraceInformation("Error occured while Creating WFM Staff Closed Tickets View", WFMLogger.LogCategory.ErrorLog);
                        ExceptionHelper.HandleException(new Exception("Error occured while Creating WFM Staff Closed Tickets View", ex), ExceptionPolicy.BOExceptionPolicy, true);
                    }
                }
            }
        }

        private static void CreateManagerTicketsView(Guid oSiteId, Guid oWebId)
        {
            using (SPSite site = new SPSite(oSiteId))
            {
                using (SPWeb web = site.OpenWeb(oWebId))
                {
                    try
                    {
                        SPList ticketsList = web.Lists.TryGetList(Constants.ListName.WFM_TICKETS);
                        if (ticketsList != null)
                        {
                            StringCollection viewFields = new StringCollection();
                            viewFields.Add("AgentName");
                            viewFields.Add("Agent_x0020_Name_x003a__x0020_Ma1");
                            viewFields.Add("Ticket #");
                            viewFields.Add("Submitted Date");
                            viewFields.Add("Event Date");
                            viewFields.Add("Status");
                            viewFields.Add("Request Type");
                            viewFields.Add("CommentsDisplay");
                            //viewFields.Add("NotesDisplay");

                            string query = "<Where>" +
                                            "<And>" +
                                            "<Eq>" +
                                              "<FieldRef Name=\"Author\" />" +
                                              "<Value Type=\"User\">[Me]</Value> " +
                                            "</Eq>" +
                                            "<Geq>" +
                                              "<FieldRef Name=\"Modified\" />" +
                                              "<Value Type=\"DateTime\"><Today OffsetDays=\"-6\"/></Value> " +
                                            "</Geq>" +
                                            "</And>" +
                                            "</Where>" +
                                            "<OrderBy>" +
                                                "<FieldRef Name=\"Status\" Ascending=\"False\"/>" +
                                                "<FieldRef Name=\"Created\" Ascending=\"False\"/>" +
                                            "</OrderBy>";

                            //ticketsList.Views.Add("ManagerTicketsView", viewFields, query, 30, true, false);
                            ticketsList.Views.Add(Constants.TicketsListViewName.MANAGER_TICKETS_VIEW, viewFields, query, 30, true, false);
                            ticketsList.Update();
                            WFMLogger.LogTraceInformation("Manager Tickets View Created Successfully", WFMLogger.LogCategory.InfoLog);
                        }
                    }
                    catch (Exception ex)
                    {
                        //WFMLogger.LogTraceInformation("Error occured while Creating Manager Tickets View", WFMLogger.LogCategory.ErrorLog);
                        ExceptionHelper.HandleException(new Exception("Error occured while Creating Manager Tickets View", ex), ExceptionPolicy.BOExceptionPolicy, true);
                    }
                }
            }
        }

        private static void CreateManagerTeamMembersTicketsView(Guid oSiteId, Guid oWebId)
        {
            using (SPSite site = new SPSite(oSiteId))
            {
                using (SPWeb web = site.OpenWeb(oWebId))
                {
                    try
                    {
                        SPList ticketsList = web.Lists.TryGetList(Constants.ListName.WFM_TICKETS);
                        if (ticketsList != null)
                        {
                            StringCollection viewFields = new StringCollection();
                            viewFields.Add("AgentName");
                            viewFields.Add("Agent_x0020_Name_x003a__x0020_Ma1");
                            viewFields.Add("Ticket #");
                            viewFields.Add("Submitted Date");
                            viewFields.Add("Event Date");
                            viewFields.Add("Status");
                            viewFields.Add("Request Type");
                            viewFields.Add("CommentsDisplay");
                            //viewFields.Add("NotesDisplay");

                            string query = "<Where>" +
                                            "<Geq>" +
                                              "<FieldRef Name=\"Modified\" />" +
                                              "<Value Type=\"DateTime\"><Today OffsetDays=\"-6\"/></Value> " +
                                            "</Geq>" +
                                            "</Where>" +
                                            "<OrderBy>" +
                                                "<FieldRef Name=\"Status\" Ascending=\"False\"/>" +
                                                "<FieldRef Name=\"Created\" Ascending=\"False\"/>" +
                                            "</OrderBy>";

                            //ticketsList.Views.Add("ManagerTeamMembersTicketsView", viewFields, query, 30, true, false);
                            ticketsList.Views.Add(Constants.TicketsListViewName.MANAGER_TEAM_MEMBERS_TICKETS_VIEW, viewFields, query, 30, true, false);
                            ticketsList.Update();
                            WFMLogger.LogTraceInformation("Manager Team Members Tickets View Created Successfully", WFMLogger.LogCategory.InfoLog);
                        }
                    }
                    catch (Exception ex)
                    {
                        //WFMLogger.LogTraceInformation("Error occured while Creating Manager Team Members Tickets View", WFMLogger.LogCategory.ErrorLog);
                        ExceptionHelper.HandleException(new Exception("Error occured while Creating Manager Team Members Tickets View", ex), ExceptionPolicy.BOExceptionPolicy, true);
                    }
                }
            }
        }

        private static void CreateAgentOpenTicketsView(Guid oSiteId, Guid oWebId)
        {
            using (SPSite site = new SPSite(oSiteId))
            {
                using (SPWeb web = site.OpenWeb(oWebId))
                {
                    try
                    {
                        SPList ticketsList = web.Lists.TryGetList(Constants.ListName.WFM_TICKETS);
                        if (ticketsList != null)
                        {
                            StringCollection viewFields = new StringCollection();
                            viewFields.Add("AgentName");
                            viewFields.Add("Agent_x0020_Name_x003a__x0020_Ma1");
                            viewFields.Add("Ticket #");
                            viewFields.Add("Submitted Date");
                            viewFields.Add("Event Date"); 
                            viewFields.Add("Status");
                            viewFields.Add("Request Type");
                            viewFields.Add("CommentsDisplay");

                            string query = "<Where>" +
                                            "</Where>" +
                                            "<OrderBy>" +
                                                "<FieldRef Name=\"Status\" Ascending=\"False\"/>" +
                                                "<FieldRef Name=\"Created\" Ascending=\"False\"/>" +
                                            "</OrderBy>";

                            //SPView view = ticketsList.Views.Add("AgentOpenTicketsView", viewFields, query, 30, true, false);
                            SPView view = ticketsList.Views.Add(Constants.TicketsListViewName.AGENT_OPEN_TICKETS_VIEW, viewFields, query, 30, true, false);
                            ticketsList.Update();
                            WFMLogger.LogTraceInformation("Agent Open Tickets View Created Successfully", WFMLogger.LogCategory.InfoLog);
                        }
                    }
                    catch (Exception ex)
                    {
                        //WFMLogger.LogTraceInformation("Error occured while Creating Agent Open Tickets View", WFMLogger.LogCategory.ErrorLog);
                        ExceptionHelper.HandleException(new Exception("Error occured while Creating Agent Open Tickets View", ex), ExceptionPolicy.BOExceptionPolicy, true);
                    }
                }
            }
        }

        private static void CreateSearchByTicketNumberView(Guid oSiteId, Guid oWebId)
        {
            using (SPSite site = new SPSite(oSiteId))
            {
                using (SPWeb web = site.OpenWeb(oWebId))
                {
                    try
                    {
                        SPList ticketsList = web.Lists.TryGetList(Constants.ListName.WFM_TICKETS);
                        if (ticketsList != null)
                        {
                            StringCollection viewFields = new StringCollection();
                            viewFields.Add("AgentName");
                            viewFields.Add("Agent_x0020_Name_x003a__x0020_Ma1");
                            viewFields.Add("Ticket #");
                            viewFields.Add("Submitted Date");
                            viewFields.Add("Event Date");
                            viewFields.Add("Status");
                            viewFields.Add("Request Type");
                            viewFields.Add("WFM Team Member Name");
                            viewFields.Add("NotesDisplay");

                            string query = "";

                            //ticketsList.Views.Add("WFMStaffClosedTicketsView", viewFields, query, 30, true, false);
                            ticketsList.Views.Add(Constants.TicketsListViewName.SEARCH_BY_TICKET_NUMBER_VIEW, viewFields,query, 30, true, false);
                            ticketsList.Update();
                            WFMLogger.LogTraceInformation("Search by ticket number View Created Successfully",WFMLogger.LogCategory.InfoLog);
                        }
                    }
                    catch (Exception ex)
                    {
                        //WFMLogger.LogTraceInformation("Error occured while Creating Search by ticket number View",WFMLogger.LogCategory.ErrorLog);
                        ExceptionHelper.HandleException(new Exception("Error occured while Creating Search by ticket number View", ex), ExceptionPolicy.BOExceptionPolicy, true);
                    }
                }
            }
        }

        private static void CreateSearchByDateView(Guid oSiteId, Guid oWebId)
        {
            using (SPSite site = new SPSite(oSiteId))
            {
                using (SPWeb web = site.OpenWeb(oWebId))
                {
                    try
                    {
                        SPList ticketsList = web.Lists.TryGetList(Constants.ListName.WFM_TICKETS);
                        if (ticketsList != null)
                        {
                            StringCollection viewFields = new StringCollection();
                            viewFields.Add("AgentName");
                            viewFields.Add("Agent_x0020_Name_x003a__x0020_Ma1");
                            viewFields.Add("Ticket #");
                            viewFields.Add("Submitted Date");
                            viewFields.Add("Event Date");
                            viewFields.Add("Status");
                            viewFields.Add("Request Type");
                            viewFields.Add("WFM Team Member Name");
                            viewFields.Add("NotesDisplay");

                            //string query = "";
                            string query = "<Where>" +
                              "<And Group=\"true\">" +
                                  "<Geq>" +
                                      "<FieldRef Name=\"Created\"/>" +
                                      "<Value Type=\"DateTime\">{StartDate}</Value>" +
                                  "</Geq>" +
                                  "<Leq>" +
                                      "<FieldRef Name=\"Created\"/>" +
                                      "<Value Type=\"DateTime\">{EndDate}</Value> " +
                                  "</Leq>" +
                              "</And>" +
                          "</Where>";


                            //ticketsList.Views.Add("WFMStaffClosedTicketsView", viewFields, query, 30, true, false);
                            ticketsList.Views.Add(Constants.TicketsListViewName.SEARCH_BY_DATE_VIEW, viewFields, query, 30, true, false);
                            ticketsList.Update();
                            WFMLogger.LogTraceInformation("Search by ticket number View Created Successfully", WFMLogger.LogCategory.InfoLog);
                        }
                    }
                    catch (Exception ex)
                    {
                        //WFMLogger.LogTraceInformation("Error occured while Creating Search by ticket number View", WFMLogger.LogCategory.ErrorLog);
                        ExceptionHelper.HandleException(new Exception("Error occured while Creating Search by ticket number View", ex), ExceptionPolicy.BOExceptionPolicy, true);
                    }
                }
            }
        }

        public static void DeleteViews(Guid oSiteId, Guid oWebId)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(oSiteId))
                {
                    using (SPWeb web = site.OpenWeb(oWebId))
                    {
                        SPList list = web.Lists.TryGetList("WFMTickets");
                        List<Guid> Ids = new List<Guid>();
                        SPViewCollection oViewCollection = list.Views;
                        foreach (SPView view in oViewCollection)
                        {
                            //if (view.Title.Equals("WFMStaffOpenTicketsView") || view.Title.Equals("WFMStaffClosedTicketsView") || view.Title.Equals("AgentOpenTicketsView") ||
                            //    view.Title.Equals("ManagerTicketsView") || view.Title.Equals("ManagerTeamMembersTicketsView"))
                            if (view.Title.Equals(Constants.TicketsListViewName.WFMSTAFF_OPEN_TICKETS_VIEW) || view.Title.Equals(Constants.TicketsListViewName.WFMSTAFF_CLOSED_TICKETS_VIEW) || view.Title.Equals(Constants.TicketsListViewName.AGENT_OPEN_TICKETS_VIEW) ||
                                view.Title.Equals(Constants.TicketsListViewName.MANAGER_TICKETS_VIEW) || view.Title.Equals(Constants.TicketsListViewName.MANAGER_TEAM_MEMBERS_TICKETS_VIEW) || view.Title.Equals(Constants.TicketsListViewName.SEARCH_BY_DATE_VIEW) ||  view.Title.Equals(Constants.TicketsListViewName.SEARCH_BY_TICKET_NUMBER_VIEW))
                            {
                                Ids.Add(view.ID);
                            }
                        }
                        foreach (Guid id in Ids)
                        {
                            try
                            {
                                oViewCollection.Delete(id);
                            }
                            catch (Exception ex)
                            {
                                //WFMLogger.LogTraceInformation(string.Format("Error occured while Deleting View: {0}", id.ToString()), WFMLogger.LogCategory.ErrorLog);
                                ExceptionHelper.HandleException(new Exception(string.Format("Error occured while Deleting View: {0}", id.ToString()), ex), ExceptionPolicy.BOExceptionPolicy, true);
                            }
                        }
                    }
                }
            });
        }

        private static bool isListViewExists(SPList list, string viewName)
        {
            bool isPresent = false;
            //isPresent = list.Views.Cast(SPView).Any(view => string.Equals(view.Title, viewName));
            return isPresent;
        }

        #endregion

        #region Setup WebParts

        public static void SetupAllWebParts(Guid oSiteId, Guid oWebId)
        {
            setupWFMStaffWebPartPage(oSiteId, oWebId);
            setupManagerWebPartPage(oSiteId, oWebId);
            setupAgentWebPartPage(oSiteId, oWebId);
            setupSearchWebPartPage(oSiteId, oWebId);
        }

        private static void setupWFMStaffWebPartPage(Guid oSiteId, Guid oWebId)
        {
            addListViewWebPart(oSiteId, oWebId, "Libraries/LandingPages/WFMStaffHome.aspx", Constants.TicketsListViewName.WFMSTAFF_OPEN_TICKETS_VIEW, Constants.LandingPagesWebPartsTitle.WFMSTAFF_OPEN_TICKETS_WEBPART, 0, false, null);
            addListViewWebPart(oSiteId, oWebId, "Libraries/LandingPages/WFMStaffHome.aspx", Constants.TicketsListViewName.WFMSTAFF_CLOSED_TICKETS_VIEW, Constants.LandingPagesWebPartsTitle.WFMSTAFF_CLOSED_TICKETS_WEBPART, 1, false, null);
        }

        private static void setupManagerWebPartPage(Guid oSiteId, Guid oWebId)
        {
            addListViewWebPart(oSiteId, oWebId, "Libraries/LandingPages/ManagerHome.aspx", Constants.TicketsListViewName.MANAGER_TICKETS_VIEW, Constants.LandingPagesWebPartsTitle.MANAGER_TICKETS_WEBPART, 0, false, null);
            addListViewWebPart(oSiteId, oWebId, "Libraries/LandingPages/ManagerHome.aspx", Constants.TicketsListViewName.MANAGER_TEAM_MEMBERS_TICKETS_VIEW, Constants.LandingPagesWebPartsTitle.MANAGER_TEAM_MEMBER_TICKETS_WEBPART, 1, false, null);
        }

        private static void setupAgentWebPartPage(Guid oSiteId, Guid oWebId)
        {
            addListViewWebPart(oSiteId, oWebId, "Libraries/LandingPages/AgentHome.aspx", Constants.TicketsListViewName.AGENT_OPEN_TICKETS_VIEW, Constants.LandingPagesWebPartsTitle.AGENT_TICKETS_WEBPART, 0, false, null);
        }

        private static void setupSearchWebPartPage(Guid oSiteId, Guid oWebId)
        {
            string parameters = "<ParameterBinding Name=\"dvt_sortdir\" Location=\"Postback;Connection\" />" +
                                    "<ParameterBinding Name=\"dvt_sortfield\" Location=\"Postback;Connection\" />" +
                                    "<ParameterBinding Name=\"dvt_startposition\" Location=\"Postback\" DefaultValue=\"\" />" +
                                    "<ParameterBinding Name=\"dvt_firstrow\" Location=\"Postback;Connection\" />" +
                                    "<ParameterBinding Name=\"OpenMenuKeyAccessible\" Location=\"Resource(wss,OpenMenuKeyAccessible)\" />" +
                                    "<ParameterBinding Name=\"open_menu\" Location=\"Resource(wss,open_menu)\" />" +
                                    "<ParameterBinding Name=\"select_deselect_all\" Location=\"Resource(wss,select_deselect_all)\" />" +
                                    "<ParameterBinding Name=\"idPresEnabled\" Location=\"Resource(wss,idPresEnabled)\" />" +
                                    "<ParameterBinding Name=\"NoAnnouncements\" Location=\"Resource(wss,noXinviewofY_LIST)\" />" +
                                    "<ParameterBinding Name=\"NoAnnouncementsHowTo\" Location=\"Resource(wss,noXinviewofY_DEFAULT)\"/>" +
                                    "<ParameterBinding Name=\"StartDate\" Location=\"None\" DefaultValue=\"\" />" +
                                    "<ParameterBinding Name=\"EndDate\" Location=\"None\" DefaultValue=\"\" />";

            addListViewWebPart(oSiteId, oWebId, "SearchPages/searchnumber.aspx", Constants.TicketsListViewName.SEARCH_BY_TICKET_NUMBER_VIEW, Constants.LandingPagesWebPartsTitle.SEARCH_TICKETS_WEBPART, 0, true, null);
            addListViewWebPart(oSiteId, oWebId, "SearchPages/searchdate.aspx", Constants.TicketsListViewName.SEARCH_BY_DATE_VIEW, Constants.LandingPagesWebPartsTitle.SEARCH_TICKETS_WEBPART, 0, true, parameters);
        }

        private static void addListViewWebPart(Guid oSiteId, Guid oWebId, string pageUrl, string viewName, string webPartTitle, int webPartIndex, bool asyncRefresh, string parameterBindings)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(oSiteId))
                {
                    using (SPWeb web = site.OpenWeb(oWebId))
                    {
                        try
                        {
                            SPFile page = web.GetFile(pageUrl);
                            SPList list = web.Lists.TryGetList(Constants.ListName.WFM_TICKETS);
                            using (SPLimitedWebPartManager wpmgr = page.GetLimitedWebPartManager(PersonalizationScope.Shared))
                            {
                                XsltListViewWebPart lvwp = new XsltListViewWebPart();
                                lvwp.ListId = list.ID;
                                lvwp.ViewGuid = list.Views[viewName].ID.ToString("B").ToUpper(CultureInfo.InvariantCulture);
                                lvwp.Description = list.Description;
                                lvwp.Title = webPartTitle;
                                lvwp.AsyncRefresh = asyncRefresh;
                                lvwp.ManualRefresh = asyncRefresh;
                                lvwp.ChromeType = PartChromeType.TitleAndBorder;
                                //lvwp.Toolbar = "No Toolbar";
                                SetToolbar(lvwp, "None");

                                if (!string.IsNullOrEmpty(parameterBindings))
                                {
                                    lvwp.ParameterBindings = parameterBindings;
                                }
                               
                                 wpmgr.AddWebPart(lvwp, "Header", webPartIndex);
                                
                                //wpmgr.SaveChanges(lvwp);
                            }
                        }
                        catch (Exception ex)
                        {
                            //WFMLogger.LogTraceInformation(string.Format("Error occured while adding View WebPart for View: {0}", viewName), WFMLogger.LogCategory.ErrorLog);
                            ExceptionHelper.HandleException(new Exception(string.Format("Error occured while adding View WebPart for View: {0}", viewName), ex), ExceptionPolicy.BOExceptionPolicy, true);
                        }
                    }
                }
            });
        }

       


        //Method to Set the Tool bar type 
        public static void SetToolbarType(SPView spView, String toolBarType)
        {
            spView.GetType().InvokeMember("EnsureFullBlownXmlDocument", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.InvokeMethod, null, spView, null, System.Globalization.CultureInfo.CurrentCulture);

            System.Reflection.PropertyInfo nodeProp = spView.GetType().GetProperty("Node", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            XmlNode node = nodeProp.GetValue(spView, null) as XmlNode;
            XmlNode toolbarNode = node.SelectSingleNode("Toolbar");

            if (toolbarNode != null)
            {
                toolbarNode.Attributes["Type"].Value = toolBarType;

                // If the toolbartype is Freeform (i.e. Summary Toolbar) then we need to manually  
                // add some CAML to get it to work. 
                if (String.Compare(toolBarType, "Freeform", true, System.Globalization.CultureInfo.InvariantCulture) == 0)
                {
                    string newItemString = "";
                    XmlAttribute positionNode = toolbarNode.OwnerDocument.CreateAttribute("Position");
                    positionNode.Value = "After";
                    toolbarNode.Attributes.Append(positionNode);

                    switch (spView.ParentList.BaseTemplate)
                    {
                        case SPListTemplateType.Announcements:
                            newItemString = "announcement";
                            break;
                        case SPListTemplateType.Events:
                            newItemString = "event";
                            break;
                        case SPListTemplateType.Tasks:
                            newItemString = "task";
                            break;
                        case SPListTemplateType.DiscussionBoard:
                            newItemString = "discussion";
                            break;
                        case SPListTemplateType.Links:
                            newItemString = "link";
                            break;
                        case SPListTemplateType.GenericList:
                            newItemString = "item";
                            break;
                        case SPListTemplateType.DocumentLibrary:
                            newItemString = "document";
                            break;
                        default:
                            newItemString = "item";
                            break;
                    }

                    if (spView.ParentList.BaseType == SPBaseType.DocumentLibrary)
                    {
                        newItemString = "document";
                    }

                    // Add the CAML 
                    toolbarNode.InnerXml = @"<IfHasRights><RightsChoices><RightsGroup PermAddListItems=""required"" /></RightsChoices><Then><HTML><![CDATA[ <table width=100% cellpadding=0 cellspacing=0 border=0 > <tr> <td colspan=""2"" class=""ms-partline""><IMG   src=""/_layouts/images/blank.gif"" width=1 height=1 alt=""""></td> </tr> <tr> <td class=""ms-addnew"" style=""padding-bottom: 3px""> <img src=""/_layouts/images/rect.gif"" alt="""">&nbsp;<a class=""ms-addnew"" ID=""idAddNewItem"" href=""]]></HTML><URL Cmd=""New"" /><HTML><![CDATA["" ONCLICK=""BLOCKED SCRIPTNewItem(']]></HTML><URL Cmd=""New"" /><HTML><![CDATA[', true);BLOCKED SCRIPTreturn false;"" target=""_self"">]]></HTML><HTML>Add new " + newItemString + @"</HTML><HTML><![CDATA[</a> </td> </tr> <tr><td><IMG src=""/_layouts/images/blank.gif"" width=1 height=5 alt=""""></td></tr> </table>]]></HTML></Then></IfHasRights>";
                }

                spView.Update();

            }
        }

        public static void SetToolbar(XsltListViewWebPart lvwp, string toolBarType)
        {
            MethodInfo ensureViewMethod = lvwp.GetType().GetMethod("EnsureView", BindingFlags.Instance | BindingFlags.NonPublic);
            object[] ensureViewParams = { };
            ensureViewMethod.Invoke(lvwp, ensureViewParams);
            FieldInfo viewFieldInfo = lvwp.GetType().GetField("view", BindingFlags.NonPublic | BindingFlags.Instance);
            SPView spView = viewFieldInfo.GetValue(lvwp) as SPView;
            Type[] toolbarMethodParamTypes = { Type.GetType("System.String") };
            MethodInfo setToolbarTypeMethod = spView.GetType().GetMethod("SetToolbarType", BindingFlags.Instance | BindingFlags.NonPublic, null, toolbarMethodParamTypes, null);
            //object[] setToolbarParam = { "None" };
            object[] setToolbarParam = { toolBarType };
            setToolbarTypeMethod.Invoke(spView, setToolbarParam);
            
        }

        #endregion

        #region Connect WebParts

        public static void ConnectAllWebParts(Guid oSiteId, Guid oWebId)
        {
            connectWebParts(oSiteId, oWebId, "Libraries/LandingPages/AgentHome.aspx", "Text Filter", Constants.LandingPagesWebPartsTitle.AGENT_TICKETS_WEBPART, "Text Filter", "AgentACF2ID");
            connectWebParts(oSiteId, oWebId, "Libraries/LandingPages/ManagerHome.aspx", "Text Filter", Constants.LandingPagesWebPartsTitle.MANAGER_TEAM_MEMBER_TICKETS_WEBPART, "Text Filter", "ManagerACF2ID");
            connectWebParts(oSiteId, oWebId, "SearchPages/searchnumber.aspx", "Ticket Number",Constants.LandingPagesWebPartsTitle.SEARCH_TICKETS_WEBPART, "Ticket Number", "TicketNumber");
            connectWebParts(oSiteId, oWebId, "SearchPages/searchnumber.aspx", "Agent ACF2ID", Constants.LandingPagesWebPartsTitle.SEARCH_TICKETS_WEBPART, "Agent ACF2ID", "AgentACF2ID");
            connectWebPartsUsingParameters(oSiteId, oWebId, "SearchPages/searchdate.aspx", "Start Date", Constants.LandingPagesWebPartsTitle.SEARCH_TICKETS_WEBPART, "StartDate", "StartDate");
            connectWebPartsUsingParameters(oSiteId, oWebId, "SearchPages/searchdate.aspx", "End Date", Constants.LandingPagesWebPartsTitle.SEARCH_TICKETS_WEBPART, "EndDate", "EndDate");
        }

        private static void connectWebParts(Guid oSiteId, Guid oWebId, string pageUrl, string providerWebPartTitle, string consumerWebPartTitle, string providerFieldName, string consumerFieldName)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(oSiteId))
                {
                    using (SPWeb web = site.OpenWeb(oWebId))
                    {
                        try
                        {
                            SPFile page = web.GetFile(pageUrl);
                            SPList list = web.Lists.TryGetList("WFMTickets");
                            using (SPLimitedWebPartManager wpmgr = page.GetLimitedWebPartManager(PersonalizationScope.Shared))
                            {
                                Microsoft.SharePoint.WebPartPages.WebPart providerPart = (from Microsoft.SharePoint.WebPartPages.WebPart w in wpmgr.WebParts where w.Title == providerWebPartTitle select w).FirstOrDefault();
                                Microsoft.SharePoint.WebPartPages.WebPart consumerPart = (from Microsoft.SharePoint.WebPartPages.WebPart w in wpmgr.WebParts where w.Title == consumerWebPartTitle select w).FirstOrDefault();

                                var cc = wpmgr.GetConsumerConnectionPoints(consumerPart);
                                var pp = wpmgr.GetProviderConnectionPoints(providerPart);
                                var transformer = new TransformableFilterValuesToParametersTransformer();
                               
                                transformer.ConsumerFieldNames = new string[] { consumerFieldName };
                                transformer.ProviderFieldNames = new string[] { providerFieldName };

                                ConsumerConnectionPoint consumerConnection = null;
                                foreach (ConsumerConnectionPoint cpoint in cc)
                                {
                                    if (cpoint.InterfaceType == typeof(IWebPartParameters))
                                        consumerConnection = cpoint;
                                }
                                ProviderConnectionPoint providerConnection = null;
                                foreach (ProviderConnectionPoint ppoint in pp)
                                {
                                    if (ppoint.InterfaceType == typeof(ITransformableFilterValues))
                                        providerConnection = ppoint;
                                }

                                var conn = wpmgr.SPConnectWebParts(providerPart, providerConnection, consumerPart, consumerConnection, transformer);
                                wpmgr.SPWebPartConnections.Add(conn);
                            }
                        }
                        catch (Exception ex)
                        {
                            //WFMLogger.LogTraceInformation(string.Format("Error occured while connecting WebParts on Page: {0}", pageUrl), WFMLogger.LogCategory.ErrorLog);
                            ExceptionHelper.HandleException(new Exception(string.Format("Error occured while connecting WebParts on Page: {0}", pageUrl), ex), ExceptionPolicy.BOExceptionPolicy, true);
                        }

                    }
                }
            });
        }

        private static void connectWebPartsUsingParameters(Guid oSiteId, Guid oWebId, string pageUrl, string providerWebPartTitle, string consumerWebPartTitle, string providerFieldName, string consumerFieldName)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(oSiteId))
                {
                    using (SPWeb web = site.OpenWeb(oWebId))
                    {
                        try
                        {
                            SPFile page = web.GetFile(pageUrl);
                            SPList list = web.Lists.TryGetList("WFMTickets");
                            using (SPLimitedWebPartManager wpmgr = page.GetLimitedWebPartManager(PersonalizationScope.Shared))
                            {
                                Microsoft.SharePoint.WebPartPages.WebPart providerPart = (from Microsoft.SharePoint.WebPartPages.WebPart w in wpmgr.WebParts where w.Title == providerWebPartTitle select w).FirstOrDefault();
                                Microsoft.SharePoint.WebPartPages.WebPart consumerPart = (from Microsoft.SharePoint.WebPartPages.WebPart w in wpmgr.WebParts where w.Title == consumerWebPartTitle select w).FirstOrDefault();

                                var cc = wpmgr.GetConsumerConnectionPoints(consumerPart);
                                var pp = wpmgr.GetProviderConnectionPoints(providerPart);
                                var transformer = new TransformableFilterValuesToParametersTransformer();
                               
                                transformer.ConsumerFieldNames = new string[] { consumerFieldName };
                                transformer.ProviderFieldNames = new string[] { providerFieldName };

                                string consumerConnectionId = "DFWP Parameter Consumer ID" ;

                               ConsumerConnectionPoint consumerConnection = (from ConsumerConnectionPoint conn in wpmgr.GetConsumerConnectionPoints(consumerPart)
                                    where conn.ID == consumerConnectionId
                                    select conn).FirstOrDefault();

                                ProviderConnectionPoint providerConnection = null;
                                foreach (ProviderConnectionPoint ppoint in pp)
                                {
                                    if (ppoint.InterfaceType == typeof(ITransformableFilterValues))
                                        providerConnection = ppoint;
                                }

                                var connect = wpmgr.SPConnectWebParts(providerPart, providerConnection, consumerPart, consumerConnection, transformer);
                                wpmgr.SPWebPartConnections.Add(connect);
                            }
                        }
                        catch (Exception ex)
                        {
                            //WFMLogger.LogTraceInformation(string.Format("Error occured while connecting WebParts on Page: {0}", pageUrl), WFMLogger.LogCategory.ErrorLog);
                            ExceptionHelper.HandleException(new Exception(string.Format("Error occured while connecting WebParts on Page: {0}", pageUrl), ex), ExceptionPolicy.BOExceptionPolicy, true);
                        }

                    }
                }
            });
        }

        #endregion

        #region General

        public static string GetTruncatedText(string columnValue)
        {
            if (columnValue.Length > 50)
            {
                columnValue = string.Concat(columnValue.Substring(0, 50), "...");
            }
            return columnValue;
        }

        #endregion
    }
}
