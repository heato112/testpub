using System;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebPartPages;
using WFM.Common;

namespace WFM.Features.WFM_Provision_Views
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("e767dd35-71d8-4088-b36b-9953f1888d6e")]
    public class WFM_Provision_ViewsEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            try{
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                SPWeb oWeb = (SPWeb)properties.Feature.Parent;
                if (oWeb != null)
                {
                    ViewHelper.CreateAllViews(oWeb.Site.ID, oWeb.ID);
                    ViewHelper.SetupAllWebParts(oWeb.Site.ID, oWeb.ID);
                    ViewHelper.ConnectAllWebParts(oWeb.Site.ID, oWeb.ID);
                }
            });
            WFMLogger.LogTraceInformation("Activating Feature Provision Views successful", WFMLogger.LogCategory.InfoLog);
            }
            catch (Exception e)
            {
                ExceptionHelper.HandleException(new Exception("Error occured activating Provision Views feature", e), ExceptionPolicy.BOExceptionPolicy, true);
            }

        }

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            try{
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                SPWeb oWeb = (SPWeb)properties.Feature.Parent;
                if (oWeb != null)
                {
                    ViewHelper.DeleteViews(oWeb.Site.ID, oWeb.ID);
                }
            });
            WFMLogger.LogTraceInformation("Deactivating Feature Provision Views successful", WFMLogger.LogCategory.InfoLog);
            }
            catch (Exception e)
            {
                ExceptionHelper.HandleException(new Exception("Error occured deactivating Provision Views feature", e), ExceptionPolicy.BOExceptionPolicy, true);
            }
        }
    }
}
