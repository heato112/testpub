using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.Navigation;
using WFM.Common;
using NYL.WFM.Common;

namespace WFM.Features.WFM_Provision_Master_Page
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("e181d418-bd54-49eb-b3b0-e46a3f849f5e")]
    public class WFM_Provision_Master_PageEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSite featureSite = properties.Feature.Parent as SPSite;
            using (SPSite site = new SPSite(featureSite.ID))
            {
                using (SPWeb web = site.OpenWeb())
                {
                    try
                    {
                        // CREATE MASTER PAGE URL
                        Uri masterPageUri = new Uri(string.Concat(web.Url, "/_catalogs/masterpage/MasterPage/WFM.master"));

                        // SET MASTER PAGE
                        web.MasterUrl = masterPageUri.AbsolutePath;
                        web.CustomMasterUrl = masterPageUri.AbsolutePath;

                        web.Update();

                        //Add Configuration List Key 
                        PropertyBagHelper.AddProperty(web, "mastersiteurl", web.Url);

                        if (site.Features[new Guid("f6924d36-2fa8-4f0b-b16d-06b7250180fa")] == null)
                        {
                            site.Features.Add(new Guid("f6924d36-2fa8-4f0b-b16d-06b7250180fa"));
                        }

                        WFMLogger.LogTraceInformation("Activating master page feature  successful", WFMLogger.LogCategory.InfoLog);
                    }
                    catch (Exception e)
                    {
                        //WFMLogger.LogTraceInformation("Error occured activating master page feature ", WFMLogger.LogCategory.ErrorLog);
                        ExceptionHelper.HandleException(new Exception("Error occured activating master page feature", e), ExceptionPolicy.BOExceptionPolicy, true);
                    }
                }
            }
        }


        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPSite featureSite = properties.Feature.Parent as SPSite;
            using (SPSite site = new SPSite(featureSite.ID))
            {
                using (SPWeb web = site.OpenWeb())
                {
                    try
                    {
                        // CREATE MASTER PAGE URL
                        Uri masterPageUri = new Uri(string.Concat(web.Url, "/_catalogs/masterpage/v4.master"));

                        // SET MASTER PAGE
                        web.MasterUrl = masterPageUri.AbsolutePath;
                        web.CustomMasterUrl = masterPageUri.AbsolutePath;

                        web.Update();

                        WFMLogger.LogTraceInformation("Deactivating master page feature  successful", WFMLogger.LogCategory.InfoLog);
                    }
                    catch (Exception e)
                    {
                        //WFMLogger.LogTraceInformation("Error occured deactivating master page feature ", WFMLogger.LogCategory.ErrorLog);
                        ExceptionHelper.HandleException(new Exception("Error occured deactivating master page feature", e), ExceptionPolicy.BOExceptionPolicy, true);
                    }
                }
            }
        }

    }
}
