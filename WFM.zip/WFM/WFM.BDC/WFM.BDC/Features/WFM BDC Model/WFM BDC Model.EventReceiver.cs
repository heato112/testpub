using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.Office.SharePoint.ClientExtensions;
using Microsoft.SharePoint.Administration;
using Microsoft.Office.SharePoint.ClientExtensions.Deployment;

namespace WFM.BDC.Features.WFM_BDC_Model
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("8286ce2e-bc04-4325-bf02-f7acaddbdcb7")]
    public class WFM_BDC_ModelEventReceiver : SPFeatureReceiver
    {
        const string SiteUrl = "SiteUrl";
        const string SiteUrlProp = "SiteUrlProp";
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            ReworkProperty(properties);
            DynamicBCSDeployment d = new DynamicBCSDeployment();
            d.FeatureActivated(properties);
        }
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            ReworkProperty(properties);
            DynamicBCSDeployment d = new DynamicBCSDeployment();
            d.FeatureDeactivating(properties);
        }

        void ReworkProperty(SPFeatureReceiverProperties properties)
        {
            SPFarm LocalFarm = ((SPWebService)properties.Feature.Parent).Farm;
            if (LocalFarm.Properties[properties.Definition.Properties[SiteUrlProp].Value] == null)
                throw new ArgumentException("Missing farm property");

            properties.Definition.Properties[SiteUrl].Value = LocalFarm.Properties[properties.Definition.Properties[SiteUrlProp].Value].ToString();
            properties.Feature.Properties.Update();

        }

    }
    public class DynamicBCSDeployment : ImportModelReceiver
    {
        public DynamicBCSDeployment() { }
    }

}
