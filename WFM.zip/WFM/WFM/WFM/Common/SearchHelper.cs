﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebPartPages;
using WFM.Common;
using System.Web.UI.WebControls.WebParts;
using System.Globalization;

namespace NYL.WFM.Common
{
    class SearchHelper
    {

        public static void updateAllWebpartViews(Guid oSiteId, Guid oWebId)
        {
            updateListViewWebPart(oSiteId, oWebId, "SearchPages/searchdate.aspx",  "{435D0841-A473-4EDF-B1F5-A98647C145AD}");
        }

        private static void updateListViewWebPart(Guid oSiteId, Guid oWebId, string pageUrl, string SelectedWebPartId)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(oSiteId))
                {
                    using (SPWeb web = site.OpenWeb(oWebId))
                    {
                        try
                        {
                            SPFile page = web.GetFile(pageUrl);
                            SPList list = web.Lists.TryGetList(Constants.ListName.WFM_TICKETS);
                            SPView view = list.DefaultView;

                            using (SPLimitedWebPartManager wpmgr = page.GetLimitedWebPartManager(PersonalizationScope.Shared))
                            {

                                foreach (Microsoft.SharePoint.WebPartPages.WebPart wp in wpmgr.WebParts)
                                {
                                    if (wp.ID.Equals(SelectedWebPartId))
                                    {
                                        XsltListViewWebPart lvwp = wp as XsltListViewWebPart;
                                        lvwp.ViewGuid = view.ID.ToString("B");
                                        lvwp.XmlDefinition = view.GetViewXml();
                                        //mXsltListViewWebPart.ListId = list.ID;
                                        //lvwp.Toolbar = "No Toolbar";
                                        //wpmgr.AddWebPart(lvwp, "Header", webPartIndex);
                                        wpmgr.SaveChanges(wp);

                                    }

                                }
                            }

                        }
                        catch (Exception ex)
                        {
                            //WFMLogger.LogTraceInformation(string.Format("Error occured while adding View WebPart for search page: {0}", pageUrl), WFMLogger.LogCategory.ErrorLog);
                            ExceptionHelper.HandleException(new Exception(string.Format("Error occured while adding View WebPart for search page: {0}", pageUrl), ex), ExceptionPolicy.BOExceptionPolicy);
                        }
                    }
                }
            });
        }

    }
}
