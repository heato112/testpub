﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.SharePoint.Administration;

namespace WFM.Common
{
    [System.Runtime.InteropServices.GuidAttribute("D802041C-2765-4D96-BCEA-D676B1D63514")]
    [Serializable()]
    public class WFMLogger : SPDiagnosticsServiceBase
    {
        private static string _diagnosticsAreaName = Constants.General.WFM_LOGS_HEADER;
        private static WFMLogger _logger = new WFMLogger();

        private enum EventId
        {
            None = 0,
            Information = 100,
            Error = 200
        }

        public static WFMLogger Instance
        {
            get
            {
                if (_logger == null)
                    return new WFMLogger();
                else
                    return _logger;
            }
        }

        public enum LogCategory
        {
            InfoLog,
            DebugLog,
            ErrorLog,
            Install
        }

        public WFMLogger()
            : base(string.Empty, SPFarm.Local)
        {

        }

        protected override IEnumerable<SPDiagnosticsArea> ProvideAreas()
        {
            List<SPDiagnosticsCategory> categories = new List<SPDiagnosticsCategory>();
            foreach (string categoryName in Enum.GetNames(typeof(LogCategory)))
            {
                uint categoryId = (uint)(int)Enum.Parse(typeof(LogCategory), categoryName);
                categories.Add(new SPDiagnosticsCategory(categoryName, TraceSeverity.Verbose, EventSeverity.Error, 0, categoryId));
            }

            yield return new SPDiagnosticsArea(_diagnosticsAreaName, categories);
        }

        public static void LogException(Exception ex)
        {
            SPDiagnosticsCategory diagnosticCategory = new SPDiagnosticsCategory(_diagnosticsAreaName, TraceSeverity.Verbose, EventSeverity.Error);
            diagnosticCategory = _logger[LogCategory.ErrorLog];
            StringBuilder errorLog = new StringBuilder();
            errorLog.Append("\n");
            errorLog.Append("Exception: \n");
            errorLog.Append(ex.Message);
            errorLog.Append("\n");
            errorLog.Append("Stack Trace: \n");
            errorLog.Append(ex.StackTrace);
            errorLog.Append("\n");

            _logger.WriteTrace((uint)EventId.Error, diagnosticCategory, TraceSeverity.Verbose, errorLog.ToString(), _logger.TypeName);

        }

        public static void LogException(Exception ex, ExceptionPolicy exceptionPolicy)
        {
            #region Commented Code
            //SPDiagnosticsCategory diagnosticCategory = new SPDiagnosticsCategory(_diagnosticsAreaName, TraceSeverity.Verbose, EventSeverity.Error);
            //diagnosticCategory = _logger[LogCategory.ErrorLog];
            //StringBuilder errorLog = new StringBuilder();
            //errorLog.Append("\n");
            //errorLog.Append("Exception Policy: " + exceptionPolicy.Name);
            //errorLog.Append("\nException: \n");
            //errorLog.Append(ex.Message);
            //errorLog.Append("\n");
            //errorLog.Append("Stack Trace: \n");
            //errorLog.Append(ex.StackTrace);
            //errorLog.Append("\n");

            //_logger.WriteTrace((uint)EventId.Error, diagnosticCategory, TraceSeverity.Verbose, errorLog.ToString(), _logger.TypeName);
            #endregion
         
            LogException(string.Empty, ex, exceptionPolicy);
        }

        public static void LogException(string moduleName, Exception ex, ExceptionPolicy exceptionPolicy)
        {
            SPDiagnosticsCategory diagnosticCategory = new SPDiagnosticsCategory(_diagnosticsAreaName, TraceSeverity.Verbose, EventSeverity.Error);
            diagnosticCategory = _logger[LogCategory.ErrorLog];
            StringBuilder errorLog = new StringBuilder();
            
            if (!string.IsNullOrEmpty(moduleName))
            {
                errorLog.Append("\n");
                errorLog.Append("ModuleName: " + moduleName);
                errorLog.Append("\n");
            }
            errorLog.Append("\n");
            errorLog.Append("Exception Policy: " + exceptionPolicy.Name);
            errorLog.Append("\nException: \n");
            errorLog.Append(ex.Message);
            errorLog.Append("\n");
            errorLog.Append("Stack Trace: \n");
            errorLog.Append(ex.StackTrace);

            if (ex.InnerException != null)
            {
                errorLog.Append("Inner Stack Trace: \n");
                errorLog.Append(ex.InnerException.StackTrace);
            }

            errorLog.Append("\n");

            _logger.WriteTrace((uint)EventId.Error, diagnosticCategory, TraceSeverity.Verbose, errorLog.ToString(), _logger.TypeName);

        }

        public static void LogTraceInformation(string message, LogCategory category)
        {
            LogTraceInformation(string.Empty, message, category);

            #region Commented Code
            //try
            //{
            //    StackTrace st = new StackTrace();
            //    StackFrame sf = null;

            //    if (category == LogCategory.Install || category == LogCategory.InfoLog)
            //    {
            //        sf = st.GetFrames()[1];
            //    }
            //    else if (category == LogCategory.DebugLog && ConfigurationSettings.GetTraceLogCategory().Equals("Debug", StringComparison.OrdinalIgnoreCase))
            //    {
            //        sf = st.GetFrames()[1];
            //    }

            //    if (sf != null)
            //    {
            //        StringBuilder buildMessage = new StringBuilder();
            //        buildMessage.Append("ClassName:");
            //        buildMessage.Append("$");
            //        buildMessage.Append(sf.GetMethod().ReflectedType.Name);
            //        buildMessage.Append("$");
            //        buildMessage.Append(sf.GetMethod().ToString());
            //        buildMessage.Append("$");
            //        buildMessage.Append("Timestamp:");
            //        buildMessage.Append("$");
            //        buildMessage.Append(DateTime.Now.ToString("hh:mm:ss.fff"));
            //        buildMessage.Append("$");
            //        buildMessage.Append("WFMCorrelationID:");
            //        buildMessage.Append("$");
            //        buildMessage.Append(getWFMCorrelationID());
            //        buildMessage.Append("$");

            //        buildMessage.Append("Exec Time: ");
            //        buildMessage.Append("$");
            //        buildMessage.Append(string.Empty);
            //        buildMessage.Append("$");

            //        buildMessage.Append(message);
            //        buildMessage.Append("$");

            //        LogMessage(buildMessage.ToString(), category);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    string error = ex.Message;
            //}

            #endregion
        }

        public static void LogTraceInformation(string moduleName, string message, LogCategory category)
        {
            try
            {
                StackTrace st = new StackTrace();
                StackFrame sf = null;

                if (category == LogCategory.Install || category == LogCategory.InfoLog)
                {
                    sf = st.GetFrames()[1];
                }
                else if (category == LogCategory.DebugLog && ConfigurationSettings.GetTraceLogCategory().Equals("Debug", StringComparison.OrdinalIgnoreCase))
                {
                    sf = st.GetFrames()[1];
                }

                if (sf != null)
                {
                    StringBuilder buildMessage = new StringBuilder();
                    if (!string.IsNullOrEmpty(moduleName))
                    {
                        buildMessage.Append("ModuleName:");
                        buildMessage.Append("$");
                        buildMessage.Append(moduleName);
                        buildMessage.Append("$");
                    }
                    buildMessage.Append("ClassName:");
                    buildMessage.Append("$");
                    buildMessage.Append(sf.GetMethod().ReflectedType.Name);
                    buildMessage.Append("$");
                    buildMessage.Append(sf.GetMethod().ToString());
                    buildMessage.Append("$");
                    buildMessage.Append("Timestamp:");
                    buildMessage.Append("$");
                    buildMessage.Append(DateTime.Now.ToString("hh:mm:ss.fff"));
                    buildMessage.Append("$");
                    buildMessage.Append("WFMCorrelationID:");
                    buildMessage.Append("$");
                    buildMessage.Append(getWFMCorrelationID());
                    buildMessage.Append("$");

                    buildMessage.Append("Exec Time: ");
                    buildMessage.Append("$");
                    buildMessage.Append(string.Empty);
                    buildMessage.Append("$");

                    buildMessage.Append(message);
                    buildMessage.Append("$");

                    LogMessage(buildMessage.ToString(), category);
                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }
        }

        private static void LogMessage(string message, LogCategory category)
        {
            try
            {
                SPDiagnosticsCategory diagnosticCategory = new SPDiagnosticsCategory(_diagnosticsAreaName, TraceSeverity.Verbose, EventSeverity.Error);
                diagnosticCategory = _logger[category];

                if (category == LogCategory.ErrorLog)
                {
                    _logger.WriteTrace((uint)EventId.Error, diagnosticCategory, TraceSeverity.High, message, _logger.TypeName);
                }
                else if (category == LogCategory.DebugLog)
                {
                    _logger.WriteTrace((uint)EventId.Information, diagnosticCategory, TraceSeverity.High, message, _logger.TypeName);
                }
                else
                {
                    _logger.WriteTrace((uint)EventId.Information, diagnosticCategory, TraceSeverity.Verbose, message, _logger.TypeName);
                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }
        }

        private SPDiagnosticsCategory this[LogCategory id]
        {
            get
            {
                return Areas[_diagnosticsAreaName].Categories[id.ToString()];
            }
        }

        private static string getWFMCorrelationID()
        {
            string correlationID = string.Empty;

            if (System.Web.HttpContext.Current != null)
            {
                if (System.Web.HttpContext.Current.Items["WFMCorrelationID"] != null)
                {
                    correlationID = Convert.ToString(System.Web.HttpContext.Current.Items["WFMCorrelationID"]);
                }
            }

            return correlationID;
        }

    }
}
