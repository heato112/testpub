﻿using System;
using Microsoft.SharePoint;
using System.Collections.Generic;
using System.Data;
using NYL.WFM.Common;

namespace WFM.Common
{
    public static class GroupSync
    {
        //private const string user_prefix = "i:0ǻ.t|siteminder nyluid|";

        public static void SyncUsers(Guid siteId, Guid webId, SPListItem listItem)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            if (SyncAgents(siteId, webId))
            {
                UpdateGroupSyncStatus(Constants.GroupSyncResultType.AGENT_SYNC_COMPLETE, true, listItem);
            }

            if (SyncManagers(siteId, webId))
            {
                UpdateGroupSyncStatus(Constants.GroupSyncResultType.MANAGER_SYNC_COMPLETE, true, listItem);
            }

            if (SyncWFMStaff(siteId, webId))
            {
                UpdateGroupSyncStatus(Constants.GroupSyncResultType.WFMSTAFF_SYNC_COMPLETE, true, listItem);
            }

            if (SyncWFMAdmin(siteId, webId))
            {
                UpdateGroupSyncStatus(Constants.GroupSyncResultType.WFMADMIN_SYNC_COMPLETE, true, listItem);
            }

            UpdateGroupSyncStatus(Constants.GroupSyncResultType.SYNC_PROCESS_COMPLETE, true, listItem);

            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
        }

        public static bool SyncManagers(Guid siteId, Guid webId)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);
            bool retVal = false;
            try
            {
                DataTable dtManagers = getAllUsersFromExternalList(siteId, webId, Constants.ViewName.WFM_All_Managers);
                List<SPUser> managersList = getUsersFromList(dtManagers, siteId, webId);
                GroupHelper.RemoveAllUsersFromGroup(siteId, webId, Constants.GroupNames.MANAGERS_GROUP);
                GroupHelper.AddUsersToGroup(siteId, webId, Constants.GroupNames.MANAGERS_GROUP, managersList);

                WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, "Managers synchronized successfully", WFMLogger.LogCategory.InfoLog);
                retVal = true;
            }
            catch (Exception e)
            {
                //WFMLogger.LogException(new Exception("Error occurred while synchronizing Managers",e));
                ExceptionHelper.HandleException(Constants.ModuleName.WFM_GROUP_SYNC, new Exception("Error occurred while synchronizing Managers", e), ExceptionPolicy.BOExceptionPolicy, true);
                retVal = false;
            }
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
            return retVal;
        }

        public static bool SyncAgents(Guid siteId, Guid webId)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);
            bool retVal = false;
            try
            {
                DataTable dtAgents = getAllUsersFromExternalList(siteId, webId, Constants.ViewName.WFM_All_Agents);
                List<SPUser> agentsList = getUsersFromList(dtAgents, siteId, webId);
                GroupHelper.RemoveAllUsersFromGroup(siteId, webId, Constants.GroupNames.AGENTS_GROUP);
                GroupHelper.AddUsersToGroup(siteId, webId, Constants.GroupNames.AGENTS_GROUP, agentsList);

                WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, "Agents synchronized successfully", WFMLogger.LogCategory.InfoLog);
                retVal = true;
            }
            catch (Exception e)
            {
                //WFMLogger.LogException(new Exception("Error occurred while synchronizing Agents", e));
                ExceptionHelper.HandleException(Constants.ModuleName.WFM_GROUP_SYNC, new Exception("Error occurred while synchronizing Agents", e), ExceptionPolicy.BOExceptionPolicy, true);
                retVal = false;
            }
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
            return retVal;
        }

        public static bool SyncWFMStaff(Guid siteId, Guid webId)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);
            bool retVal = false;
            try
            {
                DataTable dtWFMStaff = getAllUsersFromExternalList(siteId, webId, Constants.ViewName.WFM_All_WFMStaff); ;
                List<SPUser> wfmStaffList = getUsersFromList(dtWFMStaff, siteId, webId);
                GroupHelper.RemoveAllUsersFromGroup(siteId, webId, Constants.GroupNames.WFM_STAFF_GROUP);
                GroupHelper.AddUsersToGroup(siteId, webId, Constants.GroupNames.WFM_STAFF_GROUP, wfmStaffList);
                WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, "WFM Staff synchronized successfully", WFMLogger.LogCategory.InfoLog);
                retVal = true;
            }
            catch (Exception e)
            {
                //WFMLogger.LogException(new Exception("Error occurred while synchronizing WFM Staff", e));
                ExceptionHelper.HandleException(Constants.ModuleName.WFM_GROUP_SYNC, new Exception("Error occurred while synchronizing WFM Staff", e), ExceptionPolicy.BOExceptionPolicy, true);
                retVal = false;
            }
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
            return retVal;
        }

        public static bool SyncWFMAdmin(Guid siteId, Guid webId)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);
            bool retVal = false;
            try
            {
                DataTable dtWFMAdmin = getAllUsersFromExternalList(siteId, webId, Constants.ViewName.WFM_All_WFMAdmin); ;
                List<SPUser> wfmAdminList = getUsersFromList(dtWFMAdmin, siteId, webId);
                GroupHelper.RemoveAllUsersFromGroup(siteId, webId, Constants.GroupNames.WFM_ADMIN_GROUP);
                GroupHelper.AddUsersToGroup(siteId, webId, Constants.GroupNames.WFM_ADMIN_GROUP, wfmAdminList);
                WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, "WFM Admin synchronized successfully", WFMLogger.LogCategory.InfoLog);
                retVal = true;
            }
            catch (Exception e)
            {
                //WFMLogger.LogException(new Exception("Error occurred while synchronizing WFM Admin",e));
                ExceptionHelper.HandleException(Constants.ModuleName.WFM_GROUP_SYNC, new Exception("Error occurred while synchronizing WFM Admin", e), ExceptionPolicy.BOExceptionPolicy, true);
                retVal = false;
            }
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
            return retVal;
        }

        #region private methods

        private static List<SPUser> getUsersFromList(DataTable dtUsers, Guid siteId, Guid webId)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            List<SPUser> usersList = new List<SPUser>();
            //SPSecurity.RunWithElevatedPrivileges(delegate()
            //{
            using (SPSite site = new SPSite(siteId))
            {
                using (SPWeb web = site.OpenWeb(webId))
                {
                    ConfigurationSettings.MasterSiteURL = PropertyBagHelper.GetPropertyValue(web, "mastersiteurl");
                    string userIDcolumnName = ConfigurationSettings.getUserIDColumnName();

                    web.AllowUnsafeUpdates = true;
                    for (int i = 0; i < dtUsers.Rows.Count; i++)
                    //for (int i = 0; i < 4; i++)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(dtUsers.Rows[i][userIDcolumnName])))
                        {
                            SPUser user = null;
                            try
                            {
                                user = web.EnsureUser(string.Concat(ConfigurationSettings.UserPrefix(), Convert.ToString(dtUsers.Rows[i][userIDcolumnName])));
                                if (user != null)
                                {
                                    if (!isBlockedUser(user))
                                    {
                                        usersList.Add(user);
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                ExceptionHelper.HandleException(Constants.ModuleName.WFM_GROUP_SYNC, new Exception(string.Format("Error occurred while getting user from list for User: {0}", Convert.ToString(dtUsers.Rows[i][userIDcolumnName])), ex), ExceptionPolicy.BOExceptionPolicy, true);
                            }

                        }
                    }
                    web.AllowUnsafeUpdates = false;
                }
            }
            //});

            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);

            return usersList;
        }

        private static Boolean isBlockedUser(SPUser user)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            Boolean isUserBlocked = false;

            SPList oList = user.ParentWeb.Lists.TryGetList(Constants.ListName.BLOCKED_USERS);
            SPQuery query = new SPQuery();

            query.Query = "<Where><Eq><FieldRef Name='User' LookupId='TRUE' /><Value Type='Int'>" + user.ID + "</Value></Eq></Where>";
            //query.Query = "<Where><In><FieldRef Name=\"User\" LookupId=\"TRUE\" /><Values><Value Type=\"User\">" + user.ID + "</Value></Values></In></Where>";

            SPListItemCollection items = oList.GetItems(query);
            int count = items.Count;
            if (count > 0)
            {
                isUserBlocked = true;
            }

            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
            return isUserBlocked;
        }

        // GET ALL MANAGERS
        private static DataTable getAllUsersFromExternalList(Guid siteId, Guid webId, string vwName)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            DataTable users = new DataTable();

            using (SPSite site = new SPSite(siteId))
            {
                using (SPWeb web = site.OpenWeb(webId))
                {
                    var context = SPServiceContext.GetContext(site);
                    using (var scope = new SPServiceContextScope(context))
                    {
                        SPList externalList = web.Lists.TryGetList(Constants.ListName.WFM_ALLUSERS);
                        if (externalList != null)
                        {
                            SPView view = externalList.Views[vwName];
                            SPQuery query = new SPQuery(view);
                            users = externalList.GetItems(query).GetDataTable();
                        }
                    }
                }
            }

            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
            return users;
        }

        // GET ALL AGENTS
        private static DataTable getAllAgents(Guid siteId, Guid webId)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            DataTable users = new DataTable();
            using (SPSite site = new SPSite(siteId))
            {
                using (SPWeb web = site.OpenWeb(webId))
                {
                    var context = SPServiceContext.GetContext(site);
                    using (var scope = new SPServiceContextScope(context))
                    {
                        SPList externalList = web.Lists.TryGetList(Constants.ListName.WFM_ALLUSERS);
                        if (externalList != null)
                        {
                            //SPView view = externalList.Views["Managers2"];
                            //SPQuery query = new SPQuery(view);
                            //query.Query = view.Query;
                            //query.RowLimit = 4;
                            //query.Query = "<Where><Eq><FieldRef Name='SupervisorBln' /><Value Type='Boolean'>true</Value></Eq></Where>";
                            users = externalList.GetItems().GetDataTable();
                            //users = externalList.GetItems().GetDataTable();
                        }
                    }
                }
            }
            //});

            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);

            return users;
        }

        // GET ALL WFM STAFF
        private static DataTable getAllWFMStaff(Guid siteId, Guid webId)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            DataTable users = new DataTable();
            using (SPSite site = new SPSite(siteId))
            {
                using (SPWeb web = site.OpenWeb(webId))
                {
                    var context = SPServiceContext.GetContext(site);
                    using (var scope = new SPServiceContextScope(context))
                    {
                        SPList externalList = web.Lists.TryGetList(Constants.ListName.WFM_ALLUSERS);
                        if (externalList != null)
                        {
                            SPQuery query = new SPQuery();
                            //query.Query = "<Where><Eq><FieldRef Name='RoleName' /><Value Type='Text'>WFM Staff</Value></Eq></Where>";
                            query.Query = "<Where><Eq><FieldRef Name='RoleName' /><Value Type='Text'>Non-CC Personnel</Value></Eq></Where>";
                            users = externalList.GetItems(query).GetDataTable();
                        }
                    }
                }
            }
            //});

            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);

            return users;
        }

        private static void UpdateGroupSyncStatus(string columnName, bool status, SPListItem item)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    if (item != null)
                    {
                        item[columnName] = status;
                        item.Update();
                    }
                });
            }
            catch (Exception e)
            {
                //WFMLogger.LogException(new Exception("Error occurred while updating synchronizing status",e));
                ExceptionHelper.HandleException(Constants.ModuleName.WFM_GROUP_SYNC, new Exception(string.Format("Error occurred while updating synchronizing status for column: {0}", columnName), e), ExceptionPolicy.BOExceptionPolicy, true);
            }

            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_GROUP_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
        }
        #endregion

    }
}

