using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using WFM.Common;

namespace WFM.Features.WFM_Provision_Security_Groups
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("4f8deeec-0c77-47db-b45f-7d0d22c901b8")]
    public class WFM_Provision_Security_GroupsEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPWeb oWeb = (SPWeb)properties.Feature.Parent;
            if (oWeb != null)
            {
                if (oWeb.Site != null)
                {
                    try
                    {
                        GroupHelper.RemoveUnusedSiteGroups(oWeb.Site.ID, oWeb.ID);
                        GroupHelper.SetupSiteGroups(oWeb.Site.ID, oWeb.ID);
                        PermissionHelper.AssignBlockedUsersListPermission(oWeb.Site.ID, oWeb.ID, oWeb.AssociatedOwnerGroup.Name);
                        PermissionHelper.AssignRequestTypeListPermission(oWeb.Site.ID, oWeb.ID, oWeb.AssociatedOwnerGroup.Name);
                        PermissionHelper.AssignReportsTemplateListPermission(oWeb.Site.ID, oWeb.ID, oWeb.AssociatedOwnerGroup.Name);
                        
                        WFMLogger.LogTraceInformation("Provisioning of Security Groups Completed Successfully", WFMLogger.LogCategory.InfoLog);
                    }
                    catch (Exception ex)
                    {
                        //WFMLogger.LogException(new Exception("Error occured while Provisioning WFM Security Groups",ex));
                        ExceptionHelper.HandleException(new Exception("Error occured while Provisioning WFM Security Groups", ex), ExceptionPolicy.BOExceptionPolicy, true);
                    }
                }
            }
        }

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPWeb oWeb = (SPWeb)properties.Feature.Parent;
            if (oWeb != null)
            {
                if (oWeb.Site != null)
                {
                    try
                    {
                        GroupHelper.RemoveSiteGroups(oWeb.Site.ID, oWeb.ID);
                        WFMLogger.LogTraceInformation("Removing of Security Groups Completed Successfully", WFMLogger.LogCategory.InfoLog);
                    }
                    catch (Exception ex)
                    {
                         //WFMLogger.LogException(new Exception("Error occured while removing WFM Security Groups",ex));
                        ExceptionHelper.HandleException(new Exception("Error occured while removing WFM Security Groups", ex), ExceptionPolicy.BOExceptionPolicy, true);
                    }
                }
            }
        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
