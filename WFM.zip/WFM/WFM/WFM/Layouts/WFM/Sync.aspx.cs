﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using WFM.Common;
using System.Data;

namespace WFM.Layouts.WFM
{
    public partial class ApplicationPage1 : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //DataTable allUsers = GroupSync.getAllManagers(SPContext.Current.Web);
            //GroupSync.SyncManagers(SPContext.Current.Web.Site.ID, SPContext.Current.Web.ID);
        }

        protected void btnSyncManagers_Click(object sender, EventArgs e)
        {
            GroupSync.SyncManagers(SPContext.Current.Web.Site.ID, SPContext.Current.Web.ID);
        }

        protected void btnSyncAgents_Click(object sender, EventArgs e)
        {
            GroupSync.SyncAgents(SPContext.Current.Web.Site.ID, SPContext.Current.Web.ID);
        }

        protected void btnSyncWFMStaff_Click(object sender, EventArgs e)
        {
            GroupSync.SyncWFMStaff(SPContext.Current.Web.Site.ID, SPContext.Current.Web.ID);
        }
    }
}
