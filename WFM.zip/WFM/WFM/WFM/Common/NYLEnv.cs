﻿using System;
using System.Net;

namespace WFM.Common
{
    public class NYLEnv
    {
        public static String ENV = GetEnv();

        public const String PROD_SERVER_PREFIX = "NYP";

        public const String MODEL_SERVER_PREFIX = "NYM";

        public const String UNIT_SERVER_PREFIX = "NYT";

        public const String ENV_ISO = "iso";

        public const String ENV_MODEL = "mdl";

        public const String ENV_PROD = "prod";

        public const String ENV_UNIT = "dev";

        //return the env based on host name
        //for ex. host name that starts with "NYM"/"nym" returns Model
        //this method is intentionally kept private
        //use  the "ENV" constant
        private static String GetEnv()
        {
            //WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_START, WFMLogger.LogCategory.DebugLog);
            String hostName = null;
            //the only caller should be the "ENV" variable and it cannot
            //handle exceptions
            try
            {
                hostName = Dns.GetHostName();

                if (hostName == null)
                {
                    throw new SystemException("NYLEnv.getEnv() - Hostname is null");
                }

                if (hostName.ToLower().StartsWith(PROD_SERVER_PREFIX.ToLower()))
                {
                    return ENV_PROD;
                }
                else if (hostName.ToLower().StartsWith(MODEL_SERVER_PREFIX.ToLower()))
                {
                    return ENV_MODEL;
                }
                else if (hostName.ToLower().Contains("iso") || hostName.ToLower().Contains("is0"))
                {
                    return ENV_ISO;
                }
                else if (hostName.ToLower().StartsWith(UNIT_SERVER_PREFIX.ToLower()))
                {
                    return ENV_UNIT;
                }
            }
            catch (Exception e)
            {
                //log the exception here
                WFMLogger.LogException(e);
                throw e;
            }
            //WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_END, WFMLogger.LogCategory.DebugLog);
            return null;
        }

    }
}
