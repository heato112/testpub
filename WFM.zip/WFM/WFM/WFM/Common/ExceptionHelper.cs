﻿using System;
using System.Text;
using System.Web;

namespace WFM.Common
{
    public class ExceptionHelper
    {
        public static void HandleException(string moduleName, Exception exception, ExceptionPolicy exceptionPolicy)
        {
            HandleException(moduleName, exception, exceptionPolicy, false);

            if (exceptionPolicy == ExceptionPolicy.UIExceptionPolicy)
            {
                string masterSiteUrl = ConfigurationSettings.SiteUrl();
                //HttpContext.Current.Response.Redirect(masterSiteUrl + Constants.General.EXCEPTION_ERROR_PAGE, false);
            }
        }

        public static void HandleException(string moduleName, Exception exception, ExceptionPolicy exceptionPolicy, bool sendEmail)
        {
            WFMLogger.LogException(moduleName, exception, exceptionPolicy);

            //            if (sendEmail && NYLEnv.ENV.Equals(NYLEnv.ENV_PROD))
            if (sendEmail && ConfigurationSettings.getEnableErrorNotification() == 1)
            {
                // SEND ERROR EMAIL ONLY FOR PROD ENV
                buildSupportEmail(moduleName, exception, exceptionPolicy);
            }
        }

        public static void HandleException(Exception exception, ExceptionPolicy exceptionPolicy)
        {
            HandleException(exception, exceptionPolicy, false);

            if (exceptionPolicy == ExceptionPolicy.UIExceptionPolicy)
            {
                string masterSiteUrl = ConfigurationSettings.SiteUrl();
                //HttpContext.Current.Response.Redirect(masterSiteUrl + Constants.General.EXCEPTION_ERROR_PAGE, false);
            }
        }

        public static void HandleException(Exception exception, ExceptionPolicy exceptionPolicy, bool sendEmail)
        {
            WFMLogger.LogException(exception, exceptionPolicy);

            //            if (sendEmail && NYLEnv.ENV.Equals(NYLEnv.ENV_PROD))
            if (sendEmail && ConfigurationSettings.getEnableErrorNotification() == 1)
            {
                // SEND ERROR EMAIL ONLY FOR PROD ENV
                buildSupportEmail(exception, exceptionPolicy);
            }
        }


        #region Private Methods

        private static void buildSupportEmail(Exception ex, ExceptionPolicy exceptionPolicy)
        {
            #region Commented Code
            //StringBuilder errorEmailBody = new StringBuilder();
            //errorEmailBody.Append("<b>Error Occured At:</b> " + DateTime.Now);
            //errorEmailBody.Append("<br/>");
            //errorEmailBody.Append("<br/>");
            //errorEmailBody.Append("<b>Exception Policy:</b> " + exceptionPolicy.Name);

            //errorEmailBody.Append("<br/>");
            //errorEmailBody.Append("<b>Exception:</b> ");
            //errorEmailBody.Append(ex.Message);
            //errorEmailBody.Append("<br/>");
            //errorEmailBody.Append("<b>Stack Trace:</b> ");
            //errorEmailBody.Append(ex.StackTrace);
            //errorEmailBody.Append("<br/>");

            ////Send Email.
            //NotificationHelper sendEmail = new NotificationHelper();
            //sendEmail.SendSupportEmail(errorEmailBody.ToString());

            #endregion
            buildSupportEmail(string.Empty, ex, exceptionPolicy);
        }

        private static void buildSupportEmail(string moduleName, Exception ex, ExceptionPolicy exceptionPolicy)
        {
            StringBuilder errorEmailBody = new StringBuilder();
            errorEmailBody.Append("<b>Error Occured At:</b> " + DateTime.Now);
            if (!string.IsNullOrEmpty(moduleName))
            {
                errorEmailBody.Append("<br/>");
                errorEmailBody.Append("<b>ModuleName:</b> " + moduleName);
            }

            errorEmailBody.Append("<br/>");
            errorEmailBody.Append("<br/>");
            errorEmailBody.Append("<b>Exception Policy:</b> " + exceptionPolicy.Name);

            errorEmailBody.Append("<br/>");
            errorEmailBody.Append("<b>Exception:</b> ");
            errorEmailBody.Append(ex.Message);
            errorEmailBody.Append("<br/>");
            errorEmailBody.Append("<b>Stack Trace:</b> ");
            errorEmailBody.Append(ex.StackTrace);
            errorEmailBody.Append("<br/>");

            //Send Email.
            NotificationHelper sendEmail = new NotificationHelper();
            sendEmail.SendSupportEmail(errorEmailBody.ToString());
        }

        #endregion
    }

    public abstract class ExceptionPolicy
    {
        protected const string PolicyName_UI = "UI";
        protected const string PolicyName_BO = "BO";

        public abstract string Name { get; }

        public static readonly ExceptionPolicy UIExceptionPolicy = new UIExceptionPolicy();
        public static readonly ExceptionPolicy BOExceptionPolicy = new BOExceptionPolicy();
    }

    public class UIExceptionPolicy : ExceptionPolicy
    {
        public override string Name { get { return PolicyName_UI; } }
    }

    public class BOExceptionPolicy : ExceptionPolicy
    {
        public override string Name { get { return PolicyName_BO; } }
    }

    public class WFMException : ApplicationException
    {
        public WFMException(string msg) : base(msg) { }
    }
}
