﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.RecordsManagement.PolicyFeatures;
using WFM.Common;

namespace NYL.WFM.Common.ExpirationPolicy
{
    public class WFMTicketsDeletionFormula : IExpirationFormula
    {
        public DateTime? ComputeExpireDate(Microsoft.SharePoint.SPListItem item, System.Xml.XmlNode parametersData)
        {
            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_START, WFMLogger.LogCategory.DebugLog);

            ConfigurationSettings.MasterSiteURL = PropertyBagHelper.GetPropertyValue(item.Web, "mastersiteurl");
            string duration = ConfigurationSettings.getWFMTicketsRemovalDuration();
            DateTime createdDate = Convert.ToDateTime(item["Created"]);

            DateTime expiryDate = ExpirationPolicyManagement.GetRetentionExpiryDate(createdDate, duration);

            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_END, WFMLogger.LogCategory.DebugLog);

            return expiryDate;
        }
    }
}
