using System;
using System.Runtime.InteropServices;
using Microsoft.Office.RecordsManagement.InformationPolicy;
using Microsoft.SharePoint;
using WFM.Common;

namespace NYL.WFM.Features.WFM_Tickets_Provision_Policy
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("633e73c3-b9a7-4a6d-a67a-9c859e8ecd88")]
    public class WFM_Tickets_Provision_PolicyEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            string xmlManifestWFMTicketsDeletionFormula = @"<PolicyResource xmlns=""urn:schemas-microsoft-com:office:server:policy""
                                        id = ""NYL.WFMWFMTicketsExpirationFormula""
                                        featureId=""Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration""
                                        type = ""DateCalculator"">
                                      <Name>NYL WFM Tickets Expiration</Name>
                                      <Description>Items Expire based on a filter</Description>
                                      <AssemblyName>NYL.WFM, Version=1.0.0.0, Culture=neutral, PublicKeyToken=c0e1ff0922ff95bc</AssemblyName>
                                      <ClassName>NYL.WFM.Common.ExpirationPolicy.WFMTicketsDeletionFormula</ClassName>
                                    </PolicyResource>";
            try
            {
                PolicyResourceCollection.Add(xmlManifestWFMTicketsDeletionFormula);
                WFMLogger.LogTraceInformation("Activating Feature WFM Tickets Provision Policy successful", WFMLogger.LogCategory.InfoLog);
            }
            catch (Exception e)
            {
                ExceptionHelper.HandleException(new Exception("Error occured Activating  WFM Tickets Provision Policy feature", e), ExceptionPolicy.BOExceptionPolicy, true);
            }
        }

        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
