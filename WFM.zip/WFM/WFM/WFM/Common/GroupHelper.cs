﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace WFM.Common
{
    public class GroupHelper
    {
        /// <summary>
        /// Check whether group exists or not
        /// </summary>
        /// <param name="oSiteId"> Site Id </param>
        /// <param name="oGroupName"> Group Name </param>
        /// <returns></returns>
        public static bool IsGroupExists(Guid oSiteId, Guid oWebId, string oGroupName)
        {
            // DO not add Trace logging in this method & Try/Catch

            bool groupExists = false;

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite oSite = new SPSite(oSiteId))
                {
                    using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                    {
                        try
                        {
                            SPGroup group = oWeb.SiteGroups[oGroupName];
                            groupExists = true;
                        }
                        catch
                        {
                            groupExists = false;
                        }
                    }
                }

            });

            return groupExists;
        }

        /// <summary>
        /// Check whether user exist in a group  or not
        /// </summary>
        /// <param name="oSiteId">Site ID</param>
        /// <param name="oGroupName">Group Name</param>
        /// <param name="oUser">Logged in User</param>
        /// <returns></returns>
        public static bool IsUserOfGroup(Guid oSiteId, Guid oWebId, string oGroupName, SPUser oUser)
        {
            // DO not add Trace logging in this method & Try/Catch

            bool userExists = false;

            using (SPSite oSite = new SPSite(oSiteId))
            {
                using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                {
                    try
                    {
                        SPUser user = oWeb.SiteGroups[oGroupName].Users[oUser.LoginName];
                        if (user != null)
                            userExists = true;
                    }
                    catch
                    {
                        WFMLogger.LogTraceInformation(string.Concat(oUser.LoginName, " user not found in group ", oGroupName, " on site ", oWeb.Name), WFMLogger.LogCategory.DebugLog);
                        userExists = false;
                    }
                }
            }

            return userExists;
        }

        /// <summary>
        /// Checks User is present in group or not
        /// </summary>
        /// <param name="oGroupName">Group Name</param>
        /// <param name="oUsers">User</param>
        /// <returns></returns>
        public static bool IsUserOfGroup(string oGroupName, SPUser oUsers)
        {
            // DO not add Trace logging in this method & Try/Catch
            bool userExists;
            try
            {
                SPGroup userInGroup = oUsers.Groups[oGroupName];
                userExists = true;
            }
            catch
            {
                userExists = false;
            }

            return userExists;
        }

        /// <summary>
        /// Returns the users present in the group
        /// </summary>
        /// <param name="siteId">Site Id</param>
        /// <param name="groupName">Group Name</param>
        /// <returns></returns>
        public static List<SPUser> GetGroupUsers(Guid siteId, Guid oWebId, string groupName)
        {
            // DO not add Trace logging in this method & Try/Catch
            List<SPUser> getUsers = null;
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {

                using (SPSite oSite = new SPSite(siteId))
                {
                    using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                    {
                        bool GroupExists = IsGroupExists(siteId, oWebId, groupName);
                        if (GroupExists == true)
                        {
                            SPGroup group = oWeb.SiteGroups[groupName];
                            SPUserCollection users = group.Users;
                            getUsers = new List<SPUser>();
                            foreach (SPUser user in users)
                            {
                                getUsers.Add(user);
                            }
                        }
                    }
                }

            });

            return getUsers;
        }

        /// <summary>
        /// Creates the Group
        /// </summary>
        /// <param name="oSiteId">Site Id</param>
        /// <param name="oGroupName">Group Name</param>
        /// <returns></returns>
        public static SPGroup CreateGroup(Guid oSiteId, Guid oWebId, string oGroupName)
        {
            // DO not add Trace logging in this method & Try/Catch

            SPGroup spGroup = null;
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite oSite = new SPSite(oSiteId))
                {
                    using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                    {
                        oWeb.AllowUnsafeUpdates = true;
                        SPUser spAdminUser = oWeb.Site.SystemAccount;//$$ Todo Need to take from config
                        oWeb.SiteGroups.Add(oGroupName, spAdminUser, spAdminUser, string.Empty);
                        oWeb.AllowUnsafeUpdates = false;
                    }

                }
            });

            return spGroup;
        }

        /// <summary>
        /// Adds the user to the specified group
        /// </summary>
        /// <param name="oSiteId">Site Id</param>
        /// <param name="oGroupName">Group Name</param>
        /// <param name="oUsers">Users</param>
        /// <returns></returns>
        public static bool AddUsersToGroup(Guid oSiteId, Guid oWebId, string oGroupName, List<SPUser> oUsers)
        {
            // DO not add Trace logging in this method & Try/Catch
            //if (!IsGroupExists(oSiteId, oWebId, oGroupName))
            //throw new AuthorizationGroupNotFoundException(oGroupName, Convert.ToString(oSiteId));

            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                if (oUsers != null)
                {
                    using (SPSite oSite = new SPSite(oSiteId))
                    {
                        using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                        {

                            oWeb.AllowUnsafeUpdates = true;
                            SPGroup group = oWeb.SiteGroups[oGroupName];
                            foreach (SPUser user in oUsers)
                            {
                                string userNameString = string.Empty;
                                try
                                {
                                    userNameString = string.Concat(user.Name, ": ", user.LoginName);
                                    group.Users.Add(user.LoginName, user.Email, user.Name, user.Notes);
                                }
                                catch (Exception e)
                                {
                                    //WFMLogger.LogTraceInformation(string.Format("Error occurred while Adding user to group {0}", oGroupName), WFMLogger.LogCategory.ErrorLog);
                                    ExceptionHelper.HandleException(new Exception(string.Format("Error occurred while Adding user: {0} to group: {1}", userNameString, oGroupName), e), ExceptionPolicy.BOExceptionPolicy, true);
                                }
                            }
                            oWeb.AllowUnsafeUpdates = false;
                        }
                    }
                }
            });

            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
            return true;
        }

        /// <summary>
        /// Remove all users from the specified group
        /// </summary>
        /// <param name="oSiteId">Site Id</param>
        /// <param name="oGroupName">Group Name</param>
        /// <returns></returns>
        public static bool RemoveAllUsersFromGroup(Guid oSiteId, Guid oWebId, string oGroupName)
        {
            //if (!IsGroupExists(oSiteId, oWebId, oGroupName))
            //throw new AuthorizationGroupNotFoundException(oGroupName, Convert.ToString(oSiteId));

            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite oSite = new SPSite(oSiteId))
                {
                    using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                    {
                        oWeb.AllowUnsafeUpdates = true;
                        SPGroup group = oWeb.SiteGroups[oGroupName];
                        if (group != null)
                        {
                            foreach (SPUser user in group.Users)
                            {
                                string userNameString = string.Empty;
                                try
                                {
                                    userNameString = string.Concat(user.Name, ": ", user.LoginName);
                                    group.RemoveUser(user);
                                }
                                catch (Exception e)
                                {
                                    //WFMLogger.LogTraceInformation(string.Format("Error occurred while Removing user from group {0}", oGroupName), WFMLogger.LogCategory.ErrorLog);
                                    ExceptionHelper.HandleException(new Exception(string.Format("Error occurred while Removing user: {0} from group: {1}", userNameString, oGroupName), e), ExceptionPolicy.BOExceptionPolicy, true);
                                }
                            }
                        }
                        oWeb.AllowUnsafeUpdates = false;
                    }
                }
            });

            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
            return true;
        }

        /// <summary>
        /// Delete the Group
        /// </summary>
        /// <param name="oSiteId">Site Id</param>
        /// <param name="oGroupName">Group Name</param>
        public static void DeleteGroup(Guid oSiteId, Guid oWebId, string oGroupName)
        {
            // DO not add Trace logging in this method & Try/Catch
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite oSite = new SPSite(oSiteId))
                {
                    using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                    {
                        if (IsGroupExists(oSiteId, oWebId, oGroupName))
                        {
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.SiteGroups.Remove(oGroupName);
                            oWeb.AllowUnsafeUpdates = false;
                        }
                    }
                }
            });

        }

        /// <summary>
        /// Setup all SharePoint groups needed to manage security, except item level groups
        /// </summary>
        /// <param name="oSiteId">ID of Site collection</param>
        /// <param name="oWebId">ID of site (SPWeb)</param>
        public static void SetupSiteGroups(Guid oSiteId, Guid oWebId)
        {
            using (SPSite site = new SPSite(oSiteId))
            {
                using (SPWeb webItemNew = site.OpenWeb(oWebId))
                {
                    // GROUPS
                    string managersGroup = Constants.GroupNames.MANAGERS_GROUP;
                    string agentsGroup = Constants.GroupNames.AGENTS_GROUP;
                    string wfm_staffGroup = Constants.GroupNames.WFM_STAFF_GROUP;
                    string wfmAdminGroup = Constants.GroupNames.WFM_ADMIN_GROUP;

                    if (!(GroupHelper.IsGroupExists(oSiteId, oWebId, managersGroup)))
                    {
                        GroupHelper.CreateGroup(oSiteId, oWebId, managersGroup);
                        WFMLogger.LogTraceInformation("Managers Group Created Successfully", WFMLogger.LogCategory.InfoLog);
                        PermissionHelper.AssignGroupSpecialContributeAddOnlyAccessPermission(oSiteId, oWebId, managersGroup);
                        WFMLogger.LogTraceInformation("Managers Group Permission Assigned Successfully", WFMLogger.LogCategory.InfoLog);
                    }

                    if (!(GroupHelper.IsGroupExists(oSiteId, oWebId, agentsGroup)))
                    {
                        GroupHelper.CreateGroup(oSiteId, oWebId, agentsGroup);
                        WFMLogger.LogTraceInformation("Agents Group Created Successfully", WFMLogger.LogCategory.InfoLog);
                        PermissionHelper.AssignGroupSpecialContributeAddOnlyAccessPermission(oSiteId, oWebId, agentsGroup);
                        WFMLogger.LogTraceInformation("Agents Group Permission Assigned Successfully", WFMLogger.LogCategory.InfoLog);
                    }

                    if (!(GroupHelper.IsGroupExists(oSiteId, oWebId, wfm_staffGroup)))
                    {
                        GroupHelper.CreateGroup(oSiteId, oWebId, wfm_staffGroup);
                        WFMLogger.LogTraceInformation("WFM Staff Group Created Successfully", WFMLogger.LogCategory.InfoLog);
                        PermissionHelper.AssignGroupSpecialContributeEditOnlyAccessPermission(oSiteId, oWebId, wfm_staffGroup);
                        WFMLogger.LogTraceInformation("WFM Staff Group Permission Assigned Successfully", WFMLogger.LogCategory.InfoLog);
                    }

                    if (!(GroupHelper.IsGroupExists(oSiteId, oWebId, wfmAdminGroup)))
                    {
                        GroupHelper.CreateGroup(oSiteId, oWebId, wfmAdminGroup);
                        WFMLogger.LogTraceInformation("WFM Admin Group Created Successfully", WFMLogger.LogCategory.InfoLog);
                        PermissionHelper.AssignGroupSpecialContributeEditOnlyAccessPermission(oSiteId, oWebId, wfmAdminGroup);
                        WFMLogger.LogTraceInformation("WFM Admin Group Permission Assigned Successfully", WFMLogger.LogCategory.InfoLog);
                    }
                }
            }
        }

        public static void RemoveSiteGroups(Guid oSiteId, Guid oWebId)
        {
            using (SPSite oSite = new SPSite(oSiteId))
            {
                using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                {
                    RemoveSPGroup(oSiteId, oWebId, Constants.GroupNames.MANAGERS_GROUP);
                    WFMLogger.LogTraceInformation("Managers Group Deleted Successfully", WFMLogger.LogCategory.InfoLog);
                    RemoveSPGroup(oSiteId, oWebId, Constants.GroupNames.AGENTS_GROUP);
                    WFMLogger.LogTraceInformation("Agents Group Deleted Successfully", WFMLogger.LogCategory.InfoLog);
                    RemoveSPGroup(oSiteId, oWebId, Constants.GroupNames.WFM_STAFF_GROUP);
                    WFMLogger.LogTraceInformation("WFM Staff Group Deleted Successfully", WFMLogger.LogCategory.InfoLog);
                    RemoveSPGroup(oSiteId, oWebId, Constants.GroupNames.WFM_ADMIN_GROUP);
                    WFMLogger.LogTraceInformation("WFM Admin Group Deleted Successfully", WFMLogger.LogCategory.InfoLog);
                }
            }

        }

        public static void RemoveUnusedSiteGroups(Guid oSiteId, Guid oWebId)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite oSite = new SPSite(oSiteId))
                {
                    using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                    {
                        List<int> SPGroupIDs = new List<int>();
                        foreach (SPGroup group in oWeb.SiteGroups)
                        {
                            if (group.ID != oWeb.AssociatedOwnerGroup.ID && !group.Name.Equals(Constants.GroupNames.AGENTS_GROUP) 
                                && !group.Name.Equals(Constants.GroupNames.MANAGERS_GROUP) && !group.Name.Equals(Constants.GroupNames.WFM_STAFF_GROUP))
                            {
                                SPGroupIDs.Add(group.ID);
                            }
                        }

                        foreach (int groupID in SPGroupIDs)
                        {
                            try
                            {
                                oWeb.SiteGroups.RemoveByID(groupID);
                            }
                            catch (Exception e)
                            {
                                ExceptionHelper.HandleException(new Exception(string.Format("Error occurred while removing unused site groups for group: {0}", groupID.ToString()), e), ExceptionPolicy.BOExceptionPolicy, true);
                            }
                        }
                    }
                }
            });
        }

        private static void RemoveSPGroup(Guid oSiteId, Guid oWebId, string strGroupName)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite oSite = new SPSite(oSiteId))
                {
                    using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                    {
                        if (GroupHelper.IsGroupExists(oSiteId, oWebId, strGroupName))
                        {
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.SiteGroups.Remove(strGroupName);
                            oWeb.AllowUnsafeUpdates = false;
                        }
                    }
                }
            });
        }
    }
}
