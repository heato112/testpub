﻿     var fieldAgentName = 'AgentName';
     var fieldRequestType = 'RequestType';
     var fieldComments = 'Comments';
     var fieldStatus = 'Status';
     var fieldNotes = 'Notes';
	 var fieldEventDate = 'EventDate';
	 var fieldWFMName = 'WFMName';
	 var fieldCCManagerEmail = 'CCManagerEmail';
     
     var currentPage = location.toString();
     var agentQueuePage = "libraries/landingpages/agenthome.aspx";
     var managerQueuePage = "libraries/landingpages/managerhome.aspx";
     var wfmQueuePage = "libraries/landingpages/wfmstaffhome.aspx";
     var homePage = "sitepages/home.aspx";
     var newTicketPage = "WFMTickets/NewForm.aspx";
     var editTicketPage = "WFMTickets/EditForm.aspx";
     var viewTicketPage = "WFMTickets/DispForm.aspx";
     var allTicketPage = "lists/wfmtickets/allitems.aspx";
     var searchDatePage = "searchpages/searchdate.aspx";
     var searchNumberPage = "searchpages/searchnumber.aspx";

	 var wfmManagerGroup = "WFM Staff Group";
	 var agentsGroup = "WFM Agents Group";
	 var managersGroup = "WFM Managers Group";
     
     var isWFMStaff = false;
     var isAgent = false;
     var isManager = false; 		
     var roleSet = false; 
     var userACF2 = "";
	 var userName = "";
	 var userLoginName = "";
	 var userEmail = "";
	 var currentUserProfile = "";

	 var wfmStaffFieldsToShow = [fieldAgentName, fieldRequestType, fieldComments, fieldStatus, fieldNotes, fieldEventDate, fieldCCManagerEmail];
	 var wfmStaffViewFormFieldsToShow = [fieldAgentName, fieldRequestType, fieldComments, fieldEventDate, fieldStatus, fieldNotes, fieldWFMName, fieldCCManagerEmail];
     var NewFormFieldsToShow = [fieldAgentName ,fieldRequestType ,fieldComments, fieldEventDate  ];
     var agentManagerViewFormFieldsToShow = [fieldAgentName, fieldRequestType, fieldComments, fieldStatus, fieldEventDate];
     var fields = "";

     if (currentPage.toLowerCase().indexOf(allTicketPage) != -1 || currentPage.toLowerCase().indexOf(homePage) != -1) {
         determineRole();

         var url = window.location.href;
         url = url.toLowerCase();

         if (isWFMStaff) {
             url = url.replace(allTicketPage.toLowerCase(), wfmQueuePage);
             url = url.replace(homePage.toLowerCase(), wfmQueuePage);
             $(location).attr('href', url); 
         }
         else if (isManager) {
             url = url.replace(allTicketPage.toLowerCase(), managerQueuePage);
             url = url.replace(homePage.toLowerCase(), managerQueuePage);
             $(location).attr('href', url);
         }
         else if (isAgent) {
             url = url.replace(allTicketPage.toLowerCase(), agentQueuePage);
             url = url.replace(homePage.toLowerCase(), agentQueuePage);
             $(location).attr('href', url);
         }

     }

     if (currentPage.indexOf(newTicketPage) != -1 || currentPage.indexOf(editTicketPage) != -1 || currentPage.indexOf(viewTicketPage) != -1) {
         determineRole();
         showAndHideFields();
         document.getElementById("MSOZoneCell_WebPartWPQ2").style.display = "block";
     }
     else if (currentPage.indexOf(allTicketPage) === -1) {
         verifyPermissionsAndRedirect();
         document.getElementById("MSOZoneCell_WebPartWPQ2").style.display = "block";
     }

	 if(currentPage.indexOf(editTicketPage) != -1){	 
	 	setEditFormFieldsFields();	
	 }
	 else if(currentPage.indexOf(newTicketPage) != -1){
	 	filterRequestTypeDropDown();
	 	setNewFormFieldsFields();
     }
     else if (currentPage.indexOf(viewTicketPage) != -1) {
        $("#s4-ribbonrow").hide();
        var newHeight = $(document).height();
         $("#s4-workspace").height(newHeight);
     }

	 function setNewFormFieldsFields(){
	     var selectAgentEmpty = false;

		     if(isAgent){				  
		          $("div[title='External Item Picker']").hide();
				  $("a[title='Check if External Item exists']").hide();
				  $("a[title='Select External Item(s)']").hide();
				  $("<label>"+userName+"</label>").insertAfter( "div[title='External Item Picker']");
				  setSelectedAgent();
	 		 }
	 		 
	 		 $('select[title="Status Required Field"]').val("1");


	 		 $(".ms-formvalidation").each(function (index) {
	 		     if (typeof $(this).attr('role') != 'undefined') {
	 		         selectAgentEmpty = true;
	 		     }
	 		 });

	 		 if (!selectAgentEmpty) {
	 		     $('.ms-usereditor span.ms-error:contains("External Data")').hide();
	 		 }

             $("<p style='margin:0px; padding:0px;padding-top: 6px'><span style='color:red'><b>Attention:</b></span><span> If the ticket is in regards to a schedule change within the next 48 hours please contact your Manager. Thank you.</span></p>").insertAfter($("span[id*=DateTimeField]"));
	 
     }
	 
	 function setEditFormFieldsFields(){
	 
	 		 if(isWFMStaff){
	 		 
	 		 	 if($("select[title='Status Required Field'] option:selected").text() === "Open")
	 		 	 {
	 		 	     setStaffEditForm();
				}
				else{

				    if ($("select[title='Status Required Field'] option:selected").text() === "Approved" || $("select[title='Status Required Field'] option:selected").text() === "Denied") {

				        var ccEmail = $('input[title="CC Manager Email"]').val();
				        if (ccEmail.length > 0) {
				            if (validateEmail(ccEmail)) {
				                setEntireFormToReadOnly();
				            }
				            else {
				                setStaffEditForm();
				            }
				        }
				        else {
				            setEntireFormToReadOnly();
				        }

				    }
				    else {

				        setEntireFormToReadOnly();
				    }
				}
				
			 }
			 else{
			 	
			 	setEntireFormToReadOnly();
			 }

	 }

	 	 
	 function setEntireFormToReadOnly(){

	     var url = window.location.href;
	     url = url.replace("EditForm.aspx", "DispForm.aspx");
	     $(location).attr('href', url);

	 	 var agentName =  $("div[title='External Item Picker']").text();
		 var requestType =  $("select[title='Request Type Required Field'] option:selected").text();
		 var status =  $("select[title='Status Required Field'] option:selected").text();
		
		 $("div[title='External Item Picker']").hide();				  
		 $("a[title='Check if External Item exists']").hide();
		 $("a[title='Select External Item(s)']").hide();
	
		 $("select[title='Request Type Required Field']").hide();
		 $("select[title='Status Required Field']").hide();
		 
		 
		 $("<label>"+agentName+"</label>").insertAfter( "div[title='External Item Picker']");
		 $("<label>"+requestType+"</label>").insertAfter( "select[title='Request Type Required Field']");
		 $("<label>"+status+"</label>").insertAfter( "select[title='Status Required Field']");
		 
		 $("textarea[title='Comments']").attr('readonly', true); 
		 $("textarea[title='Comments']").attr('style', 'background-color:#D2D2D2');
		
		 $("textarea[title='Notes']").attr('readonly', true);
		 $("textarea[title='Notes']").attr('style', 'background-color:#D2D2D2');
		 
		 $("img[alt='Select a date from the calendar.'").attr('style', 'display:none');

	     $("input[title='Event Date']").attr('readonly', true); 
		 $("input[title='Event Date']").attr('style', 'background-color:#D2D2D2');
		
		 $("input[title='Start Date']").attr('readonly', true);
		 $("input[title='Start Date']").attr('style', 'background-color:#D2D2D2');
			
		 $("input[title='End Date']").attr('readonly', true);
		 $("input[title='End Date']").attr('style', 'background-color:#D2D2D2');

	 }
	 
	 
	 function isCurrentUserInGroup(groupName,returnGroupName){
			 var ui, ug, result;
			 ui = getUserInfo_v2(_spUserId);
			 userLoginName = ui['Name'];

			 currentUserProfile = getUserProfileByAccountName();
			 userACF2 = currentUserProfile['nylACF2'];
			 userName = currentUserProfile['FirstName'] + " " + currentUserProfile['LastName'] + " " + "(" + currentUserProfile['nylACF2'] + ")";
			 userEmail = currentUserProfile['WorkEmail'];

			 ug = getGroupCollectionFromUser(userLoginName);
			 result = false;
			 
			 $.each(ug,function(i,obj){
				 if(obj.groupName===groupName){
				 if(returnGroupName){
				 	result = obj.groupName;
				 }else{
					 result = true;
					 roleSet = true;
				 }
				 return false;
			 }
			 
			 });
			 return result;
	 }
		 	 
	function getGroupCollectionFromUser(userLoginName,userListBaseUrl){
	
			 if(userListBaseUrl===undefined){
				 userListBaseUrl = L_Menu_BaseUrl;
			 }
			 
			 var result = [];
			 
			 spjs_wrapSoapRequest(userListBaseUrl + '/_vti_bin/usergroup.asmx',
			'http://schemas.microsoft.com/sharepoint/soap/directory/GetGroupCollectionFromUser',
			'<GetGroupCollectionFromUser xmlns="http://schemas.microsoft.com/sharepoint/soap/directory/"><userLoginName>' + userLoginName + '</userLoginName></GetGroupCollectionFromUser>',
			
			function(data){
			 $('Group', data).each(function(idx, itemData){
			 	result.push({"groupId":parseInt($(itemData).attr('ID'),10),"groupName":$(itemData).attr('Name')});
			 });
			});
			
			return result;
	}

	function hideAllButThese(arrToShow){
	
			 $.each(fields,function(fin){
				 if($.inArray(fin,arrToShow)===-1){
				 	$(fields[fin]).hide();
				 }else{
				 	$(fields[fin]).show();
				 }
			 });
	}
	
	
	function hideFields(arrToShow){
		$.each(fields,function(fin){
				 if($.inArray(fin,arrToShow)!== -1){
				 	$(fields[fin]).hide();
				 }
		});
	}


	function showFields(arrToShow){
		$.each(fields,function(fin){
				 if($.inArray(fin,arrToShow)!== -1){
				 	$(fields[fin]).show();
				 }
		});
	}
		
	function filterRequestTypeDropDown(){
			$().SPServices.SPFilterDropdown({
			  relationshipList: "RequestType",
			  relationshipListColumn: "Title",
			  columnName: "Request Type",
			  CAMLQuery: "<Eq><FieldRef Name='Active' /><Value Type='Boolean'>1</Value></Eq>",
			  completefunc: null,
			  debug: false
			});
	}
	 
     function determineRole(groupName){
     
		 isAgent = isCurrentUserInGroup(agentsGroup,false);
		
		 if(!isAgent)
		 {
		 	isWFMStaff = isCurrentUserInGroup(wfmManagerGroup,false);
		 }
		
		 if(!isWFMStaff && !isAgent){
		 	isManager = isCurrentUserInGroup(managersGroup,false);
		 }
		 
     }
     
     function showAndHideFields(){
     
     	 fields = init_fields_v2();

     	 if(currentPage.indexOf(viewTicketPage) != -1 && isWFMStaff){ ///Staff role and view page
			hideAllButThese(wfmStaffViewFormFieldsToShow);
		 }
		 else if(isWFMStaff){ //staff and edit or new page
		 	hideAllButThese(wfmStaffFieldsToShow);
		 }
		 else if(currentPage.indexOf(newTicketPage) != -1) //agent or manager and new ticket page
		 {
		    hideAllButThese(NewFormFieldsToShow);
		 }
		 else //agent or manager view page
		 {
		 	hideAllButThese(agentManagerViewFormFieldsToShow); 
		 }
		 
     }
	 
	 function setSelectedAgent(){ 
	 	  $("div[title='External Item Picker']").html(userACF2);
	 	  $("a[title='Check if External Item exists']").trigger("onclick");
	}

	function setWFMInfo() {
	    $('input[title="WFM Team Member Name"]').val(userName);
	    $('input[title="WFM ACF2"]').val(userACF2);
	    //$('input[title="WFMNYLUID"]').val(userUID);
	    $('input[title="WFM Email"]').val(userEmail);
	}

	function verifyPermissionsAndRedirect() {
	    var url = window.location.href;
	    url = url.toLowerCase();

	    determineRole();

	    if (currentPage.toLowerCase().indexOf(wfmQueuePage) != -1) {

	        if (isManager) {
	            url = url.replace(wfmQueuePage.toLowerCase(), managerQueuePage);
	            $(location).attr('href', url);
	        }
	        else if (isAgent) {
	            url = url.replace(wfmQueuePage.toLowerCase(), agentQueuePage);
	            $(location).attr('href', url);
	        }


	        $("div[displayname='Agent Name: ManagerName']").text("Manager Name");
	    }
	    else if (currentPage.toLowerCase().indexOf(agentQueuePage) != -1) {

	        if (isManager) {
	            url = url.replace(agentQueuePage.toLowerCase(), managerQueuePage);
	            $(location).attr('href', url);
	        }
	        else if (isWFMStaff) {
	            url = url.replace(agentQueuePage.toLowerCase(), wfmQueuePage);
	            $(location).attr('href', url);
	        }

	    }
	    else if (currentPage.toLowerCase().indexOf(managerQueuePage) != -1) {

	        if (isWFMStaff) {
	            url = url.replace(managerQueuePage.toLowerCase(), wfmQueuePage);
	            $(location).attr('href', url);
	        }
	        else if (isAgent) {
	            url = url.replace(managerQueuePage.toLowerCase(), agentQueuePage);
	            $(location).attr('href', url);
	        }


	    }
        else if (currentPage.toLowerCase().indexOf(searchDatePage) != -1) {

	        if (isAgent) {
	            url = url.replace(searchDatePage.toLowerCase(), agentQueuePage);
	            $(location).attr('href', url);
	        }


	        $("div[displayname='Agent Name: ManagerName']").text("Manager Name");

	    } 
        else if (currentPage.toLowerCase().indexOf(searchNumberPage) != -1) {

	        if (isAgent) {
	            url = url.replace(searchNumberPage.toLowerCase(), agentQueuePage);
	            $(location).attr('href', url);
	        }


	        $("div[displayname='Agent Name: ManagerName']").text("Manager Name");

	    }
	}


	function getUserProfileByAccountName(){
		return spjs.utility.userProfile();
    }

    function validateEmail(inputText) {
        var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        if (filter.test(inputText)) {
            return true;
        }
        else {
            return false;
        }
    }

    function setStaffEditForm(){
                     var agentName =  $("div[title='External Item Picker']").text();
		 		     var requestType =  $("select[title='Request Type Required Field'] option:selected").text();
					 
					
				 	 $("div[title='External Item Picker']").hide();				  
				 	 $("a[title='Check if External Item exists']").hide();
					 $("a[title='Select External Item(s)']").hide();
	
				     $("select[title='Request Type Required Field']").hide();
				     $("<label>"+agentName+"</label>").insertAfter( "div[title='External Item Picker']");
					 $("<label>"+requestType+"</label>").insertAfter( "select[title='Request Type Required Field']");
					 $("textarea[title='Comments']").attr('readonly', true);
					 $("textarea[title='Comments']").attr('style', 'background-color:#D2D2D2');

					 setWFMInfo();
    }


	
        
