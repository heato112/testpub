﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace WFM.Common
{
    public class PermissionHelper
    {
        /// <summary>
        /// Assigns permission to a site
        /// </summary>
        /// <param name="oSiteId">ID of Site collection</param>
        /// <param name="oGroupName">Name of SharePoint group that will be assigned permission</param>
        /// <param name="oRolePermission">Type of permission to be applied</param>
        /// <returns>True if Assigning of permission was successful, false otherwise</returns>
        public static void AssignSitePermission(Guid oSiteId, Guid oWebId, string oGroupName, SPRoleType oRolePermission)
        {
            // DO not add Trace logging in this method & Try/Catch

            //if (!GroupHelper.IsGroupExists(oSiteId, oGroupName))
            //throw new AuthorizationGroupNotFoundException(oGroupName, Convert.ToString(oSiteId));

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite oSite = new SPSite(oSiteId))
                {
                    using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                    {
                        oWeb.AllowUnsafeUpdates = true;

                        SPGroup group = oWeb.SiteGroups[oGroupName];

                        SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(oRolePermission);
                        SPRoleAssignment roleAssigment = new SPRoleAssignment(group);
                        roleAssigment.RoleDefinitionBindings.Add(roleDefinition);
                        oWeb.RoleAssignments.AddToCurrentScopeOnly(roleAssigment);

                        oWeb.AllowUnsafeUpdates = false;

                    }
                }
            });
        }

        /// <summary>
        /// Assigns permission to a List/Library
        /// </summary>
        /// <param name="oSiteId">ID of Site collection</param>
        /// <param name="oGroupName">Name of SharePoint group that will be assigned permission</param>
        /// <param name="oRolePermission">Type of permission to be applied</param>
        /// <param name="oListName">Name of List on which permission will be mapped</param>
        /// <returns>True if Assigning of permission was successful, false otherwise </returns>
        public static void AssignListPermission(Guid oSiteId, Guid oWebId, string oGroupName, SPRoleType oRolePermission, string oListName)
        {
            // DO not add Trace logging in this method & Try/Catch
            //if (!GroupHelper.IsGroupExists(oSiteId, oGroupName))
            //    throw new AuthorizationGroupNotFoundException(oGroupName, Convert.ToString(oSiteId));

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite oSite = new SPSite(oSiteId))
                {
                    using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                    {
                        oWeb.AllowUnsafeUpdates = true;

                        SPList oList = oWeb.Lists.TryGetList(oListName);
                        //if (oList == null)
                        //    throw new ListNotFoundException(Convert.ToString(oSiteId), Convert.ToString(oWeb.ID), oListName);

                        SPGroup group = oWeb.SiteGroups[oGroupName];
                        SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(oRolePermission);
                        SPRoleAssignment roleAssigment = new SPRoleAssignment(group);
                        roleAssigment.RoleDefinitionBindings.Add(roleDefinition);
                        oList.RoleAssignments.AddToCurrentScopeOnly(roleAssigment);

                        oWeb.AllowUnsafeUpdates = false;
                    }
                }
            });
        }

        public static void AssignListPermission(Guid oSiteId, Guid oWebId, string oGroupName, string RoleDefinationName, string oListName)
        {
            // DO not add Trace logging in this method & Try/Catch
            //if (!GroupHelper.IsGroupExists(oSiteId, oGroupName))
            //    throw new AuthorizationGroupNotFoundException(oGroupName, Convert.ToString(oSiteId));

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite oSite = new SPSite(oSiteId))
                {
                    using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                    {
                        oWeb.AllowUnsafeUpdates = true;

                        SPList oList = oWeb.Lists.TryGetList(oListName);
                        //if (oList == null)
                        //    throw new ListNotFoundException(Convert.ToString(oSiteId), Convert.ToString(oWeb.ID), oListName);

                        SPGroup group = oWeb.SiteGroups[oGroupName];
                        SPRoleDefinition roleDefinition = GetSpecialContributeAddEditOnlyAccess(oWeb, RoleDefinationName);
                        SPRoleAssignment roleAssigment = new SPRoleAssignment(group);
                        roleAssigment.RoleDefinitionBindings.Add(roleDefinition);
                        oList.RoleAssignments.AddToCurrentScopeOnly(roleAssigment);

                        oWeb.AllowUnsafeUpdates = false;
                    }
                }
            });
        }
        public static void AssignGroupSpecialContributeAddOnlyAccessPermission(Guid oSiteId, Guid oWebId, string oGroupName)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite oSite = new SPSite(oSiteId))
                {
                    using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                    {

                        try
                        {
                            oWeb.AllowUnsafeUpdates = true;

                            SPGroup group = oWeb.SiteGroups[oGroupName];

                            SPRoleDefinition roleDefinition = GetSpecialContributeAddOnlyAccess(oWeb);
                            SPRoleAssignment roleAssigment = new SPRoleAssignment(group);
                            roleAssigment.RoleDefinitionBindings.Add(roleDefinition);
                            oWeb.RoleAssignments.AddToCurrentScopeOnly(roleAssigment);

                            oWeb.AllowUnsafeUpdates = false;
                        }
                        catch (Exception ex)
                        {
                            //WFMLogger.LogException(new Exception("Error occured while assigning Add Only Group Permission ",ex));
                            ExceptionHelper.HandleException(new Exception("Error occured while assigning Add Only Group Permission", ex), ExceptionPolicy.BOExceptionPolicy);
                        }
                    }
                }
            });

        }

        public static void AssignGroupSpecialContributeEditOnlyAccessPermission(Guid oSiteId, Guid oWebId, string oGroupName)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite oSite = new SPSite(oSiteId))
                {
                    using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                    {
                        try
                        {
                            oWeb.AllowUnsafeUpdates = true;

                            SPGroup group = oWeb.SiteGroups[oGroupName];

                            SPRoleDefinition roleDefinition = GetSpecialContributeEditOnlyAccess(oWeb);
                            SPRoleAssignment roleAssigment = new SPRoleAssignment(group);
                            roleAssigment.RoleDefinitionBindings.Add(roleDefinition);
                            oWeb.RoleAssignments.AddToCurrentScopeOnly(roleAssigment);

                            oWeb.AllowUnsafeUpdates = false;
                        }
                        catch (Exception ex)
                        {
                             //WFMLogger.LogException(new Exception("Error occured while assigning Edit Only Group Permission ",ex));
                            ExceptionHelper.HandleException(new Exception("Error occured while assigning Edit Only Group Permission", ex), ExceptionPolicy.BOExceptionPolicy);
                        }
                    }
                }
            });

        }

        private static SPRoleDefinition GetSpecialContributeAddOnlyAccess(SPWeb web)
        {
            // DO not add Trace logging in this method & Try/Catch
            string strRoleDefinition = Constants.PermissionLevel.SPECIAL_CONTRIBUTE_ADD_ONLY_ACCESS;

            // only exists in webs with unique role definitions
            if (web.HasUniqueRoleDefinitions)
            {
                try
                {
                    // try to retrieve the role definition
                    return web.RoleDefinitions[strRoleDefinition];
                }
                catch (SPException)
                {
                    // SPException means it does not exist

                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        // create our custom limited access role
                        SPRoleDefinition roleDef = new SPRoleDefinition();

                        // give it a name and description
                        roleDef.Name = Constants.PermissionLevel.SPECIAL_CONTRIBUTE_ADD_ONLY_ACCESS;
                        roleDef.Description = "Identical to standard " +
                            "Contribute Access rights. " +
                            "Used to provide contribute access Add Only without delete permission ";

                        // apply the base permissions required
                        roleDef.BasePermissions = SPBasePermissions.ViewListItems
                            | SPBasePermissions.AddListItems
                            //| SPBasePermissions.EditListItems
                            | SPBasePermissions.OpenItems
                            | SPBasePermissions.ViewVersions
                            | SPBasePermissions.ManagePersonalViews
                            | SPBasePermissions.ViewFormPages
                            | SPBasePermissions.Open
                            | SPBasePermissions.ViewPages
                            | SPBasePermissions.CreateSSCSite
                            | SPBasePermissions.BrowseDirectories
                            | SPBasePermissions.BrowseUserInfo
                            | SPBasePermissions.AddDelPrivateWebParts
                            | SPBasePermissions.UpdatePersonalWebParts
                            | SPBasePermissions.UseClientIntegration
                            | SPBasePermissions.UseRemoteAPIs
                            | SPBasePermissions.CreateAlerts
                            | SPBasePermissions.EditMyUserInfo;

                        // add it to the web
                        web.RoleDefinitions.Add(roleDef);
                    });
                }

                return web.RoleDefinitions[strRoleDefinition];
            }
            else
            {
                // try the parent web

                return GetSpecialContributeAddOnlyAccess(web.ParentWeb);
            }

        }

        private static SPRoleDefinition GetSpecialContributeEditOnlyAccess(SPWeb web)
        {
            // DO not add Trace logging in this method & Try/Catch
            string strRoleDefinition = Constants.PermissionLevel.SPECIAL_CONTRIBUTE_EDIT_ONLY_ACCESS;

            // only exists in webs with unique role definitions
            if (web.HasUniqueRoleDefinitions)
            {
                try
                {
                    // try to retrieve the role definition
                    return web.RoleDefinitions[strRoleDefinition];
                }
                catch (SPException)
                {
                    // SPException means it does not exist

                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        // create our custom limited access role
                        SPRoleDefinition roleDef = new SPRoleDefinition();

                        // give it a name and description
                        roleDef.Name = Constants.PermissionLevel.SPECIAL_CONTRIBUTE_EDIT_ONLY_ACCESS;
                        roleDef.Description = "Identical to standard " +
                            "Contribute Access rights. " +
                            "Used to provide contribute access Edit Only without delete permission ";

                        // apply the base permissions required
                        roleDef.BasePermissions = SPBasePermissions.ViewListItems
                            //| SPBasePermissions.AddListItems
                            | SPBasePermissions.EditListItems
                            | SPBasePermissions.OpenItems
                            | SPBasePermissions.ViewVersions
                            | SPBasePermissions.ManagePersonalViews
                            | SPBasePermissions.ViewFormPages
                            | SPBasePermissions.Open
                            | SPBasePermissions.ViewPages
                            //| SPBasePermissions.CreateSSCSite
                            | SPBasePermissions.BrowseDirectories
                            | SPBasePermissions.BrowseUserInfo
                            | SPBasePermissions.AddDelPrivateWebParts
                            | SPBasePermissions.UpdatePersonalWebParts
                            | SPBasePermissions.UseClientIntegration
                            | SPBasePermissions.UseRemoteAPIs
                            | SPBasePermissions.CreateAlerts
                            | SPBasePermissions.EditMyUserInfo;

                        // add it to the web
                        web.RoleDefinitions.Add(roleDef);
                    });
                }

                return web.RoleDefinitions[strRoleDefinition];
            }
            else
            {
                // try the parent web

                return GetSpecialContributeEditOnlyAccess(web.ParentWeb);
            }

        }

        private static SPRoleDefinition GetSpecialContributeAddEditOnlyAccess(SPWeb web, string RoleDefinitionName)
        {
            // DO not add Trace logging in this method & Try/Catch
            //string strRoleDefinition = Constants.PermissionLevel.SPECIAL_CONTRIBUTE_EDIT_ONLY_ACCESS;

            // only exists in webs with unique role definitions
            if (web.HasUniqueRoleDefinitions)
            {
                try
                {
                    // try to retrieve the role definition
                    return web.RoleDefinitions[RoleDefinitionName];
                }
                catch (SPException)
                {
                    // SPException means it does not exist

                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        // create our custom limited access role
                        SPRoleDefinition roleDef = new SPRoleDefinition();

                        // give it a name and description
                        roleDef.Name = RoleDefinitionName;
                        roleDef.Description = "Identical to standard " +
                            "Contribute Access rights. " +
                            "Used to provide contribute access Edit Only without delete permission ";

                        // apply the base permissions required
                        roleDef.BasePermissions = SPBasePermissions.ViewListItems
                            | SPBasePermissions.AddListItems
                            | SPBasePermissions.EditListItems
                            | SPBasePermissions.OpenItems
                            | SPBasePermissions.ViewVersions
                            | SPBasePermissions.ManagePersonalViews
                            | SPBasePermissions.ViewFormPages
                            | SPBasePermissions.Open
                            | SPBasePermissions.ViewPages
                            //| SPBasePermissions.CreateSSCSite
                            | SPBasePermissions.BrowseDirectories
                            | SPBasePermissions.BrowseUserInfo
                            | SPBasePermissions.AddDelPrivateWebParts
                            | SPBasePermissions.UpdatePersonalWebParts
                            | SPBasePermissions.UseClientIntegration
                            | SPBasePermissions.UseRemoteAPIs
                            | SPBasePermissions.CreateAlerts
                            | SPBasePermissions.EditMyUserInfo;

                        // add it to the web
                        web.RoleDefinitions.Add(roleDef);
                    });
                }

                return web.RoleDefinitions[RoleDefinitionName];
            }
            else
            {
                // try the parent web

                return GetSpecialContributeAddEditOnlyAccess(web.ParentWeb, RoleDefinitionName);
            }

        }
      

        /// <summary>
        /// Breaks permission inheritance for a List/Library
        /// </summary>
        /// <param name="oSiteId">ID of Site collection</param>
        /// /// <param name="oWebId">ID of Web</param>
        /// <param name="oList">List on which permission will be mapped</param>
        public static void BreakListInheritance(Guid oSiteId, Guid oWebId, string listName)
        {
            // DO not add Trace logging in this method & Try/Catch

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite oSite = new SPSite(oSiteId))
                {
                    using (SPWeb oWeb = oSite.OpenWeb(oWebId))
                    {
                        oWeb.AllowUnsafeUpdates = true;

                        SPList list = oWeb.Lists.TryGetList(listName);
                        //if (list == null)
                        //    throw new ListNotFoundException(Convert.ToString(oSiteId), Convert.ToString(oWeb.ID), Convert.ToString(oList.Title));

                        list.BreakRoleInheritance(false, true);

                        oWeb.AllowUnsafeUpdates = false;
                    }
                }
            });
        }

        public static void DeleteUserPermissionsFromListItem(SPListItem itemRecord)
        {
            SPRoleAssignmentCollection SPRoleAssColn = itemRecord.RoleAssignments;

            for (int i = SPRoleAssColn.Count - 1; i >= 0; i--)
            {
                SPRoleAssColn.Remove(i);
            }
        }

        public static void AssignBlockedUsersListPermission(Guid oSiteId, Guid oWebId, string ownerGroupName)
        {
            try
            {
                BreakListInheritance(oSiteId, oWebId, Constants.ListName.BLOCKED_USERS);
                AssignListPermission(oSiteId, oWebId, Constants.GroupNames.WFM_STAFF_GROUP, SPRoleType.Contributor, Constants.ListName.BLOCKED_USERS);
                AssignListPermission(oSiteId , oWebId, ownerGroupName, SPRoleType.Contributor, Constants.ListName.BLOCKED_USERS);
            }
            catch (Exception ex)
            {
                //WFMLogger.LogException(new Exception("Error occured while assigning permission to Blocked Users List",ex));
                ExceptionHelper.HandleException(new Exception("Error occured while assigning permission to Blocked Users List", ex), ExceptionPolicy.BOExceptionPolicy, true);
            }
        }

        public static void AssignRequestTypeListPermission(Guid oSiteId, Guid oWebId, string ownerGroupName)
        {
            try
            {
                BreakListInheritance(oSiteId, oWebId, Constants.ListName.REQUEST_TYPE);
                AssignListPermission(oSiteId, oWebId, Constants.GroupNames.WFM_ADMIN_GROUP, Constants.PermissionLevel.SPECIAL_CONTRIBUTE_ADD_EDIT_ONLY_ACCESS,Constants.ListName.REQUEST_TYPE);
                AssignListPermission(oSiteId, oWebId, ownerGroupName, SPRoleType.Contributor, Constants.ListName.REQUEST_TYPE);
                AssignListPermission(oSiteId, oWebId, Constants.GroupNames.WFM_ADMIN_GROUP, SPRoleType.Reader, Constants.ListName.REQUEST_TYPE);
                AssignListPermission(oSiteId, oWebId, Constants.GroupNames.AGENTS_GROUP, SPRoleType.Reader, Constants.ListName.REQUEST_TYPE);
                AssignListPermission(oSiteId, oWebId, Constants.GroupNames.MANAGERS_GROUP, SPRoleType.Reader, Constants.ListName.REQUEST_TYPE);
                AssignListPermission(oSiteId, oWebId, Constants.GroupNames.WFM_STAFF_GROUP, SPRoleType.Reader, Constants.ListName.REQUEST_TYPE);
            }
            catch (Exception ex)
            {
                ExceptionHelper.HandleException(new Exception("Error occured while assigning permission to Request Type List", ex), ExceptionPolicy.BOExceptionPolicy, true);
            }
        }

        public static void AssignReportsTemplateListPermission(Guid oSiteId, Guid oWebId, string ownerGroupName)
        {
            try
            {
                BreakListInheritance(oSiteId, oWebId, Constants.ListName.REPORTS_TEMPLATE_LIST);
                AssignListPermission(oSiteId, oWebId, ownerGroupName, SPRoleType.Reader, Constants.ListName.REPORTS_TEMPLATE_LIST);
                AssignListPermission(oSiteId, oWebId, Constants.GroupNames.WFM_ADMIN_GROUP, SPRoleType.Reader, Constants.ListName.REPORTS_TEMPLATE_LIST);
                AssignListPermission(oSiteId, oWebId, Constants.GroupNames.AGENTS_GROUP, SPRoleType.Reader, Constants.ListName.REPORTS_TEMPLATE_LIST);
                AssignListPermission(oSiteId, oWebId, Constants.GroupNames.MANAGERS_GROUP, SPRoleType.Reader, Constants.ListName.REPORTS_TEMPLATE_LIST);
                AssignListPermission(oSiteId, oWebId, Constants.GroupNames.WFM_STAFF_GROUP, SPRoleType.Reader, Constants.ListName.REPORTS_TEMPLATE_LIST);
            }
            catch (Exception ex)
            {
                ExceptionHelper.HandleException(new Exception("Error occured while assigning permission to Reports Template List", ex), ExceptionPolicy.BOExceptionPolicy, true);
            }
        }

    }
}
