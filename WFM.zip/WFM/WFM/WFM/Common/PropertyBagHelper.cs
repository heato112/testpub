﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace NYL.WFM.Common
{
    public static class PropertyBagHelper
    {
     
            public static void AddProperty( SPWeb web, string key, string value)
            {
                web.AllowUnsafeUpdates = true;

                if (web.AllProperties.ContainsKey(key))
                {
                    RemoveProperty(web, key);
                }

                web.Properties[key] = value;
                web.AllProperties[key] = value;
                web.Update();
                web.Properties.Update();
            }


            public static void RemoveProperty( SPWeb web, string key)
            {
                web.AllowUnsafeUpdates = true;
                web.AllProperties.Remove(key);
                web.Properties[key] = null;
                web.Update();
                web.Properties.Update();
            }


            public static string GetPropertyValue( SPWeb web, string key)
            {
                if (web.AllProperties.ContainsKey(key))
                    return web.AllProperties[key].ToString();

                return null;
            }
    }
}
