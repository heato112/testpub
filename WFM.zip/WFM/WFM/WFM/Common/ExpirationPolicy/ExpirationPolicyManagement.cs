﻿using System;
using Microsoft.Office.RecordsManagement.InformationPolicy;
using Microsoft.SharePoint;
using WFM.Common;

namespace NYL.WFM.Common.ExpirationPolicy
{
    public class ExpirationPolicyManagement
    {
        #region Methods

        /// <summary>
        /// Method to add policy to WFM Tickets list content type
        /// </summary>
        /// <param name="contentTypeName"></param>
        /// <param name="web"></param>
        public static void ApplyWFMTicketsPolicy(string contentTypeName, string listName, SPWeb web)
        {
            try
            {
                string policyXmlData = @"<Schedules nextStageId=""2"">
                                      <Schedule type=""Default"">
                                        <stages>
                                          <data stageId=""1"">
                                            <formula id=""NYL.WFMWFMTicketsExpirationFormula"" />
                                            <action type=""action"" id=""Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration.Action.Delete"" />
                                          </data>
                                        </stages>
                                      </Schedule>
                                    </Schedules>";
                string policyFeatureId = "Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration";
                SPContentTypeCollection contentTypeCollection = web.Lists.TryGetList(listName).ContentTypes;
                SPContentType wfmTicketsContentType = null;
                foreach (SPContentType contentType in contentTypeCollection)
                {
                    if (contentType.Name.Equals(contentTypeName))
                    {
                        wfmTicketsContentType = contentType;
                        break;
                    }
                }

                if (wfmTicketsContentType != null)
                {
                    if (Policy.GetPolicy(wfmTicketsContentType) == null)
                    {
                        //if the content type hasn't got a Policy yet, create a new Policy 
                        Policy.CreatePolicy(wfmTicketsContentType, null);
                    }

                    Policy wfmTicketsPolicy = Policy.GetPolicy(wfmTicketsContentType);

                    //Add expiration policy to the content type 
                    if (wfmTicketsPolicy.Items[policyFeatureId] != null)
                    {
                        //Delete previous policy rules
                        wfmTicketsPolicy.Items.Delete(policyFeatureId);
                    }

                    //Add new policy rules
                    wfmTicketsPolicy.Items.Add(policyFeatureId, policyXmlData);
                }
            }
            catch (Exception ex)
            {
                ExceptionHelper.HandleException(new Exception("Error occurred while applying WFM Tickets records retention policy", ex), ExceptionPolicy.BOExceptionPolicy, true);
            }
        }

        /// <summary>
        /// /Method to add duration in provided date.
        /// </summary>
        /// <param name="date"></param>
        /// <param name="duration"></param>
        public static DateTime GetRetentionExpiryDate(DateTime date, string duration)
        {
            //Duration Pattern: yy-mm-dd-hh-min-ss

            int yy = 0;
            int mm = 0;
            int dd = 0;
            int hh = 0;
            int min = 0;
            int ss = 0;

            if (!string.IsNullOrEmpty(duration))
            {
                string[] arrDuration = duration.Split('-');
                if (arrDuration.Length == 6)
                {
                    yy = Convert.ToInt32(arrDuration[0]);
                    mm = Convert.ToInt32(arrDuration[1]);
                    dd = Convert.ToInt32(arrDuration[2]);
                    hh = Convert.ToInt32(arrDuration[3]);
                    min = Convert.ToInt32(arrDuration[4]);
                    ss = Convert.ToInt32(arrDuration[5]);
                }
            }
            date = date.AddYears(yy);
            date = date.AddMonths(mm);
            date = date.AddDays(dd);
            date = date.AddHours(hh);
            date = date.AddMinutes(min);
            date = date.AddSeconds(ss);
            return date;
        }

        #endregion
    }
}
