﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction "SilentlyContinue"

#### ISO Settings ####
$isoUserPrefix = "i:0ǽ.t|siteminder nyluid|";
$isoGroupPrefix = "c:0ǹ.t|siteminder nyluid|";
$isoSitePrefix = "http://isodev4";
$isoSecureservice_db_userName = "devuser"
$isoSecureservice_db_password = "devuser"
$isoBdcDatabaseServer = "CTISQLM"
$isoBdcDatabase = "cti_admin"

#### DEV Settings ####
$devUserPrefix = "i:0ǵ.t|siteminder|";
$devGroupPrefix =  "c:0ǽ.t|siteminder|";
$devSitePrefix = "https://dev";
$devSecureservice_db_userName = "devuser"
$devSecureservice_db_password = "devuser"
$devBdcDatabaseServer = "CTISQLM"
$devBdcDatabase = "cti_admin"

#### MODEL Settings ####
$mdlUserPrefix = "i:0ǵ.t|siteminder|";
$mdlGroupPrefix =  "c:0ǹ.t|spagencysiteminder|";
$mdlSitePrefix = "https://mdl";
$mdlSecureservice_db_userName = "wfmctiadmin"
$mdlSecureservice_db_password = "FCaI15d23"
$mdlBdcDatabaseServer = "CTISQLM"
$mdlBdcDatabase = "cti_admin"

#### Prod Settings ####
$prodUserPrefix = "i:0ǵ.t|siteminder|"; 
$prodGroupPrefix = "c:0ǿ.t|spagencysiteminder|";
$prodSitePrefix = "https://www";
$prodSecureservice_db_userName = "wfmctiadmin"
$prodSecureservice_db_password = "FCaI15d23"
$prodBdcDatabaseServer = "CTISQLP"
$prodBdcDatabase = "cti_admin"

function EnsureValidNylSharepointEnvironment
{
	$serverName = $env:COMPUTERNAME;
	$environment = $null;

	$serverName = $serverName.ToLower();

	$index = $serverName.IndexOf("iso");

	if ($serverName.Contains("iso") -or $serverName.Contains("is0"))
	{
		$environment = "iso";
	}
	elseif ($serverName.Contains("nyt") -eq $true)
	{
		$environment = "dev";
	}
	elseif ($serverName.Contains("nym") -eq $true)
	{
		$environment = "model";
	}
	elseif ($serverName.Contains("nyp") -eq $true)
	{
		$environment = "prod"
	}
	else
	{
		throw "The server name $env::COMPUTERNAME is not a recognized server for this powershell script. Please run this script on the NYL iso, dev, model, or production Sharepoint farm."
	}

	return $environment
}



function SetUserPrefix($environment)
{
	if ($environment -eq "iso")
	{
		$userprefix = $isoUserPrefix; 
	}
	elseif ($environment -eq "dev")
	{
		$userprefix = $devUserPrefix;
	}
	elseif ($environment -eq "model")
	{
		$userprefix = $mdlUserPrefix;
	}
	elseif ($environment -eq "prod")
	{
		$userprefix = $prodUserPrefix;
	}
	else
	{
		throw "The enviornment $environment is not a recognized environment for this powershell script."
	}

	return $userprefix
}

function SetGroupPrefix($environment)
{
	if ($environment -eq "iso")
	{
		$groupprefix = $isoGroupPrefix;
	}
	elseif ($environment -eq "dev")
	{
		$groupprefix = $devGroupPrefix;
	}
	elseif ($environment -eq "model")
	{
		$groupprefix = $mdlGroupPrefix;
	}
	elseif ($environment -eq "prod")
	{
		$groupprefix = $prodGroupPrefix;
	}
	else
	{
		throw "The enviornment $environment is not a recognized environment for this powershell script."
	}

	return $groupprefix
}


function SetSiteOwner($environment)
{
	if ($environment -eq "iso")
	{
		$siteOwner = $isoSetSiteOwner;
	}
	elseif ($environment -eq "dev")
	{
		$siteOwner = $devSetSiteOwner;
	}
	elseif ($environment -eq "model")
	{
		$siteOwner = $mdlSetSiteOwner;
	}
	elseif ($environment -eq "prod")
	{
		$siteOwner = $prodSetSiteOwner;
	}
	else
	{
		throw "The enviornment $environment is not a recognized environment for this powershell script."
	}

	return $siteOwner
}

function GetSiteCollectionUrl($siteUrl)
{
	
	$sitecollection = $siteUrl;

	if ($environment -eq "iso")
	{
		$sitecollection = $sitecollection.Replace("https://www", $isoSitePrefix)
	}
	elseif ($environment -eq "dev")
	{
		$sitecollection = $sitecollection.Replace("https://www", $devSitePrefix)
	}
	elseif ($environment -eq "model")
	{
		$sitecollection = $sitecollection.Replace("https://www", $mdlSitePrefix)
	}
	elseif ($environment -eq "prod")
	{
		$sitecollection = $sitecollection.Replace("https://www", $prodSitePrefix)
	}

	return $sitecollection
}

function GetSearchContentSourceName($environment)
{
	
	if ($environment -eq "iso")
	{
		$searchAppName = $isoSearchContentSourceName;
	}
	elseif ($environment -eq "dev")
	{
		$searchAppName =  $devSearchContentSourceName;
	}
	elseif ($environment -eq "model")
	{
		$searchAppName =  $mdlSearchContentSourceName;
	}
	elseif ($environment -eq "prod")
	{
		$searchAppName =  $prodSearchContentSourceName;
	}
	else
	{
		throw "The enviornment $environment is not a recognized environment for this powershell script."
	}

	return $searchAppName
}

function GetSecureServicePassword($environment)
{
	
	if ($environment -eq "iso")
	{
		$secureServicePassword = $isoSecureservice_db_password;
	}
	elseif ($environment -eq "dev")
	{
		$secureServicePassword =  $devSecureservice_db_password;
	}
	elseif ($environment -eq "model")
	{
		$secureServicePassword =  $mdlSecureservice_db_password;
	}
	elseif ($environment -eq "prod")
	{
		$secureServicePassword =  $prodSecureservice_db_password;
	}
	else
	{
		throw "The enviornment $environment is not a recognized environment for this powershell script."
	}

	return $secureServicePassword 
}


function GetSecureServiceUserName($environment)
{
	
	if ($environment -eq "iso")
	{
		$secureServiceUserName = $isoSecureservice_db_userName;
	}
	elseif ($environment -eq "dev")
	{
		$secureServiceUserName =  $devSecureservice_db_userName;
	}
	elseif ($environment -eq "model")
	{
		$secureServiceUserName =  $mdlSecureservice_db_userName;
	}
	elseif ($environment -eq "prod")
	{
		$secureServiceUserName =  $prodSecureservice_db_userName;
	}
	else
	{
		throw "The enviornment $environment is not a recognized environment for this powershell script."
	}

	return $secureServiceUserName 
}

function GetBdcDatabaseServer($environment)
{
	
	if ($environment -eq "iso")
	{
		$server = $isoBdcDatabaseServer;
	}
	elseif ($environment -eq "dev")
	{
		$server =  $devBdcDatabaseServer;
	}
	elseif ($environment -eq "model")
	{
		$server =  $mdlBdcDatabaseServer;
	}
	elseif ($environment -eq "prod")
	{
		$server =  $prodBdcDatabaseServer;
	}
	else
	{
		throw "The enviornment $environment is not a recognized environment for this powershell script."
	}

	return $server 
}

function GetBdcDatabaseName($environment)
{
	
	if ($environment -eq "iso")
	{
		$databaseName = $isoBdcDatabase;
	}
	elseif ($environment -eq "dev")
	{
		$databaseName =  $devBdcDatabase;
	}
	elseif ($environment -eq "model")
	{
		$databaseName =  $mdlBdcDatabase;
	}
	elseif ($environment -eq "prod")
	{
		$databaseName =  $prodBdcDatabase;
	}
	else
	{
		throw "The enviornment $environment is not a recognized environment for this powershell script."
	}

	return $databaseName 
}

function SetSearchSiteCollectionUrl($siteUrl)
{
	
	$sitecollection = $siteUrl;

	if ($environment -eq "iso")
	{
		$sitecollection = $sitecollection.Replace("https://www", $isoSearchSitePrefix)
	}
	elseif ($environment -eq "dev")
	{
		$sitecollection = $sitecollection.Replace("https://www", $devSearchSitePrefix)
	}
	elseif ($environment -eq "model")
	{
		$sitecollection = $sitecollection.Replace("https://www", $mdlSearchSitePrefix)
	}
	elseif ($environment -eq "prod")
	{
		$sitecollection = $sitecollection.Replace("https://www", $prodSearchSitePrefix)
	}

	return $sitecollection
}

function SetSearchApplicationName($environment)
{
	
	if ($environment -eq "iso")
	{
		$searchAppName = $isoSearchApplicationName;
	}
	elseif ($environment -eq "dev")
	{
		$searchAppName = $devSearchApplicationName; 
	}
	elseif ($environment -eq "model")
	{
		$searchAppName = $mdlSearchApplicationName;
	}
	elseif ($environment -eq "prod")
	{
		$searchAppName = $prodSearchApplicationName;
	}
	else
	{
		throw "The enviornment $environment is not a recognized environment for this powershell script."
	}

	return $searchAppName
}

function GetContentDatabase($environment)
{
	
	if ($environment -eq "iso")
	{
		$contentDatabase = $isoContentDatabase;
	}
	elseif ($environment -eq "dev")
	{
		$contentDatabase = $devContentDatabase;
	}
	elseif ($environment -eq "model")
	{
		$contentDatabase = $mdlContentDatabase;
	}
	elseif ($environment -eq "prod")
	{
		$contentDatabase = $prodContentDatabase;
	}
	else
	{
		throw "The enviornment $environment is not a recognized environment for this powershell script."
	}

	return $contentDatabase
}


function GetTimerJobServer($environment)
{
	
	if ($environment -eq "iso")
	{
		$timerjobserver = $isoTimerJobServer;
	}
	elseif ($environment -eq "dev")
	{
		$timerjobserver =  $devTimerJobServer;
	}
	elseif ($environment -eq "model")
	{
		$timerjobserver =  $mdlTimerJobServer;
	}
	elseif ($environment -eq "prod")
	{
		$timerjobserver =  $prodTimerJobServer;
	}
	else
	{
		throw "The enviornment $environment is not a recognized environment for this powershell script."
	}

	return $timerjobserver
}


function GetLogFileDirectory($environment)
{
	
	if ($environment -eq "iso")
	{
		$logFileDirectory = $isoLogFileDirectory;
	}
	elseif ($environment -eq "dev")
	{
		$logFileDirectory =  $devLogFileDirectory;
	}
	elseif ($environment -eq "model")
	{
		$logFileDirectory =  $mdlLogFileDirectory;
	}
	elseif ($environment -eq "prod")
	{
		$logFileDirectory =  $prodLogFileDirectory;
	}
	else
	{
		throw "The enviornment $environment is not a recognized environment for this powershell script."
	}

	return $logFileDirectory
}



function ActivateFeature
{
	param ($siteCollectionUrl, $featureGuid)

	#LogMessage "Activating feature $featureGuid on $siteCollectionUrl"

	Enable-SPFeature -Identity $featureGuid -Url $siteCollectionUrl -Confirm:$false -Force -ErrorAction:Continue

	Start-Sleep -s 10

	#LogMessage "Feature Activated."
}

function DeactivateFeature
{
	param ($siteCollectionUrl, $SolutionPackageName, $featureGuid)

	$solution = Get-SPSolution | where-object {$_.Name -eq $SolutionPackageName} 

	if ($solution -ne $null)
	{
		# check to see if solution package is currently deployed
		if($solution.Deployed -eq $true)
		{   
			#LogMessage "Deactivating feature $featureGuid on $siteCollectionUrl"

			Disable-SPFeature -Identity $featureGuid -Url $siteCollectionUrl -Confirm:$false -Force -ErrorAction:SilentlyContinue

			Start-Sleep -s 10

			#LogMessage "Feature Deactivated."
		}
	}
}

function RestartTimerService
{
	
		Write-Host "Stopping timer job..."
		net stop sptimerv4
		start-sleep -s 10
		Write-Host "Starting timer job..."
		net start sptimerv4

}


function ConfigureFarmPropertyBag([string]$propName, [string]$propValue)
{
	$web = Get-SPFarm
	if (!$web.Properties.ContainsKey($propName)) 
	{
		Write-Host -foregroundcolor yellow "- The '$propName' property bag couldn't be found."
		$web.Properties.Add($propName, $propValue);
		Write-Host -foregroundcolor white "- The value of the '$propName' property bag is added"
	} 
	else
	{
		Write-Host -foregroundcolor yellow "- The current value of the '$propName' property bag is " $web.Properties[$propName] "."
		$web.Properties[$propName] = $propValue; 
		Write-Host -foregroundcolor white "- The value of the '$propName' property bag is changed to " $web.Properties[$propName] 
	} 
	$web.Update(); 
}




