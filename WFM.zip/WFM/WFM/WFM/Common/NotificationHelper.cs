﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;
using Microsoft.SharePoint;
using System.Text.RegularExpressions;
using System.IO;
using System.Web;

namespace WFM.Common
{
    public class NotificationHelper
    {
        #region Private Variables

        private string _emailFromAddress;
        private string _emailFromName;
        private string _emailSubject;

        public int OperationType { get; set; }

        #endregion

        public NotificationHelper()
        {
        }

        public NotificationHelper(int opType)
        {
            OperationType = opType;
        }

        public void SendSupportEmail(string emailBody)
        {
            try
            {
                int enableNotification = ConfigurationSettings.getEnableNotification();
                string toEmailAddress = ConfigurationSettings.getSupportEmail();
                string fromEmailAddress = toEmailAddress;
                string subject = Constants.General.SUPPORT_EMAIL_TITLE;

                if (enableNotification == 1 && !string.IsNullOrEmpty(toEmailAddress))
                {
                    SendNotification(toEmailAddress, "", fromEmailAddress, subject, emailBody);
                }
            }
            catch (Exception)
            {
            }
        }

        public void SendNewTicketEmail(string toEmail, string ccEmail, int listItemID)
        {
            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_START, WFMLogger.LogCategory.DebugLog);

            string EmailBody = getEmailContent(Constants.NotificationKey.NEW_TICKET_EMAIL);
            //smruUrl = HttpUtility.UrlDecode(smruUrl);
            if (!string.IsNullOrEmpty(EmailBody))
            {

                _emailSubject = ReplaceEmailInfo(_emailSubject, listItemID);
                EmailBody = ReplaceEmailInfo(EmailBody, listItemID);
               
                int enableNotification = ConfigurationSettings.getEnableNotification();

                if (enableNotification == 1)
                {
                    SendNotification(toEmail, ccEmail, _emailFromAddress, _emailSubject, EmailBody);
                }
            }
            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_END, WFMLogger.LogCategory.DebugLog);

        }

        public void SendUpdateStatusEmail(string toEmail, string ccEmail, int listItemID)
        {
            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_START, WFMLogger.LogCategory.DebugLog);

            string EmailBody = getEmailContent(Constants.NotificationKey.STATUS_UPDATE_EMAIL);
            //smruUrl = HttpUtility.UrlDecode(smruUrl);
            if (!string.IsNullOrEmpty(EmailBody))
            {


                _emailSubject = ReplaceEmailInfo(_emailSubject, listItemID);
                EmailBody = ReplaceEmailInfo(EmailBody, listItemID);
                
                int enableNotification = ConfigurationSettings.getEnableNotification();

                if (enableNotification == 1)
                {
                    SendNotification(toEmail, ccEmail, _emailFromAddress, _emailSubject, EmailBody);
                    
                }
            }
            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_END, WFMLogger.LogCategory.DebugLog);

        }

        #region Private Methods

        private void SendErrorNotification(string emailBody, string emailSubject)
        {
            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_START, WFMLogger.LogCategory.DebugLog);

            try
            {
                string toEmailAddress = ConfigurationSettings.getSupportEmail();

                string fromEmailAddress = toEmailAddress;
                string subject = "RC - " + emailSubject;


                if (!string.IsNullOrEmpty(toEmailAddress))
                {
                    SendNotification(toEmailAddress, "", fromEmailAddress, subject, emailBody);
                }
            }
            catch (Exception ex)
            {
                ExceptionHelper.HandleException(ex, ExceptionPolicy.BOExceptionPolicy);
            }

            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_END, WFMLogger.LogCategory.DebugLog);
        }

        private void SendNotification(string ToEmail, string CCEmail, string FromEmail, string Subject, string EmailBody)
        {
            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_START, WFMLogger.LogCategory.DebugLog);

            try
            {
                string emailCCaddress = CCEmail;

                if (string.IsNullOrEmpty(ToEmail))
                    ToEmail = emailCCaddress;

                MailMessage mail = new MailMessage(FromEmail, ToEmail, Subject, EmailBody);
                if (!emailCCaddress.Equals(string.Empty))
                {
                    mail.CC.Add(emailCCaddress);
                }
                mail.IsBodyHtml = true;
                SmtpClient client = new SmtpClient();

                client.Host = ConfigurationSettings.getSmtpServer();
                client.Send(mail);
            }
            catch (Exception ex)
            {
                ExceptionHelper.HandleException(ex, ExceptionPolicy.BOExceptionPolicy);
            }

            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_END, WFMLogger.LogCategory.DebugLog);
        }

        private void SendNotification(string ToEmail, string CCEmail, string FromEmail, string Subject, string EmailBody, Attachment attachmentFile)
        {
            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_START, WFMLogger.LogCategory.DebugLog);

            try
            {
                string emailCCaddress = CCEmail;

                if (string.IsNullOrEmpty(ToEmail))
                    ToEmail = emailCCaddress;

                MailMessage mail = new MailMessage(FromEmail, ToEmail, Subject, EmailBody);
                if (!emailCCaddress.Equals(string.Empty))
                {
                    mail.CC.Add(emailCCaddress);
                }
                mail.IsBodyHtml = true;

                //foreach (Attachment file in attachments)
                //{
                //    mail.Attachments.Add(file);
                //}
                mail.Attachments.Add(attachmentFile);

                SmtpClient client = new SmtpClient();
                client.Host = ConfigurationSettings.getSmtpServer();
                client.Send(mail);
            }
            catch (Exception ex)
            {
                ExceptionHelper.HandleException(ex, ExceptionPolicy.BOExceptionPolicy);
            }

            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_END, WFMLogger.LogCategory.DebugLog);
        }

        private string getEmailContent(string EmailType)
        {
            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_START, WFMLogger.LogCategory.DebugLog);
            string q = @"  <Where>
                                <Eq>
                                    <FieldRef Name='EmailType' />
                                    <Value Type='Text'>" + EmailType + @"</Value>
                                </Eq>
                            </Where>";
            string EmailContent = string.Empty;
            string siteURL = ConfigurationSettings.SiteUrl();

            if (!string.IsNullOrEmpty(siteURL))
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(siteURL))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList list = web.Lists.TryGetList(Constants.ListName.EMAIL_CONTENT);
                            SPQuery query = new SPQuery();
                            query.Query = q;
                            SPListItemCollection listItems = list.GetItems(query);
                            foreach (SPListItem item in listItems)
                            {
                                EmailContent = Convert.ToString(item["EmailBody"]);
                                _emailFromAddress = Convert.ToString(item["EmailFromAddress"]);
                                _emailFromName = Convert.ToString(item["EmailFromName"]);
                                _emailSubject = Convert.ToString(item["EmailSubject"]);
                            }


                        }
                    }
                });
            }
            WFMLogger.LogTraceInformation(Constants.LogMessage.LOG_END, WFMLogger.LogCategory.DebugLog);
            return EmailContent;
        }

        private string ReplaceEmailInfo(string emailInfo, int listItemID)
        {
            int i = 0;
            int firstLetter = 0;
            int secondLetter = 0;

            List<string> wordsToReplace = new List<string>{}; 

            Boolean newWord = true;

            while (i < emailInfo.Length)
            {
                if (emailInfo[i] == '$' && newWord == true)
                {
                    firstLetter = i;
                    newWord = false;
                }
                else if (emailInfo[i] == '$' && newWord == false)
                {
                    secondLetter = i +1;
                    newWord = true;
                    wordsToReplace.Add(emailInfo.Substring(firstLetter,(secondLetter-firstLetter)));
                }

                i++;
            }

            return InsertListValues(emailInfo, wordsToReplace, listItemID);
        }

        private string InsertListValues(string emailInfo, List<string> wordsToReplace, int listItemID)
        {

             using (SPSite site = new SPSite(ConfigurationSettings.MasterSiteURL))
             {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPListItem item = web.Lists[Constants.ListName.WFM_TICKETS].GetItemById(Convert.ToInt32(listItemID));

                             foreach(string word in wordsToReplace){

                                if(word == "$Created$"){
                                    emailInfo = emailInfo.Replace(word, item[SPBuiltInFieldId.Created].ToString());
                                }
                                else 
                                {
                                    SPField field = item.ParentList.Fields.GetFieldByInternalName(word.Replace("$", string.Empty));
                                    SPFieldType fieldType = field.Type;
                                    string fieldTypeName = field.TypeDisplayName;

                                    if (fieldType == SPFieldType.Lookup)
                                    {
                                        emailInfo = emailInfo.Replace(word,new SPFieldLookupValue(item[word.Replace("$", string.Empty)] as String).LookupValue);
                                    }
                                    else
                                    {
                                        if (item[word.Replace("$", string.Empty)] != null)
                                        {
                                            emailInfo = emailInfo.Replace(word, item[word.Replace("$", string.Empty)].ToString());
                                        }
                                        else
                                        {
                                            emailInfo = emailInfo.Replace(word, "");
                                        }
                                    }
                                   
                                }

                             }

                             return emailInfo;
                        }

             }
        }

        #endregion

    }
}
