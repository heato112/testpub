using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using WFM.Common;

namespace NYL.WFM.Features.WFM_Provision_Report_WebParts
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("37f51d27-1e2b-40e2-bb26-2f8852c0db8c")]
    public class WFM_Provision_Report_WebPartsEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {

            try {


            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                SPWeb oWeb = (SPWeb)properties.Feature.Parent;
                if (oWeb != null)
                {
                    ReportHelper.SetupReportWebParts(oWeb.Site.ID, oWeb.ID);
                }
            });

            
                WFMLogger.LogTraceInformation("Activating Provision Reports Webparts feature  successful", WFMLogger.LogCategory.InfoLog);
            }
            catch (Exception e)
            {
                ExceptionHelper.HandleException(new Exception("Error occured activating Provision Reports Webparts feature", e), ExceptionPolicy.BOExceptionPolicy, true);
            }

        }


        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


    }
}
