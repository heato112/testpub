﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using WFM.Common;
using NYL.WFM.Common;

namespace WFM.Event_Receivers.WFMTicketEventReceiver
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class WFMTicketEventReceiver : SPItemEventReceiver
    {
        public override void ItemAdded(SPItemEventProperties properties)
        {
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(properties.Web.Site.ID))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            base.ItemAdded(properties);
                            base.EventFiringEnabled = false;
                            ConfigurationSettings.MasterSiteURL = PropertyBagHelper.GetPropertyValue(web, "mastersiteurl");
                          
                            SPListItem curritem = web.Lists[properties.ListTitle].GetItemById(Convert.ToInt32(properties.ListItem.ID));
                            curritem["TicketNumber"] = properties.ListItem["ID"].ToString().PadLeft(5, '0');
                            string ccEmail = "";
                            string managerEmail = "";

                            if (curritem["CCManagerEmail"] != null)
                            {
                                ccEmail = curritem["CCManagerEmail"].ToString();
                            }

                            if (curritem["Agent_x0020_Name_x003a__x0020_Ma0"] != null)
                            {
                                managerEmail = curritem["Agent_x0020_Name_x003a__x0020_Ma0"].ToString();
                            }

                            if (curritem["Agent_x0020_Name_x003a__x0020_Ma"] != null)
                            {
                                curritem["ManagerACF2ID"] = curritem["Agent_x0020_Name_x003a__x0020_Ma"].ToString();
                            }


                            if (curritem["Agent_x0020_Name_x003a__x0020_AC"] != null)
                            {
                                curritem["AgentACF2ID"] = curritem["Agent_x0020_Name_x003a__x0020_AC"].ToString();
                            }


                            if (curritem["Comments"] != null)
                            {
                                curritem["CommentsDisplay"] = ViewHelper.GetTruncatedText(curritem["Comments"].ToString());
                            }

                            if (curritem["Notes"] != null)
                            {
                                curritem["NotesDisplay"] = ViewHelper.GetTruncatedText(curritem["Notes"].ToString());
                            }

                            if (curritem["Agent_x0020_Name_x003a__x0020_De"] != null)
                            {
                                curritem["AgentDepartment"] = curritem["Agent_x0020_Name_x003a__x0020_De"].ToString();
                            }

                            if (curritem["Agent_x0020_Name_x003a__x0020_Fi"] != null)
                            {
                                curritem["AgentFirstName"] = curritem["Agent_x0020_Name_x003a__x0020_Fi"].ToString();
                            }

                            if (curritem["Agent_x0020_Name_x003a__x0020_La"] != null)
                            {
                                curritem["AgentLastName"] = curritem["Agent_x0020_Name_x003a__x0020_La"].ToString();
                            }

                            curritem.SystemUpdate();
                          
                            SPFieldUserValue userValue = new SPFieldUserValue(web, curritem[SPBuiltInFieldId.Author].ToString());
                            SPUser author = userValue.User;


                            TicketNotification.TicketCreatedNotification(curritem["Agent_x0020_Name_x003a__x0020_Em"].ToString(), managerEmail, ccEmail, author.Email, curritem.ID);
                
                        } 
                    }

                });
            }
            catch (Exception ex)
            {
                //WFMLogger.LogTraceInformation("Error occured in ticket added event receiver. " + ex, WFMLogger.LogCategory.ErrorLog);
                ExceptionHelper.HandleException(new Exception("Error occured in ticket added event receiver", ex), ExceptionPolicy.BOExceptionPolicy, true);
            }
            finally
            {
                base.EventFiringEnabled =true;
            }
        }
        
        
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
               {
                   using (SPSite site = new SPSite(properties.Web.Site.ID))
                   {
                       using (SPWeb web = site.OpenWeb())
                       {
                           base.ItemUpdated(properties);
                           base.EventFiringEnabled = false;

                           ConfigurationSettings.MasterSiteURL = properties.WebUrl;

                           SPListItem curritem = web.Lists[properties.ListTitle].GetItemById(Convert.ToInt32(properties.ListItem.ID));

                           string newStatus = curritem["Status"].ToString().ToLower();

                           if (newStatus == "approved" || newStatus == "denied")
                           {

                               SPFieldLookupValue requestType = new SPFieldLookupValue(curritem["RequestType"].ToString());
                               SPFieldUserValue userValue = new SPFieldUserValue(web, curritem[SPBuiltInFieldId.Author].ToString());
                               SPUser author = userValue.User;

                               string ccEmail = "";
                               string notes = "";
                               string managerEmail = "";

                               if (curritem["CCManagerEmail"] != null)
                               {
                                   ccEmail = curritem["CCManagerEmail"].ToString();
                               }

                               if (curritem["Notes"] != null)
                               {
                                   notes = curritem["Notes"].ToString();
                               }

                               if (curritem["Agent_x0020_Name_x003a__x0020_Ma0"] != null)
                               {
                                   managerEmail = curritem["Agent_x0020_Name_x003a__x0020_Ma0"].ToString();
                               }

                               
                               TicketNotification.TicketUpdatedNotification(curritem["Agent_x0020_Name_x003a__x0020_Em"].ToString(), managerEmail, ccEmail, author.Email, curritem.ID);

                           }

                           if (curritem["Comments"] != null)
                           {
                               curritem["CommentsDisplay"] = ViewHelper.GetTruncatedText(curritem["Comments"].ToString());
                           }

                           if (curritem["Notes"] != null)
                           {
                               curritem["NotesDisplay"] = ViewHelper.GetTruncatedText(curritem["Notes"].ToString());
                           }

                           if (curritem["Agent_x0020_Name_x003a__x0020_Ma"] != null)
                           {
                               curritem["ManagerACF2ID"] = curritem["Agent_x0020_Name_x003a__x0020_Ma"].ToString();
                           }


                           if (curritem["Agent_x0020_Name_x003a__x0020_AC"] != null)
                           {
                               curritem["AgentACF2ID"] = curritem["Agent_x0020_Name_x003a__x0020_AC"].ToString();
                           }

                           if (curritem["Agent_x0020_Name_x003a__x0020_De"] != null)
                           {
                               curritem["AgentDepartment"] = curritem["Agent_x0020_Name_x003a__x0020_De"].ToString();
                           }

                           if (curritem["Agent_x0020_Name_x003a__x0020_Fi"] != null)
                           {
                               curritem["AgentFirstName"] = curritem["Agent_x0020_Name_x003a__x0020_Fi"].ToString();
                           }

                           if (curritem["Agent_x0020_Name_x003a__x0020_La"] != null)
                           {
                               curritem["AgentLastName"] = curritem["Agent_x0020_Name_x003a__x0020_La"].ToString();
                           }

                           curritem.SystemUpdate();

                       }
                   }

                  
               });
            }
            catch (Exception ex)
            {
                //WFMLogger.LogTraceInformation("Error occured in ticket updated event receiver. " + ex, WFMLogger.LogCategory.ErrorLog);
                ExceptionHelper.HandleException(new Exception("Error occured in ticket updated event receiver", ex), ExceptionPolicy.BOExceptionPolicy, true);
            }
            finally{
                base.EventFiringEnabled = true;
            }   
        }
    }
}
