﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Navigation;

namespace WFM.Common
{
    public class NavigationLinks
    {
        /// <summary>
        /// Setup all SharePoint groups needed to manage security, except item level groups
        /// </summary>
        /// <param name="oSiteId">ID of Site collection</param>
        /// <param name="oWebId">ID of site (SPWeb)</param>
        public static void SetupSiteLinks(Guid oSiteId, Guid oWebId)
        {

            using (SPSite site = new SPSite(oSiteId))
            {
                using (SPWeb webItemNew = site.OpenWeb(oWebId))
                {
                    try
                    {
                        webItemNew.AllowUnsafeUpdates = true;

                        //Delete exisitng links
                        SPNavigationNodeCollection nodes = webItemNew.Navigation.QuickLaunch;
                        for (int i = nodes.Count - 1; i >= 0; i--)
                        {
                            nodes[i].Delete();
                        }

                        // Check for an existing link to the list.
                        SPNavigationNode newTicketNode = new SPNavigationNode("New Ticket", webItemNew.Url + "/Lists/WFMTickets/NewForm.aspx");
                        SPNavigationNode agentNode = new SPNavigationNode("Agent Queue", webItemNew.Url + "/Libraries/LandingPages/AgentHome.aspx");
                        SPNavigationNode managerNode = new SPNavigationNode("Manager Queue", webItemNew.Url + "/Libraries/LandingPages/ManagerHome.aspx");
                        SPNavigationNode wfmSupervisorNode = new SPNavigationNode("WFM Queue", webItemNew.Url + "/Libraries/LandingPages/WFMStaffHome.aspx");
                        SPNavigationNode blockagentstNode = new SPNavigationNode("Block Users", webItemNew.Url + "/Lists/BlockedUsers/AllItems.aspx");
                        SPNavigationNode reportNode = new SPNavigationNode("View Report", webItemNew.Url + "/_layouts/xlviewer.aspx?id=/Conf/WFM/Libraries/ReportsTemplateList/ReportsFile.xlsx");
                        SPNavigationNode searchbyDateNode = new SPNavigationNode("Date", webItemNew.Url + "/SearchPages/searchdate.aspx");
                        SPNavigationNode searchbyTicketNode = new SPNavigationNode("Ticket # / Agent", webItemNew.Url + "/SearchPages/searchnumber.aspx");
                        SPNavigationNode requestTypeListNode = new SPNavigationNode("Request Type List", webItemNew.Url + "/Lists/RequestType/AllItems.aspx");

                        SPNavigationNode QuickListHeaderNode = new SPNavigationNode("Quick Links", string.Empty);
                        SPNavigationNode AdminHeaderNode = new SPNavigationNode("Admin", string.Empty);
                        SPNavigationNode ReportsHeaderNode = new SPNavigationNode("Reports", string.Empty);
                        SPNavigationNode SearchHeaderNode = new SPNavigationNode("Search By", string.Empty);
                        

                        // Create Heading 
                        QuickListHeaderNode = nodes.AddAsFirst(QuickListHeaderNode);
                        MakeHeaderNode(QuickListHeaderNode);

                        ReportsHeaderNode = nodes.AddAsLast(ReportsHeaderNode);
                        ReportsHeaderNode.Properties["Audience"] = ";;;;" + Constants.GroupNames.WFM_STAFF_GROUP;
                        MakeHeaderNode(ReportsHeaderNode);

                        SearchHeaderNode = nodes.AddAsLast(SearchHeaderNode);
                        SearchHeaderNode.Properties["Audience"] = ";;;;" + Constants.GroupNames.WFM_STAFF_GROUP + "," + Constants.GroupNames.MANAGERS_GROUP;
                        MakeHeaderNode(SearchHeaderNode);


                        AdminHeaderNode = nodes.AddAsLast(AdminHeaderNode);
                        AdminHeaderNode.Properties["Audience"] = ";;;;" + Constants.GroupNames.WFM_STAFF_GROUP;
                        MakeHeaderNode(AdminHeaderNode);

                        newTicketNode = QuickListHeaderNode.Children.AddAsLast(newTicketNode);
                        newTicketNode.Properties["Audience"] = ";;;;" + Constants.GroupNames.AGENTS_GROUP + "," + Constants.GroupNames.MANAGERS_GROUP ;
                        newTicketNode.Update();

                        agentNode = QuickListHeaderNode.Children.AddAsLast(agentNode);
                        agentNode.Properties["Audience"] = ";;;;" + Constants.GroupNames.AGENTS_GROUP;
                        agentNode.Update();

                        managerNode = QuickListHeaderNode.Children.AddAsLast(managerNode);
                        managerNode.Properties["Audience"] = ";;;;" + Constants.GroupNames.MANAGERS_GROUP;
                        managerNode.Update();

                        wfmSupervisorNode = QuickListHeaderNode.Children.AddAsLast(wfmSupervisorNode);
                        wfmSupervisorNode.Properties["Audience"] = ";;;;" + Constants.GroupNames.WFM_STAFF_GROUP;
                        wfmSupervisorNode.Update();

                        blockagentstNode = AdminHeaderNode.Children.AddAsFirst(blockagentstNode);
                        blockagentstNode.Properties["Audience"] = ";;;;" + Constants.GroupNames.WFM_STAFF_GROUP;
                        blockagentstNode.Update();

                        requestTypeListNode = AdminHeaderNode.Children.AddAsFirst(requestTypeListNode);
                        requestTypeListNode.Properties["Audience"] = ";;;;" + Constants.GroupNames.WFM_ADMIN_GROUP;
                        requestTypeListNode.Update();

                        reportNode = ReportsHeaderNode.Children.AddAsLast(reportNode);
                        reportNode.Properties["Audience"] = ";;;;" + Constants.GroupNames.WFM_STAFF_GROUP;
                        reportNode.Update();

                        searchbyTicketNode = SearchHeaderNode.Children.AddAsLast(searchbyTicketNode);
                        searchbyTicketNode.Properties["Audience"] = ";;;;" + Constants.GroupNames.WFM_STAFF_GROUP + "," + Constants.GroupNames.MANAGERS_GROUP;
                        searchbyTicketNode.Update();

                        searchbyDateNode = SearchHeaderNode.Children.AddAsLast(searchbyDateNode);
                        searchbyDateNode.Properties["Audience"] = ";;;;" + Constants.GroupNames.WFM_STAFF_GROUP + "," + Constants.GroupNames.MANAGERS_GROUP;
                        searchbyDateNode.Update();


                        webItemNew.Update();
                        WFMLogger.LogTraceInformation("Adding navigation links successful", WFMLogger.LogCategory.InfoLog);
                    }
                    catch (Exception e)
                    {
                        //WFMLogger.LogTraceInformation("Error occured adding navigation links", WFMLogger.LogCategory.ErrorLog);
                        ExceptionHelper.HandleException(new Exception("Error occured adding navigation links", e), ExceptionPolicy.BOExceptionPolicy, true);
                    }
                }
            }

        }

       
            public static void MakeHeaderNode(SPNavigationNode node)
            {
                node.Properties["BlankUrl"] = "True";
                node.Properties["LastModifiedDate"] = DateTime.Now;
                node.Properties["Target"] = "";
                node.Properties["vti_navsequencechild"] = "true";
                node.Properties["UrlQueryString"] = "";
                node.Properties["CreatedDate"] = DateTime.Now;
                node.Properties["Description"] = "";
                node.Properties["UrlFragment"] = "";
                node.Properties["NodeType"] = "Heading";
                node.Update();
            }
    }
}
