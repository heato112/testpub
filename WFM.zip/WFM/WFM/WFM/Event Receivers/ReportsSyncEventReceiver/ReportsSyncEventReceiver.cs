﻿using Microsoft.SharePoint;
using WFM.Common;

namespace WFM.Event_Receivers.ReportsSyncEventReceiver
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class ReportsSyncEventReceiver : SPItemEventReceiver
    {
        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            ConfigurationSettings.MasterSiteURL = properties.WebUrl;
            ReportHelper.GenerateWFMReports(properties.Web.Site.ID, properties.Web.ID, properties.ListItem);
        }
    }
}
