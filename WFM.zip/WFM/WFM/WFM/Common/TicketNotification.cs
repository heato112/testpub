﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace WFM.Common
{
    public class TicketNotification
    {
        public static void TicketCreatedNotification(string agentEmail, string managerEmail, string ccManagerEmail, string author, int listItemID)
        {
           try{
            NotificationHelper sendEmail = new NotificationHelper();
            sendEmail.SendNewTicketEmail(agentEmail, getCCEmailRecipients(agentEmail, managerEmail, ccManagerEmail, author), listItemID);
           }
           catch (Exception e)
           {
               ExceptionHelper.HandleException("WFM Error sending new ticket email", new Exception(string.Format("Error occurred while sending new created ticket email for ItemID: {0}", listItemID.ToString()), e), ExceptionPolicy.BOExceptionPolicy, true);
           }
        }

        public static void TicketUpdatedNotification(string agentEmail, string managerEmail, string ccManagerEmail, string author, int listItemID)
        {
            try{
            NotificationHelper sendEmail = new NotificationHelper();
            sendEmail.SendUpdateStatusEmail(agentEmail,getCCEmailRecipients(agentEmail, managerEmail, ccManagerEmail, author),listItemID);
            }
            catch (Exception e)
            {
                ExceptionHelper.HandleException("WFM Error sending updated ticket email", new Exception(string.Format("Error occurred while sending updating ticket email for ItemID: {0}", listItemID.ToString()), e), ExceptionPolicy.BOExceptionPolicy, true);
            }
        }

        private static string getCCEmailRecipients(string agentEmail, string managerEmail, string ccManagerEmail, string createByEmail)
        {
            try
            {
                string emailRecipients = managerEmail;

                if (!string.IsNullOrEmpty(ccManagerEmail))
                {
                    emailRecipients += ", " + ccManagerEmail;
                }

                if (!string.IsNullOrEmpty(createByEmail))
                {
                    if (agentEmail != createByEmail && managerEmail != createByEmail)
                    {
                        emailRecipients += ", " + createByEmail;
                    }
                }
                return emailRecipients;
                
            }
            catch (Exception e)
            {
                ExceptionHelper.HandleException(new Exception("Error occured getting CCEmail Recipients", e), ExceptionPolicy.BOExceptionPolicy, true);
                return "";
            }
            
        }

       
    }
}
