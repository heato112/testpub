﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Microsoft.SharePoint;
using System.IO;
using Microsoft.Office.Excel.WebUI;
using Microsoft.SharePoint.WebPartPages;
using System.Web.UI.WebControls.WebParts;

namespace WFM.Common
{
    public static class ReportHelper
    {
        public static void GenerateWFMReports(Guid oSiteId, Guid oWebId, SPListItem listItem)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            try
            {
                DataTable dtReports = getWFMDataForReports(oSiteId, oWebId);
                dtReports = addReportDataColumns(dtReports);
                dtReports = formatReportData(dtReports);
                uploadReportDataFile(oSiteId, oWebId, listItem, dtReports);
                updateReportGenerationStatus(Constants.ReportsSyncResultType.REPORT_SYNC_COMPLETE, true, listItem);

            }
            catch (Exception e)
            {
                //WFMLogger.LogException(new Exception("Error occurred while generating WFM Reports",e));
                ExceptionHelper.HandleException(Constants.ModuleName.WFM_GROUP_SYNC, new Exception(string.Format("Error occurred while generating WFM Reports for ItemID: {0}", listItem.ID.ToString()), e), ExceptionPolicy.BOExceptionPolicy, true);
            }
            finally
            {
                updateReportGenerationStatus(Constants.ReportsSyncResultType.SYNC_PROCESS_COMPLETE, true, listItem);
            }

            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
        }

        #region Setup WebParts

        public static void SetupReportWebParts(Guid oSiteId, Guid oWebId)
        {
            setupReport1WebPartPage(oSiteId, oWebId);
            setupReport2WebPartPage(oSiteId, oWebId);
            setupReport3WebPartPage(oSiteId, oWebId);
            setupReport4WebPartPage(oSiteId, oWebId);
            setupReport5WebPartPage(oSiteId, oWebId);
        }

        private static void setupReport1WebPartPage(Guid oSiteId, Guid oWebId)
        {
            addReportWebPart(oSiteId, oWebId, "Libraries/WFMAllPages/Report1.aspx", getReportFileURL(oSiteId, oWebId), Constants.ReportPagesPivotName.REPORT_PIVOT_1, Constants.ReportPagesWebPartTitle.REPORT_1, 0);
        }

        private static void setupReport2WebPartPage(Guid oSiteId, Guid oWebId)
        {
            addReportWebPart(oSiteId, oWebId, "Libraries/WFMAllPages/Report2.aspx", getReportFileURL(oSiteId, oWebId), Constants.ReportPagesPivotName.REPORT_PIVOT_2, Constants.ReportPagesWebPartTitle.REPORT_2, 0);
        }

        private static void setupReport3WebPartPage(Guid oSiteId, Guid oWebId)
        {
            addReportWebPart(oSiteId, oWebId, "Libraries/WFMAllPages/Report3.aspx", getReportFileURL(oSiteId, oWebId), Constants.ReportPagesPivotName.REPORT_PIVOT_3, Constants.ReportPagesWebPartTitle.REPORT_3, 0);
        }

        private static void setupReport4WebPartPage(Guid oSiteId, Guid oWebId)
        {
            addReportWebPart(oSiteId, oWebId, "Libraries/WFMAllPages/Report4.aspx", getReportFileURL(oSiteId, oWebId), Constants.ReportPagesPivotName.REPORT_PIVOT_4, Constants.ReportPagesWebPartTitle.REPORT_4, 0);
        }

        private static void setupReport5WebPartPage(Guid oSiteId, Guid oWebId)
        {
            addReportWebPart(oSiteId, oWebId, "Libraries/WFMAllPages/Report5.aspx", getReportFileURL(oSiteId, oWebId), Constants.ReportPagesPivotName.REPORT_PIVOT_5, Constants.ReportPagesWebPartTitle.REPORT_5, 0);
        }

        private static string getReportFileURL(Guid oSiteId, Guid oWebId)
        {
            string fileURL = string.Empty;

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(oSiteId))
                {
                    using (SPWeb web = site.OpenWeb(oWebId))
                    {
                        SPList list = web.Lists.TryGetList(Constants.ListName.REPORTS_TEMPLATE_LIST);
                        if (list != null)
                        {
                            fileURL = string.Concat(list.ParentWebUrl, "/", list.RootFolder.Url, "/", Constants.ReportsFile.FILE_NAME, ".xlsx");
                        }
                    }
                }
            });

            return fileURL;
        }

        private static void addReportWebPart(Guid oSiteId, Guid oWebId, string pageUrl, string bookUrl, string namedItem, string webPartTitle, int webPartIndex)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(oSiteId))
                {
                    using (SPWeb web = site.OpenWeb(oWebId))
                    {
                        string reportWebPartIdentifier = string.Empty;

                        try
                        {
                            reportWebPartIdentifier = string.Concat(pageUrl, ":", namedItem, ":", webPartTitle);
                            SPFile page = web.GetFile(pageUrl);
                            using (SPLimitedWebPartManager wpmgr = page.GetLimitedWebPartManager(PersonalizationScope.Shared))
                            {
                                ExcelWebRenderer ewrWebPart = new ExcelWebRenderer();
                                ewrWebPart.WorkbookUri = bookUrl;

                                if (!string.IsNullOrEmpty(namedItem))
                                {
                                    ewrWebPart.VisibleItem = namedItem;
                                }

                                ewrWebPart.AutoGenerateTitle = false;
                                ewrWebPart.Title = webPartTitle;
                                ewrWebPart.ChromeType = PartChromeType.TitleAndBorder;
                                ewrWebPart.ToolbarStyle = ToolbarVisibilityStyle.None;

                                wpmgr.AddWebPart(ewrWebPart, "Header", webPartIndex);
                                wpmgr.SaveChanges(ewrWebPart);
                            }
                        }
                        catch (Exception ex)
                        {
                            //WFMLogger.LogTraceInformation(string.Format("Error occured while adding Report WebPart: {0}", ex.ToString()), WFMLogger.LogCategory.ErrorLog);
                            ExceptionHelper.HandleException(new Exception(string.Format("Error occured while adding Report WebPart: {0}", reportWebPartIdentifier), ex), ExceptionPolicy.BOExceptionPolicy, true);
                        }
                    }
                }
            });
        }

        #endregion

        #region Generate Report

        private static DataTable getWFMDataForReports(Guid oSiteId, Guid oWebId)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            DataTable dt = new DataTable();
            int startDate = 1;
            int endDate = 1;
 
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(oSiteId))
                {
                    using (SPWeb web = site.OpenWeb(oWebId))
                    {
                        SPList list = web.Lists.TryGetList(Constants.ListName.WFM_TICKETS);


                        if (list != null)
                        {
                            for (int i = 0; i < 12; i++)
                            {

                                startDate = 365 - (i * 30);
                                endDate = 365 - ((i + 1) * 30);
                                if (i == 11)
                                    endDate = 0;


                                SPQuery camlQuery = new SPQuery();
                                camlQuery.Query = "<Where>" +
                                       "<And>" +
                                          "<Geq>" +
                                            "<FieldRef Name='Modified' />" +
                                            "<Value Type='DateTime'><Today OffsetDays='-" + startDate.ToString() + "'/></Value> " +
                                          "</Geq>" +
                                      
                                          "<Lt>" +
                                            "<FieldRef Name='Modified' />" +
                                            "<Value Type='DateTime'><Today OffsetDays='-" + endDate.ToString() + "'/></Value> " +
                                          "</Lt>" +
                                       
                                        "</And>" +
                                        "</Where>";

                                camlQuery.RowLimit = 4000;

                                try
                                {
                                    int reportsDataRowLimit = ConfigurationSettings.getReportsDataRowLimit();
                                    WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, "Reports Row Limit value is " + reportsDataRowLimit.ToString(), WFMLogger.LogCategory.InfoLog);
                                    camlQuery.RowLimit = Convert.ToUInt32(reportsDataRowLimit);
                                }
                                catch
                                {

                                }

                                do
                                {
                                    SPListItemCollection collListItems = list.GetItems(camlQuery);
                                    DataTable dt1 = collListItems.GetDataTable();
                                    if (dt1!=null)
                                        dt.Merge(dt1);
                                    camlQuery.ListItemCollectionPosition = collListItems.ListItemCollectionPosition;

                                } while (camlQuery.ListItemCollectionPosition != null);

                            }
                        }

                    }
                }
            });

            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
            return dt;
        }

        private static DataTable addReportDataColumns(DataTable dt)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            DataColumn dcModifiedText = new DataColumn("ModifiedText", typeof(System.String));
            dcModifiedText.DefaultValue = string.Empty;
            dt.Columns.Add(dcModifiedText);

            DataColumn dcCreatedText = new DataColumn("CreatedText", typeof(System.String));
            dcCreatedText.DefaultValue = string.Empty;
            dt.Columns.Add(dcCreatedText);

            DataColumn dcEventDateText = new DataColumn("EventDateText", typeof(System.String));
            dcEventDateText.DefaultValue = string.Empty;
            dt.Columns.Add(dcEventDateText);

            DataColumn dcCount = new DataColumn("Count", typeof(System.Int32));
            dcCount.DefaultValue = 1;
            dt.Columns.Add(dcCount);

            DataColumn dcTimeComplianceCount = new DataColumn("TimeComplianceCount", typeof(System.Int32));
            dcTimeComplianceCount.DefaultValue = 0;
            dt.Columns.Add(dcTimeComplianceCount);

            DataColumn dcNonTimeComplianceCount = new DataColumn("NonTimeComplianceCount", typeof(System.Int32));
            dcNonTimeComplianceCount.DefaultValue = 0;
            dt.Columns.Add(dcNonTimeComplianceCount);

            dt.AcceptChanges();

            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);

            return dt;
        }

        private static DataTable formatReportData(DataTable dt)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            foreach (DataRow rw in dt.Rows)
            {
                DateTime submittedDate = Convert.ToDateTime((rw["SubmittedDate"]));
                DateTime modifiedDate = Convert.ToDateTime((rw["Modified"]));
                DateTime createdDate = Convert.ToDateTime((rw["Created"]));
                DateTime eventDate = Convert.ToDateTime((rw["EventDate"]));

                TimeSpan span = modifiedDate.Subtract(submittedDate);
                double minutesSpan = span.TotalMinutes;

                if (rw["Status"] != null && !string.IsNullOrEmpty(Convert.ToString(rw["Status"])))
                {
                    if (!Convert.ToString(rw["Status"]).Equals("Open"))
                    {
                        if (minutesSpan > 2880)
                        {
                            rw["TimeComplianceCount"] = 0;
                            rw["NonTimeComplianceCount"] = 1;
                        }
                        else
                        {
                            rw["TimeComplianceCount"] = 1;
                            rw["NonTimeComplianceCount"] = 0;
                        }
                    }
                }
                rw["SubmittedDate"] = submittedDate.ToString("d");
                rw["Modified"] = modifiedDate.ToString("d");
                rw["ModifiedText"] = modifiedDate.ToString("d");
                rw["Created"] = createdDate.ToString("d");
                rw["CreatedText"] = createdDate.ToString("d");
                rw["EventDate"] = eventDate.ToString("d");
                rw["EventDateText"] = eventDate.ToString("d");

                rw.AcceptChanges();
            }

            dt.AcceptChanges();

            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);

            return dt;
        }

        private static void uploadReportDataFile(Guid oSiteId, Guid oWebId, SPListItem listItem, DataTable dtReports)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(oSiteId))
                {
                    using (SPWeb web = site.OpenWeb(oWebId))
                    {
                        SPList list = web.Lists.TryGetList(Constants.ListName.REPORTS_TEMPLATE_LIST);
                        if (list != null)
                        {
                            web.AllowUnsafeUpdates = true;
                           
                            
                            SPFile file = web.GetFile(string.Concat(list.ParentWebUrl, list.RootFolder.Url, "/", Constants.ReportsFile.FILE_NAME, ".xlsx"));
                            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, string.Format("Report File from URL: {0} retrieved successfully", file.Url), WFMLogger.LogCategory.InfoLog);

                            byte[] fileContents = file.OpenBinary();
                            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, "Report File opened successfully", WFMLogger.LogCategory.InfoLog);

                            fileContents = ExcelHelper.CreateExcelDocument(dtReports, fileContents, Constants.ReportsFile.SHEET_NAME);
                            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, "Report File updated with Report data", WFMLogger.LogCategory.InfoLog);

                            file.SaveBinary(fileContents, false);
                            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, "Report File saved successfully", WFMLogger.LogCategory.InfoLog);

                            web.AllowUnsafeUpdates = true;
                            
                        }
                    }
                }
            });

            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
        }

        private static void updateReportGenerationStatus(string columnName, bool status, SPListItem item)
        {
            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, Constants.LogMessage.LOG_START, WFMLogger.LogCategory.InfoLog);
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    if (item != null)
                    {
                        item[columnName] = status;
                        item.Update();
                    }
                });
            }
            catch (Exception e)
            {
                //WFMLogger.LogException(new Exception("Error occurred while updating WFM Report Generation status",e));
                ExceptionHelper.HandleException(Constants.ModuleName.WFM_REPORT_SYNC, new Exception(string.Format("Error occurred while updating WFM Report Generation status for column: {0}", columnName), e), ExceptionPolicy.BOExceptionPolicy, true);
            }

            WFMLogger.LogTraceInformation(Constants.ModuleName.WFM_REPORT_SYNC, Constants.LogMessage.LOG_END, WFMLogger.LogCategory.InfoLog);
        }

        private static byte[] convertStringToBytes(string input)
        {
            MemoryStream stream = new MemoryStream();
            using (StreamWriter writer = new StreamWriter(stream))
            {
                writer.Write(input);
                writer.Flush();
            }
            return stream.ToArray();
        }

        #endregion

    }
}
