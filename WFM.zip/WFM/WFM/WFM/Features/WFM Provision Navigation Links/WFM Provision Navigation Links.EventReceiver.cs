using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using WFM.Common;

namespace WFM.Features.WFM_Provision_Navigation_Links
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("1227ee7a-20f9-41f2-8801-aa1bf6a29995")]
    public class WFM_Provision_Navigation_LinksEventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            try
            {
                SPWeb oWeb = (SPWeb)properties.Feature.Parent;
                if (oWeb != null)
                {
                    if (oWeb.Site != null)
                    {
                        NavigationLinks.SetupSiteLinks(oWeb.Site.ID, oWeb.ID);
                    }
                }

                WFMLogger.LogTraceInformation("Activating Provision Navigation links feature  successful", WFMLogger.LogCategory.InfoLog);
            }
            catch (Exception e)
            {
                ExceptionHelper.HandleException(new Exception("Error occured activating provision navigation links feature", e), ExceptionPolicy.BOExceptionPolicy, true);
            }
            
        }

    }
}
